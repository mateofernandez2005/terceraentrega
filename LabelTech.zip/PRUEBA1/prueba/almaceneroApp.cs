﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.Json;
using System.Data;


namespace prueba
{
    public partial class almaceneroApp : Form
    {
        public almaceneroApp()
        {
            InitializeComponent();

            if (variables.idiom == true)
            {
                
                lbAlm.Text = "grocer";
                lbAlmanio.Text = "year";
                lbAlmclistadelotes.Text = "List of lots in your warehouse";
                lbAlmdia.Text = "day";
                lbAlmfecha.Text = "enter the date the batch was";
                lbAlmfecha2.Text = " loaded onto the truck";
                lbAlmhs.Text = "hs";
                lbAlmidalmacen.Text = "enter your warehouse id:";
                lbAlmidlote.Text = "enter your lot id:";
                lbAlmlegadaidlote.Text = "enter your lot id:";
                lbAlmlistadepaquetes.Text = "Package List per lot";
                lbAlmmatricula.Text = "Enter truck registration:";
                lbAlmmes.Text = "month";
                lbAlmmin.Text = "min";
                lbAlmsalidadelte.Text = "Lot departure to truck";
                lbAlmsalidaidlote.Text = "Enter lot ID:";
                btnRegistrar.Text = "register";
                button1.Text = "exit";
                button2.Text = "assign";
                button3.Text = "search";
                button8.Text = "search";
                gbalmacen.Text = "warehouse";
                gbsalida.Text = "departure";
                gbllegada.Text = "register lot arrival";


            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Menu frmMenu = new Menu();
            this.Hide();
            frmMenu.Show();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Menu frmMenu = new Menu();
            this.Hide();
            frmMenu.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Menu frmMenu = new Menu();
            this.Hide();
            frmMenu.Show();
        }

        private void btnIdBulto_Click(object sender, EventArgs e)
        {

        }
        internal class lotelote
        {
            public int idalmacen { set; get; }
            public int idlote { set; get; }
            protected List<Int32> _data;
            public int devu { set; get; }

            public lotelote()
            {
                _data = new List<Int32>();

            }
            public List<Int32> data
            {
                get { return (_data); }
                set { _data = value; }
            }
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            almacenLote al = new almacenLote();





            String llSerializado;
            String resultado;
            lotelote ll = new lotelote();
            lotelote laa;

           
            int numero;
            if (int.TryParse(txtIdBulto.Text, out numero))
            {
                ll.idlote = numero;
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The entered value is not valid, only integers");
                }
                else
                {
                      MessageBox.Show("el valor ingresado del almacen no es valido, solo nunmeros enteros");
                    
                }

            }

            al.idlote = ll.idlote;

            int numeroAlmacen;
            if (int.TryParse(txtidalmacen.Text, out numeroAlmacen))
            {
                ll.idalmacen = numeroAlmacen;
            }
            else
            {
                        if (variables.idiom == true)
                    {
                        MessageBox.Show("The entered warehouse value is not valid, only integers");
                    }
                    else
                    {
                        MessageBox.Show("el valor ingresado del almacen no es valido, solo nunmeros enteros");
                    }            }


            al.idalmacen = ll.idalmacen;
           

            llSerializado = JsonSerializer.Serialize(ll);
            resultado = apiAlmacen.ingresarLote(llSerializado);
            laa = JsonSerializer.Deserialize<lotelote>(resultado);

            DataTable dt = new DataTable();

            if (laa.data.Count == 0)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The batch is already registered, either in this or another warehouse");
                }
                else
                {
                    MessageBox.Show("el lote ya esta registrado, ya sea en este u otro almacen");
                }

                girdlotes.DataSource = null;
            }
            else
            {
                dt.Columns.Add("id_lote", typeof(Int32));
                foreach (Int32 i in laa.data)
                {
                    dt.Rows.Add(i);
                }

               

                girdlotes.DataSource = dt;
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        internal class almacenL
        {
            public int idalmacen { set; get; }
            public int idlote { set; get; }
            protected List<Int32> _data;

            public almacenL()
            {
                _data = new List<Int32>();

            }
            public List<Int32> data
            {
                get { return (_data); }
                set { _data = value; }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            almacenLote al = new almacenLote();


          


            String laSerializado;
            String resultado;
            almacenL la = new almacenL();
            almacenL laa;
            al.idlote = la.idlote;
         

            int numero;
            if (int.TryParse(txtidalmacen.Text, out numero))
            {
                la.idalmacen = numero;
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The entered warehouse value is not valid, only integers");
                }
                else { 
                MessageBox.Show("el valor ingresado no es valido, solo nunmeros enteros");

                }
            }

                al.idalmacen = la.idalmacen;
            laSerializado = JsonSerializer.Serialize(la);

            resultado = apiAlmacen.registroLotes(laSerializado);////

            laSerializado = JsonSerializer.Serialize(la);
            resultado = apiAlmacen.registroLotes(laSerializado);
            laa = JsonSerializer.Deserialize<almacenL>(resultado);

            DataTable dt = new DataTable();

            if (laa.data.Count == 0)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The warehouse was not found");
                }
                else
                {
                    MessageBox.Show("no se encontro el almacen");
                }

                girdlotes.DataSource = null;
            }
            else
            {
                dt.Columns.Add("id_lote", typeof(Int32));
                foreach (Int32 i in laa.data)
                {
                    dt.Rows.Add(i);
                }

               
                girdlotes.DataSource = dt;
            }
        }
        internal class bultoL
        {
            public int idbulto { set; get; }
            public int idlote { set; get; }
            protected List<Int32> _data;

            public bultoL()
            {
                _data = new List<Int32>();

            }
            public List<Int32> data
            {
                get { return (_data); }
                set { _data = value; }
            }
        }
        private void button8_Click(object sender, EventArgs e)
        {
            BultoLote bl = new BultoLote();

            String  lbSerializado;
            String resultado;
            bultoL lb = new bultoL();
            bultoL lbb;
            bl.id_bulto = lb.idbulto;
            int idLote;
            bool isIdLoteValid = int.TryParse(txtidlote.Text, out idLote);
            if (!isIdLoteValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The provided text is not a valid integer.");
                }
                else
                {
                    Console.WriteLine("El texto proporcionado no es un número entero válido.");
                }

            }
            else
            {
                lb.idlote = idLote;
            }


            bl.id_lote = lb.idlote;
            lbSerializado = JsonSerializer.Serialize(lb);

            resultado = apiAlmacen.registropaquetes(lbSerializado);////

            lbSerializado = JsonSerializer.Serialize(lb);
            resultado = apiAlmacen.registropaquetes(lbSerializado);
            lbb = JsonSerializer.Deserialize<bultoL>(resultado);

            DataTable dt = new DataTable();

            if (lbb.data.Count == 0)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The batch was not found or is empty");
                }
                else
                {
                    MessageBox.Show("no se encontro el lote o se encuentra vacio");
                }
                girdlotes.DataSource = null;
            }
            else
            {
                dt.Columns.Add("id_bulto", typeof(Int32));
                foreach (Int32 i in lbb.data)
                {
                    dt.Rows.Add(i);
                }

               
                gridpaquetelote.DataSource = dt;
            }
        }
        internal class loteC
        {
            public string matricula { set; get; }
            public int idlote { set; get; }
            protected List<Int32> _data;

            public loteC()
            {
                _data = new List<Int32>();

            }
            public List<Int32> data
            {
                get { return (_data); }
                set { _data = value; }
            }
        }

        internal class idmatrifecha
        {
            public string matricula { set; get; }
            public int idlote { set; get; }
            public DateTime _fecha { set; get; }
            public int devu { set; get; }
            protected List<Int32> _data;
            public int idalmacen { set; get; }

            public idmatrifecha()
            {
                _data = new List<Int32>();

            }
            public List<Int32> data
            {
                get { return (_data); }
                set { _data = value; }
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            almacenLote al = new almacenLote();

            camionLote cl = new camionLote();

            // esta parte esta hecha de esta forma ya que por algun motivo al deserializar en el api las variables del objeto quedaban vacias
            cl.matricula = txtmatri.Text;
            string id = txtloti.Text;

            int numeroci;
            if (int.TryParse(txtloti.Text, out numeroci))
            {
                cl.id = numeroci;
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The entered batch value is not valid, only integers");
                }
                else
                {
                    MessageBox.Show("el valor ingresado del lote no es valido, solo nunmeros enteros");
                }
            }

            int año, mes, dia, hora, minuto;

            bool esAñoValido = int.TryParse(txtanio.Text, out año);
            bool esMesValido = int.TryParse(txtmes.Text, out mes);
            bool esDiaValido = int.TryParse(txtdia.Text, out dia);
            bool esHoraValido = int.TryParse(txths.Text, out hora);
            bool esMinutoValido = int.TryParse(txtmin.Text, out minuto);

            if (esAñoValido && esMesValido && esDiaValido && esHoraValido && esMinutoValido)
            {
                cl.fecha = new DateTime(año, mes, dia, hora, minuto, 0);
                // Utiliza la variable fecha aquí
            }
            else
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("One or more entered date values are not valid numbers.");
                }
                else
                {
                    Console.WriteLine("Uno o más valores ingresados de la fecha no son números válidos.");
                }
            }


            int devolucion2 = cl.buscarLoteCamion();
            if (devolucion2 == 2) { 
            int devolucion = cl.InsertarDatos();
            if (devolucion == 3)
            {
                    if (variables.idiom == true)
                    {
                        MessageBox.Show("registered correctly");
                    }
                    else
                    {
                        MessageBox.Show("se registro correctamente");
                    }


                }
                else if (devolucion == 1)
            {
                    if (variables.idiom == true)
                    {
                        MessageBox.Show("Error, check the registration and the batch");
                    }
                    else
                    {
                        MessageBox.Show("Error, revise la matricula y el lote");
                    }
                }
                else if (devolucion == 2)//no encontre el paquete
            {
                    if (variables.idiom == true)
                    {
                        MessageBox.Show("the connection is not open");
                    }
                    else
                    {
                        MessageBox.Show("no esta abierta la conexion ");
                    }

                }
                else
            {
                    if (variables.idiom == true)
                    {
                        MessageBox.Show("resounding error");
                    }
                    else
                    {
                        MessageBox.Show("error rotundo ");
                    }
                }
            }
            else if (devolucion2 == 3)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("the batch is already in a truck");
                }
                else
                {
                    MessageBox.Show("el lote ya se encuentra en un camion ");
                }
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("error");
                }
                else
                {
                    MessageBox.Show("error");
                }
            }

            int numeroalmacen =-1;
            if (int.TryParse(txtidalmacen.Text, out numeroci))
            {
                cl.id = numeroci;
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The entered batch value is not valid, only integers");
                }
                else
                {
                    MessageBox.Show("el valor ingresado del lote no es valido, solo nunmeros enteros");
                }
            }


            //    String imfSerializado;
            //    String resultado;
            //    idmatrifecha imf = new idmatrifecha();
            //    idmatrifecha imff;


            //    int numero;
            //    if (int.TryParse(txtloti.Text, out numero))
            //    {
            //        imf.idlote = numero;

            //    }
            //    else
            //    {
            //        MessageBox.Show("el valor ingresado no es valido, solo nunmeros enteros");
            //    }

            //    cl.id = imf.idlote;

            //    imf.matricula = txtmatri.Text;

            //    int numeroAlmacen;
            //    if (int.TryParse(txtidalmacen.Text, out numeroAlmacen))
            //    {
            //        imf.idalmacen = numeroAlmacen;
            //    }
            //    else
            //    {
            //        MessageBox.Show("el valor ingresado no es valido, solo nunmeros enteros");
            //    }


            //    al.idalmacen = imf.idalmacen;


            //    cl.matricula = imf.matricula;

            //    int año, mes, dia, hora, minuto;

            //    bool esAñoValido = int.TryParse(txtanio.Text, out año);
            //    bool esMesValido = int.TryParse(txtmes.Text, out mes);
            //    bool esDiaValido = int.TryParse(txtdia.Text, out dia);
            //    bool esHoraValido = int.TryParse(txths.Text, out hora);
            //    bool esMinutoValido = int.TryParse(txtmin.Text, out minuto);

            //    if (esAñoValido && esMesValido && esDiaValido && esHoraValido && esMinutoValido)
            //    {
            //        cl.fecha = new DateTime(año, mes, dia, hora, minuto, 0);
            //        // Utiliza la variable fecha aquí
            //    }
            //    else
            //    {
            //        MessageBox.Show("Uno o más valores ingresados de la fecha no son números válidos.");
            //    }

            //    imf._fecha = cl.fecha;






            //    imfSerializado = JsonSerializer.Serialize(imf);

            //    resultado = apiAlmacen.salidaLote(imfSerializado);
            //    imff = JsonSerializer.Deserialize<idmatrifecha>(resultado);

            //    DataTable dt = new DataTable();

            //    if (imff.devu == 4)
            //    {
            //        MessageBox.Show("el lote ya esta registrado en un camion");
            //        girdlotes.DataSource = null;
            //    }
            //    else if(imff.devu ==3 )
            //    {
            //        MessageBox.Show("registrado correctamente, muchas gracias");
            //        dt.Columns.Add("id_lote", typeof(Int32));
            //        foreach (Int32 i in imff.data)
            //        {
            //            dt.Rows.Add(i);
            //        }

            //        //Console.WriteLine(imff.data[0]);
            //        girdlotes.DataSource = dt;
            //    }
            //    else
            //    {
            //        MessageBox.Show("error");
            //    }
        }

        private void txtIdBulto_TextChanged(object sender, EventArgs e)
        {

        }

        private void gbalmacen_Enter(object sender, EventArgs e)
        {

        }
    }
    }

    
    

