﻿namespace prueba
{
    partial class usuarioApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(usuarioApp));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.año = new System.Windows.Forms.Label();
            this.txths = new System.Windows.Forms.TextBox();
            this.txtdia = new System.Windows.Forms.TextBox();
            this.txtmes = new System.Windows.Forms.TextBox();
            this.txtanio = new System.Windows.Forms.TextBox();
            this.lbclienfecha = new System.Windows.Forms.Label();
            this.txtenvio = new System.Windows.Forms.TextBox();
            this.lbclienestado = new System.Windows.Forms.Label();
            this.lbclienlocalizar = new System.Windows.Forms.Label();
            this.txtDemora = new System.Windows.Forms.TextBox();
            this.lbcliendemora = new System.Windows.Forms.Label();
            this.txtLote = new System.Windows.Forms.TextBox();
            this.txtCamion = new System.Windows.Forms.TextBox();
            this.txtCamionero = new System.Windows.Forms.TextBox();
            this.lbcliencamionero = new System.Windows.Forms.Label();
            this.lbcliencamion = new System.Windows.Forms.Label();
            this.lbcliendatos = new System.Windows.Forms.Label();
            this.lbclienlote = new System.Windows.Forms.Label();
            this.btnIngresar = new System.Windows.Forms.Button();
            this.txtId = new System.Windows.Forms.TextBox();
            this.lbclienid = new System.Windows.Forms.Label();
            this.btnSalir = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbclien = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.AliceBlue;
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.año);
            this.groupBox1.Controls.Add(this.txths);
            this.groupBox1.Controls.Add(this.txtdia);
            this.groupBox1.Controls.Add(this.txtmes);
            this.groupBox1.Controls.Add(this.txtanio);
            this.groupBox1.Controls.Add(this.lbclienfecha);
            this.groupBox1.Controls.Add(this.txtenvio);
            this.groupBox1.Controls.Add(this.lbclienestado);
            this.groupBox1.Controls.Add(this.lbclienlocalizar);
            this.groupBox1.Controls.Add(this.txtDemora);
            this.groupBox1.Controls.Add(this.lbcliendemora);
            this.groupBox1.Controls.Add(this.txtLote);
            this.groupBox1.Controls.Add(this.txtCamion);
            this.groupBox1.Controls.Add(this.txtCamionero);
            this.groupBox1.Controls.Add(this.lbcliencamionero);
            this.groupBox1.Controls.Add(this.lbcliencamion);
            this.groupBox1.Controls.Add(this.lbcliendatos);
            this.groupBox1.Controls.Add(this.lbclienlote);
            this.groupBox1.Controls.Add(this.btnIngresar);
            this.groupBox1.Controls.Add(this.txtId);
            this.groupBox1.Controls.Add(this.lbclienid);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(77, 81);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(352, 417);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(277, 357);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(24, 18);
            this.label13.TabIndex = 23;
            this.label13.Text = "hs";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(229, 357);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(27, 18);
            this.label11.TabIndex = 22;
            this.label11.Text = "dia";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(180, 357);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 18);
            this.label10.TabIndex = 21;
            this.label10.Text = "mes";
            // 
            // año
            // 
            this.año.AutoSize = true;
            this.año.Location = new System.Drawing.Point(139, 357);
            this.año.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.año.Name = "año";
            this.año.Size = new System.Drawing.Size(33, 18);
            this.año.TabIndex = 20;
            this.año.Text = "año";
            // 
            // txths
            // 
            this.txths.Location = new System.Drawing.Point(277, 379);
            this.txths.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txths.Name = "txths";
            this.txths.ReadOnly = true;
            this.txths.Size = new System.Drawing.Size(37, 24);
            this.txths.TabIndex = 19;
            // 
            // txtdia
            // 
            this.txtdia.Location = new System.Drawing.Point(231, 379);
            this.txtdia.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtdia.Name = "txtdia";
            this.txtdia.ReadOnly = true;
            this.txtdia.Size = new System.Drawing.Size(37, 24);
            this.txtdia.TabIndex = 18;
            // 
            // txtmes
            // 
            this.txtmes.Location = new System.Drawing.Point(184, 379);
            this.txtmes.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtmes.Name = "txtmes";
            this.txtmes.ReadOnly = true;
            this.txtmes.Size = new System.Drawing.Size(37, 24);
            this.txtmes.TabIndex = 17;
            // 
            // txtanio
            // 
            this.txtanio.Location = new System.Drawing.Point(137, 379);
            this.txtanio.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtanio.Name = "txtanio";
            this.txtanio.ReadOnly = true;
            this.txtanio.Size = new System.Drawing.Size(37, 24);
            this.txtanio.TabIndex = 16;
            // 
            // lbclienfecha
            // 
            this.lbclienfecha.AutoSize = true;
            this.lbclienfecha.Location = new System.Drawing.Point(8, 379);
            this.lbclienfecha.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbclienfecha.Name = "lbclienfecha";
            this.lbclienfecha.Size = new System.Drawing.Size(106, 18);
            this.lbclienfecha.TabIndex = 15;
            this.lbclienfecha.Text = "fecha de salida";
            // 
            // txtenvio
            // 
            this.txtenvio.Location = new System.Drawing.Point(144, 278);
            this.txtenvio.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtenvio.Name = "txtenvio";
            this.txtenvio.ReadOnly = true;
            this.txtenvio.Size = new System.Drawing.Size(132, 24);
            this.txtenvio.TabIndex = 14;
            // 
            // lbclienestado
            // 
            this.lbclienestado.AutoSize = true;
            this.lbclienestado.Location = new System.Drawing.Point(9, 290);
            this.lbclienestado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbclienestado.Name = "lbclienestado";
            this.lbclienestado.Size = new System.Drawing.Size(112, 18);
            this.lbclienestado.TabIndex = 13;
            this.lbclienestado.Text = "estado de envio";
            // 
            // lbclienlocalizar
            // 
            this.lbclienlocalizar.AutoSize = true;
            this.lbclienlocalizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbclienlocalizar.Location = new System.Drawing.Point(9, 20);
            this.lbclienlocalizar.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbclienlocalizar.Name = "lbclienlocalizar";
            this.lbclienlocalizar.Size = new System.Drawing.Size(186, 24);
            this.lbclienlocalizar.TabIndex = 12;
            this.lbclienlocalizar.Text = "Localizar Paquetes";
            this.lbclienlocalizar.Click += new System.EventHandler(this.label7_Click);
            // 
            // txtDemora
            // 
            this.txtDemora.Location = new System.Drawing.Point(204, 319);
            this.txtDemora.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDemora.Name = "txtDemora";
            this.txtDemora.ReadOnly = true;
            this.txtDemora.Size = new System.Drawing.Size(112, 24);
            this.txtDemora.TabIndex = 11;
            // 
            // lbcliendemora
            // 
            this.lbcliendemora.AutoSize = true;
            this.lbcliendemora.Location = new System.Drawing.Point(9, 326);
            this.lbcliendemora.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbcliendemora.Name = "lbcliendemora";
            this.lbcliendemora.Size = new System.Drawing.Size(164, 18);
            this.lbcliendemora.TabIndex = 10;
            this.lbcliendemora.Text = "Demora estimada (min)";
            this.lbcliendemora.Click += new System.EventHandler(this.label6_Click);
            // 
            // txtLote
            // 
            this.txtLote.Location = new System.Drawing.Point(143, 180);
            this.txtLote.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtLote.Name = "txtLote";
            this.txtLote.ReadOnly = true;
            this.txtLote.Size = new System.Drawing.Size(132, 24);
            this.txtLote.TabIndex = 9;
            // 
            // txtCamion
            // 
            this.txtCamion.Location = new System.Drawing.Point(144, 213);
            this.txtCamion.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtCamion.Name = "txtCamion";
            this.txtCamion.ReadOnly = true;
            this.txtCamion.Size = new System.Drawing.Size(132, 24);
            this.txtCamion.TabIndex = 8;
            // 
            // txtCamionero
            // 
            this.txtCamionero.Location = new System.Drawing.Point(144, 245);
            this.txtCamionero.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtCamionero.Name = "txtCamionero";
            this.txtCamionero.ReadOnly = true;
            this.txtCamionero.Size = new System.Drawing.Size(132, 24);
            this.txtCamionero.TabIndex = 7;
            // 
            // lbcliencamionero
            // 
            this.lbcliencamionero.AutoSize = true;
            this.lbcliencamionero.Location = new System.Drawing.Point(9, 249);
            this.lbcliencamionero.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbcliencamionero.Name = "lbcliencamionero";
            this.lbcliencamionero.Size = new System.Drawing.Size(86, 18);
            this.lbcliencamionero.TabIndex = 6;
            this.lbcliencamionero.Text = "Camionero:";
            // 
            // lbcliencamion
            // 
            this.lbcliencamion.AutoSize = true;
            this.lbcliencamion.Location = new System.Drawing.Point(9, 217);
            this.lbcliencamion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbcliencamion.Name = "lbcliencamion";
            this.lbcliencamion.Size = new System.Drawing.Size(64, 18);
            this.lbcliencamion.TabIndex = 5;
            this.lbcliencamion.Text = "Camion:";
            // 
            // lbcliendatos
            // 
            this.lbcliendatos.AutoSize = true;
            this.lbcliendatos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbcliendatos.ForeColor = System.Drawing.Color.Black;
            this.lbcliendatos.Location = new System.Drawing.Point(9, 143);
            this.lbcliendatos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbcliendatos.Name = "lbcliendatos";
            this.lbcliendatos.Size = new System.Drawing.Size(149, 18);
            this.lbcliendatos.TabIndex = 4;
            this.lbcliendatos.Text = "Datos del paquete:";
            // 
            // lbclienlote
            // 
            this.lbclienlote.AutoSize = true;
            this.lbclienlote.Location = new System.Drawing.Point(9, 186);
            this.lbclienlote.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbclienlote.Name = "lbclienlote";
            this.lbclienlote.Size = new System.Drawing.Size(41, 18);
            this.lbclienlote.TabIndex = 3;
            this.lbclienlote.Text = "Lote:";
            // 
            // btnIngresar
            // 
            this.btnIngresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIngresar.ForeColor = System.Drawing.Color.Green;
            this.btnIngresar.Location = new System.Drawing.Point(184, 85);
            this.btnIngresar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnIngresar.MaximumSize = new System.Drawing.Size(133, 28);
            this.btnIngresar.MinimumSize = new System.Drawing.Size(133, 28);
            this.btnIngresar.Name = "btnIngresar";
            this.btnIngresar.Size = new System.Drawing.Size(133, 28);
            this.btnIngresar.TabIndex = 2;
            this.btnIngresar.Text = "INGRESAR";
            this.btnIngresar.UseVisualStyleBackColor = true;
            this.btnIngresar.Click += new System.EventHandler(this.btnIngresar_Click);
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(184, 52);
            this.txtId.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(132, 24);
            this.txtId.TabIndex = 1;
            // 
            // lbclienid
            // 
            this.lbclienid.AutoSize = true;
            this.lbclienid.Location = new System.Drawing.Point(8, 55);
            this.lbclienid.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbclienid.Name = "lbclienid";
            this.lbclienid.Size = new System.Drawing.Size(147, 18);
            this.lbclienid.TabIndex = 0;
            this.lbclienid.Text = "Ingrese Id de paquete";
            // 
            // btnSalir
            // 
            this.btnSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.ForeColor = System.Drawing.Color.Red;
            this.btnSalir.Location = new System.Drawing.Point(397, 14);
            this.btnSalir.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(91, 36);
            this.btnSalir.TabIndex = 6;
            this.btnSalir.Text = "SALIR";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click_1);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.lbclien);
            this.panel1.Controls.Add(this.btnSalir);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(503, 63);
            this.panel1.TabIndex = 18;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // lbclien
            // 
            this.lbclien.AutoSize = true;
            this.lbclien.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbclien.ForeColor = System.Drawing.Color.White;
            this.lbclien.Location = new System.Drawing.Point(171, 18);
            this.lbclien.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbclien.Name = "lbclien";
            this.lbclien.Size = new System.Drawing.Size(144, 31);
            this.lbclien.TabIndex = 0;
            this.lbclien.Text = "ClLIENTE";
            this.lbclien.Click += new System.EventHandler(this.label12_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(997, 14);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 36);
            this.button1.TabIndex = 13;
            this.button1.Text = "SALIR";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // usuarioApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(503, 513);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "usuarioApp";
            this.Text = "Localizar paquete";
            this.Load += new System.EventHandler(this.usuarioApp_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbclienid;
        private System.Windows.Forms.TextBox txtDemora;
        private System.Windows.Forms.Label lbcliendemora;
        private System.Windows.Forms.TextBox txtLote;
        private System.Windows.Forms.TextBox txtCamion;
        private System.Windows.Forms.TextBox txtCamionero;
        private System.Windows.Forms.Label lbcliencamionero;
        private System.Windows.Forms.Label lbcliencamion;
        private System.Windows.Forms.Label lbcliendatos;
        private System.Windows.Forms.Label lbclienlote;
        private System.Windows.Forms.Button btnIngresar;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Label lbclienlocalizar;
        private System.Windows.Forms.TextBox txtenvio;
        private System.Windows.Forms.Label lbclienestado;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbclien;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label año;
        private System.Windows.Forms.TextBox txths;
        private System.Windows.Forms.TextBox txtdia;
        private System.Windows.Forms.TextBox txtmes;
        private System.Windows.Forms.TextBox txtanio;
        private System.Windows.Forms.Label lbclienfecha;
    }
}