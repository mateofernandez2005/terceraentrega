﻿namespace prueba
{
    partial class backofficeApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(backofficeApp));
            this.btnSalir = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.registroDeCamiones = new System.Windows.Forms.Button();
            this.registroDeAlmacenes = new System.Windows.Forms.Button();
            this.registroDePaquetes = new System.Windows.Forms.Button();
            this.registroDeUsuario = new System.Windows.Forms.Button();
            this.FormPrueba = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.FormPrueba.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSalir
            // 
            this.btnSalir.ForeColor = System.Drawing.Color.Red;
            this.btnSalir.Location = new System.Drawing.Point(290, 238);
            this.btnSalir.Margin = new System.Windows.Forms.Padding(2);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(79, 29);
            this.btnSalir.TabIndex = 5;
            this.btnSalir.Text = "SALIR";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.registroDeCamiones);
            this.panel1.Controls.Add(this.registroDeAlmacenes);
            this.panel1.Controls.Add(this.registroDePaquetes);
            this.panel1.Controls.Add(this.registroDeUsuario);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(138, 278);
            this.panel1.TabIndex = 14;
            // 
            // registroDeCamiones
            // 
            this.registroDeCamiones.Dock = System.Windows.Forms.DockStyle.Top;
            this.registroDeCamiones.FlatAppearance.BorderSize = 0;
            this.registroDeCamiones.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.registroDeCamiones.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.registroDeCamiones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.registroDeCamiones.ForeColor = System.Drawing.Color.White;
            this.registroDeCamiones.Location = new System.Drawing.Point(0, 114);
            this.registroDeCamiones.Name = "registroDeCamiones";
            this.registroDeCamiones.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.registroDeCamiones.Size = new System.Drawing.Size(138, 38);
            this.registroDeCamiones.TabIndex = 3;
            this.registroDeCamiones.Text = "Camiones";
            this.registroDeCamiones.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.registroDeCamiones.UseVisualStyleBackColor = true;
            this.registroDeCamiones.Click += new System.EventHandler(this.button4_Click);
            // 
            // registroDeAlmacenes
            // 
            this.registroDeAlmacenes.Dock = System.Windows.Forms.DockStyle.Top;
            this.registroDeAlmacenes.FlatAppearance.BorderSize = 0;
            this.registroDeAlmacenes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.registroDeAlmacenes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.registroDeAlmacenes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.registroDeAlmacenes.ForeColor = System.Drawing.Color.White;
            this.registroDeAlmacenes.Location = new System.Drawing.Point(0, 76);
            this.registroDeAlmacenes.Name = "registroDeAlmacenes";
            this.registroDeAlmacenes.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.registroDeAlmacenes.Size = new System.Drawing.Size(138, 38);
            this.registroDeAlmacenes.TabIndex = 2;
            this.registroDeAlmacenes.Text = "Almacenes";
            this.registroDeAlmacenes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.registroDeAlmacenes.UseVisualStyleBackColor = true;
            this.registroDeAlmacenes.Click += new System.EventHandler(this.button3_Click);
            // 
            // registroDePaquetes
            // 
            this.registroDePaquetes.Dock = System.Windows.Forms.DockStyle.Top;
            this.registroDePaquetes.FlatAppearance.BorderSize = 0;
            this.registroDePaquetes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.registroDePaquetes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.registroDePaquetes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.registroDePaquetes.ForeColor = System.Drawing.Color.White;
            this.registroDePaquetes.Location = new System.Drawing.Point(0, 38);
            this.registroDePaquetes.Name = "registroDePaquetes";
            this.registroDePaquetes.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.registroDePaquetes.Size = new System.Drawing.Size(138, 38);
            this.registroDePaquetes.TabIndex = 1;
            this.registroDePaquetes.Text = "Paquetes";
            this.registroDePaquetes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.registroDePaquetes.UseVisualStyleBackColor = true;
            this.registroDePaquetes.Click += new System.EventHandler(this.button2_Click);
            // 
            // registroDeUsuario
            // 
            this.registroDeUsuario.Dock = System.Windows.Forms.DockStyle.Top;
            this.registroDeUsuario.FlatAppearance.BorderSize = 0;
            this.registroDeUsuario.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.registroDeUsuario.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.registroDeUsuario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.registroDeUsuario.ForeColor = System.Drawing.Color.White;
            this.registroDeUsuario.Location = new System.Drawing.Point(0, 0);
            this.registroDeUsuario.Name = "registroDeUsuario";
            this.registroDeUsuario.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.registroDeUsuario.Size = new System.Drawing.Size(138, 38);
            this.registroDeUsuario.TabIndex = 0;
            this.registroDeUsuario.Text = "Usuarios";
            this.registroDeUsuario.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.registroDeUsuario.UseVisualStyleBackColor = true;
            this.registroDeUsuario.Click += new System.EventHandler(this.button1_Click);
            // 
            // FormPrueba
            // 
            this.FormPrueba.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.FormPrueba.Controls.Add(this.btnSalir);
            this.FormPrueba.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FormPrueba.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.FormPrueba.Location = new System.Drawing.Point(138, 0);
            this.FormPrueba.Name = "FormPrueba";
            this.FormPrueba.Size = new System.Drawing.Size(380, 278);
            this.FormPrueba.TabIndex = 4;
            // 
            // backofficeApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(518, 278);
            this.Controls.Add(this.FormPrueba);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "backofficeApp";
            this.Text = "Backoffice";
            this.Load += new System.EventHandler(this.backofficeApp_Load);
            this.panel1.ResumeLayout(false);
            this.FormPrueba.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Button registroDeCamiones;
        public System.Windows.Forms.Button registroDeAlmacenes;
        public System.Windows.Forms.Button registroDePaquetes;
        public System.Windows.Forms.Button registroDeUsuario;
        private System.Windows.Forms.Panel FormPrueba;
    }
}