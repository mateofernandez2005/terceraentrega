﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace prueba


{
    public partial class loginUsuario : Form
    {
        public loginUsuario()
        {
            InitializeComponent();
        }
        SqlConnection conexion = new SqlConnection("server=proyecto; database=empresa; integrated security=true");
        private void btnEntrar_Click(object sender, EventArgs e)
        {
            conexion.Open();
            string consulta = "select * from usuario where usuario= '" + txtUsuario.Text + "'and contraseña='" + txtContraseña.Text + "'";
            SqlCommand comando = new SqlCommand(consulta, conexion);
            SqlDataReader lector;
            lector = comando.ExecuteReader();


            if (lector.HasRows == true)
            {
                MessageBox.Show("bienvenido" + txtUsuario.Text);
                usuarioApp frmUsuarioApp = new usuarioApp();
                this.Hide();
                frmUsuarioApp.Show();
            }
            else
            {
                MessageBox.Show("usuario o contraseña erronea");
            }
            conexion.Close();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            menu frmMenu = new menu();
            this.Hide();
            frmMenu.Show();
        }
    }
    }

