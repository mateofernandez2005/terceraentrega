﻿using System;

namespace prueba
{
    partial class Menu
    {
       
        private System.ComponentModel.IContainer components = null;

        
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.cliente = new System.Windows.Forms.Button();
            this.panelAppSubMenu = new System.Windows.Forms.Panel();
            this.backoffice = new System.Windows.Forms.Button();
            this.camionero = new System.Windows.Forms.Button();
            this.almacenero = new System.Windows.Forms.Button();
            this.btnApps = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.logoutToolStripMenuItem = new System.Windows.Forms.Button();
            this.backoficeToolStripMenuItem = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnidioma = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panelAppSubMenu.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.AutoScroll = true;
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.Black;
            this.splitContainer1.Panel1.Controls.Add(this.button1);
            this.splitContainer1.Panel1.Controls.Add(this.cliente);
            this.splitContainer1.Panel1.Controls.Add(this.btnidioma);
            this.splitContainer1.Panel1.Controls.Add(this.panelAppSubMenu);
            this.splitContainer1.Panel1.Controls.Add(this.btnApps);
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            this.splitContainer1.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Panel1_Paint);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.splitContainer1.Panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Panel2_Paint);
            this.splitContainer1.Size = new System.Drawing.Size(634, 361);
            this.splitContainer1.SplitterDistance = 146;
            this.splitContainer1.TabIndex = 0;
            // 
            // cliente
            // 
            this.cliente.Dock = System.Windows.Forms.DockStyle.Top;
            this.cliente.FlatAppearance.BorderSize = 0;
            this.cliente.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.cliente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.cliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cliente.ForeColor = System.Drawing.Color.White;
            this.cliente.Location = new System.Drawing.Point(0, 191);
            this.cliente.Name = "cliente";
            this.cliente.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.cliente.Size = new System.Drawing.Size(146, 37);
            this.cliente.TabIndex = 3;
            this.cliente.Text = "Cliente";
            this.cliente.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cliente.UseVisualStyleBackColor = true;
            this.cliente.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // panelAppSubMenu
            // 
            this.panelAppSubMenu.Controls.Add(this.backoffice);
            this.panelAppSubMenu.Controls.Add(this.camionero);
            this.panelAppSubMenu.Controls.Add(this.almacenero);
            this.panelAppSubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelAppSubMenu.Location = new System.Drawing.Point(0, 121);
            this.panelAppSubMenu.Name = "panelAppSubMenu";
            this.panelAppSubMenu.Size = new System.Drawing.Size(146, 70);
            this.panelAppSubMenu.TabIndex = 2;
            this.panelAppSubMenu.Paint += new System.Windows.Forms.PaintEventHandler(this.panelAppSubMenu_Paint);
            // 
            // backoffice
            // 
            this.backoffice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.backoffice.Dock = System.Windows.Forms.DockStyle.Top;
            this.backoffice.FlatAppearance.BorderSize = 0;
            this.backoffice.FlatAppearance.MouseDownBackColor = System.Drawing.Color.CornflowerBlue;
            this.backoffice.FlatAppearance.MouseOverBackColor = System.Drawing.Color.CornflowerBlue;
            this.backoffice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.backoffice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backoffice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.backoffice.Location = new System.Drawing.Point(0, 46);
            this.backoffice.Name = "backoffice";
            this.backoffice.Padding = new System.Windows.Forms.Padding(25, 0, 0, 0);
            this.backoffice.Size = new System.Drawing.Size(146, 24);
            this.backoffice.TabIndex = 5;
            this.backoffice.Text = "Backoffice";
            this.backoffice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.backoffice.UseVisualStyleBackColor = false;
            this.backoffice.Click += new System.EventHandler(this.button3_Click);
            // 
            // camionero
            // 
            this.camionero.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.camionero.Dock = System.Windows.Forms.DockStyle.Top;
            this.camionero.FlatAppearance.BorderSize = 0;
            this.camionero.FlatAppearance.MouseDownBackColor = System.Drawing.Color.CornflowerBlue;
            this.camionero.FlatAppearance.MouseOverBackColor = System.Drawing.Color.CornflowerBlue;
            this.camionero.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.camionero.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.camionero.ForeColor = System.Drawing.Color.White;
            this.camionero.Location = new System.Drawing.Point(0, 23);
            this.camionero.Name = "camionero";
            this.camionero.Padding = new System.Windows.Forms.Padding(25, 0, 0, 0);
            this.camionero.Size = new System.Drawing.Size(146, 23);
            this.camionero.TabIndex = 4;
            this.camionero.Text = "Camionero";
            this.camionero.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.camionero.UseVisualStyleBackColor = false;
            this.camionero.Click += new System.EventHandler(this.button2_Click);
            // 
            // almacenero
            // 
            this.almacenero.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.almacenero.Dock = System.Windows.Forms.DockStyle.Top;
            this.almacenero.FlatAppearance.BorderSize = 0;
            this.almacenero.FlatAppearance.MouseDownBackColor = System.Drawing.Color.CornflowerBlue;
            this.almacenero.FlatAppearance.MouseOverBackColor = System.Drawing.Color.CornflowerBlue;
            this.almacenero.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.almacenero.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.almacenero.ForeColor = System.Drawing.Color.White;
            this.almacenero.Location = new System.Drawing.Point(0, 0);
            this.almacenero.Name = "almacenero";
            this.almacenero.Padding = new System.Windows.Forms.Padding(25, 0, 0, 0);
            this.almacenero.Size = new System.Drawing.Size(146, 23);
            this.almacenero.TabIndex = 3;
            this.almacenero.Text = "Almacenero";
            this.almacenero.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.almacenero.UseVisualStyleBackColor = false;
            this.almacenero.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnApps
            // 
            this.btnApps.BackColor = System.Drawing.Color.Black;
            this.btnApps.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnApps.FlatAppearance.BorderSize = 0;
            this.btnApps.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnApps.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnApps.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnApps.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnApps.ForeColor = System.Drawing.Color.White;
            this.btnApps.Location = new System.Drawing.Point(0, 84);
            this.btnApps.Name = "btnApps";
            this.btnApps.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnApps.Size = new System.Drawing.Size(146, 37);
            this.btnApps.TabIndex = 1;
            this.btnApps.Text = "Apps";
            this.btnApps.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnApps.UseVisualStyleBackColor = false;
            this.btnApps.Click += new System.EventHandler(this.btnApps_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.logoutToolStripMenuItem);
            this.panel1.Controls.Add(this.backoficeToolStripMenuItem);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(146, 84);
            this.panel1.TabIndex = 0;
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.logoutToolStripMenuItem.Location = new System.Drawing.Point(3, 46);
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(144, 32);
            this.logoutToolStripMenuItem.TabIndex = 1;
            this.logoutToolStripMenuItem.Text = "Logout";
            this.logoutToolStripMenuItem.UseVisualStyleBackColor = true;
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.Logout_Click);
            // 
            // backoficeToolStripMenuItem
            // 
            this.backoficeToolStripMenuItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backoficeToolStripMenuItem.ForeColor = System.Drawing.Color.LimeGreen;
            this.backoficeToolStripMenuItem.Location = new System.Drawing.Point(3, 3);
            this.backoficeToolStripMenuItem.MaximumSize = new System.Drawing.Size(144, 32);
            this.backoficeToolStripMenuItem.MinimumSize = new System.Drawing.Size(144, 32);
            this.backoficeToolStripMenuItem.Name = "backoficeToolStripMenuItem";
            this.backoficeToolStripMenuItem.Size = new System.Drawing.Size(144, 32);
            this.backoficeToolStripMenuItem.TabIndex = 0;
            this.backoficeToolStripMenuItem.Text = "Login";
            this.backoficeToolStripMenuItem.UseVisualStyleBackColor = true;
            this.backoficeToolStripMenuItem.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.Location = new System.Drawing.Point(0, 303);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(146, 29);
            this.button1.TabIndex = 4;
            this.button1.Text = "Español";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_3);
            // 
            // btnidioma
            // 
            this.btnidioma.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnidioma.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnidioma.FlatAppearance.BorderSize = 0;
            this.btnidioma.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnidioma.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnidioma.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnidioma.Location = new System.Drawing.Point(0, 332);
            this.btnidioma.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnidioma.Name = "btnidioma";
            this.btnidioma.Size = new System.Drawing.Size(146, 29);
            this.btnidioma.TabIndex = 0;
            this.btnidioma.Text = "English";
            this.btnidioma.UseVisualStyleBackColor = false;
            this.btnidioma.Click += new System.EventHandler(this.btnidioma_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(634, 361);
            this.Controls.Add(this.splitContainer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Name = "Menu";
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.Menu_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.panelAppSubMenu.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        private void Menu_Load(object sender, EventArgs e)
        {
        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel panelAppSubMenu;
        private System.Windows.Forms.Button btnApps;
        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Button backoffice;
        public System.Windows.Forms.Button camionero;
        public System.Windows.Forms.Button almacenero;
        private System.Windows.Forms.Button backoficeToolStripMenuItem;
        private System.Windows.Forms.Button logoutToolStripMenuItem;
        public System.Windows.Forms.Button cliente;
        private System.Windows.Forms.Button btnidioma;
        private System.Windows.Forms.Button button1;
    }
}

