﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.Json;
namespace prueba
{
     class Program
    {


        
            //protected ADODB.Connection cn;

            // Este es tu método envoltorio
           // public ADODB.Connection GetConnection()
           // {
              //  return cn;
           // }
        protected ADODB.Connection _conexion;

        public static ADODB.Connection cn = new ADODB.Connection();
        public ADODB.Connection conexion
        {
            get { return (_conexion); }
            set { _conexion = value; }
        }

       



       
    

        public Program()
        {
            
        }

       
        


        public static Menu frmMenu;
        


        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(frmMenu = new Menu());
        }

       


        }





        public static class variables
        {
            public static int registro = 0;
        public static bool idiom = false;
        }

    public static class GlobalVariables
    {

        public static bool IsRadioButtonChecked { get; set; }
      
    }






}
    




