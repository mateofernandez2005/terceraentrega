﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using System.Data;

namespace prueba
{
    static class apiTransito
    {
        internal class camionL
        {
            public String matricula { set; get; }
            public int id { set; get; }
           
            protected List<Int32> _data;
            protected List<Tuple<Int32, double, double, double>> _dataordenada;

            public camionL()
            {
                _data = new List<Int32>();
                _dataordenada = new List<Tuple<Int32, double, double, double>>();
            }
            public List<Int32> data
            {
                get { return (_data); }
                set { _data = value; }
            }
            public List<Tuple<Int32, double, double, double>> dataordenada
            {
                get { return (_dataordenada); }
                set { _dataordenada = value; }
            }
        }

       

        internal class clientePaquete
        {
            public int idbulto { set; get; }
            public int idlote { set; get; }
            public string matricula { set; get; }
            public string nombrecamionero { set; get; }
            public string apellidocamionero { set; get; }
            public string estadodeenvio { set; get; }
            public double demora { set; get; }
            public int anio { set; get; }
            public int mes { set; get; }
            public int dia { set; get; }
            public int hora { set; get; }

        }

        public static String registroLotes(String matriculas)
        {
           
            List<Int32> lista;
            
            String resultado;

            camionL lc = new camionL();
            camionLote cl = new camionLote();
            Paquete p = new Paquete();
            Almacen a = new Almacen();
            Usuario U = new Usuario();
            lc = JsonSerializer.Deserialize<camionL>(matriculas); /////

            cl.matricula = lc.matricula;
            cl.id = lc.id;

            List<Tuple<Int32, double, double, double>> listaordenada = cl.obtenerbultosCamionero();
            lc.dataordenada = listaordenada;
            lista = cl.obtenerLotesCamionero();
            lc.data = lista;
            //lc.matricula = cl.matricula;
            lc.id = cl.id;
            
            resultado = JsonSerializer.Serialize(lc);
            return (resultado);
        }

        public static String registrodatos(String datos)
        {

            string resultado="";
            int idlote;
            string matricula;
            string nombrecamionero;
            string apellidocamionero;
            string estadodeenvio; 
            DateTime? fecha;
            clientePaquete cp = new clientePaquete();
            Paquete p = new Paquete();
            Almacen a = new Almacen();
            Usuario U = new Usuario();
            cp = JsonSerializer.Deserialize<clientePaquete>(datos); /////

            p.id = cp.idbulto;
            //cl.id = lc.id;


            idlote = p.obtenerIdLote();
            matricula = p.obtenerMatriculaCamion();
            nombrecamionero = p.obtenerNombreCamionero();
            apellidocamionero = p.obtenerApellidoCamionero();
            estadodeenvio = p.obtenerEstadoDeEnvio();

            fecha = p.obtenerfecha();

            //if (fecha.HasValue)
            //{
            //    int año = fecha.Value.Year;
            //    int mes = fecha.Value.Month;
            //    int dia = fecha.Value.Day;
            //    int hora = fecha.Value.Hour;
            //}

            fecha = p.obtenerfecha();

            if (fecha.HasValue)
            {
                cp.anio = fecha.Value.Year;
                cp.mes = fecha.Value.Month;
                cp.dia = fecha.Value.Day;
                cp.hora = fecha.Value.Hour;

            }   
            

            cp.estadodeenvio = estadodeenvio;
            cp.idlote = idlote;
            cp.matricula = matricula;
            cp.nombrecamionero = nombrecamionero;
            cp.apellidocamionero = apellidocamionero;

            


            a.id = p.id;
            (double longitud, double latitud) = a.ObtenerLongitudLatitudAlmacen();
          
            

            U.ci = p.id;
            (double clongitud, double clatitud) = U.ObtenerLongitudLatitudCliente();
           
            

            double distance = CalculateDistance(latitud, longitud, clatitud, clongitud);


            cp.demora = distance / 1.16;

           
            resultado = JsonSerializer.Serialize(cp);
            return (resultado);



            double CalculateDistance(double lat1, double lon1, double lat2, double lon2)
            {
                double r = 6371; // radio de la Tierra en km

                
                lat1 = lat1 * Math.PI / 180;
                lon1 = lon1 * Math.PI / 180;
                lat2 = lat2 * Math.PI / 180;
                lon2 = lon2 * Math.PI / 180;

                double dLat = lat2 - lat1;
                double dLon = lon2 - lon1;

                double res = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
                            Math.Cos(lat1) * Math.Cos(lat2) *
                            Math.Sin(dLon / 2) * Math.Sin(dLon / 2);

                double c = 2 * Math.Atan2(Math.Sqrt(res), Math.Sqrt(1 - res));

                return r * c;
            }


        }
        internal class paqueteEntrega
        {

            public int id { set; get; }
            public int result { set; get; }
            public int resu { set; get; }
            public int devolucion { set; get; }
        }

        public static String entrega(String entre)
        {
            string resultado;
            int id;
            paqueteEntrega pe = new paqueteEntrega();
            Paquete p = new Paquete();
            BultoLote bl = new BultoLote();
            pe = JsonSerializer.Deserialize<paqueteEntrega>(entre); /////

            p.id = pe.id;
            


            pe.devolucion = p.entrega();


            
        

            

            resultado = JsonSerializer.Serialize(pe);
            return (resultado);




        }

    }
}
