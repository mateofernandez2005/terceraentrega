﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prueba
{
    public partial class RegistroUsuarioApp : Form
    {
        public RegistroUsuarioApp()
        {
            InitializeComponent();
            panelListaUsuarios.Visible = false;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;
            btnRegistrar.Enabled = false;
            Usuario U = new Usuario();
            gridusuarios.DataSource = U.ObtenerDatosUsuario();

            if (variables.idiom == true)
            {
                lbbousulistas.Text = "Lists";
                lbbousulistausuario.Text = "User List";
                lbbousuregistro.Text = "User Registration";
                lbbousuusuario.Text = "Enter username:";
                contrasenia.Text = "Enter password:";
                lbbousurol.Text = "Ingrese rol:";
                lbbousuci.Text = "Enter ci:";
                lbbousunombre.Text = "Enter name:";
                cc.Text = "Enter last name:";
                lbbousuidioma.Text = "enter lenguage";
                lbbousucelular.Text = "enter cell phone number:";
                lbbousulongitud.Text = "Enter length:";
                lbbousulatitud.Text = "Enter latitude:";
                label1.Text = "enter latitude and longitude with dot(.)";
                btnSalir.Text = "exit";
                btnbuscar.Text = "search";
                btnlimpiar.Text = "clean";
                btnRegistrar.Text = "register";
                btnEliminar.Text = "delete";
                btnModificar.Text = "modify";
            }

            }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            backofficeApp frmbackofficeApp = new backofficeApp();
            this.Hide();
            frmbackofficeApp.Show();
        }

        private void RegistroUsuarioApp_Load(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            Usuario U = new Usuario();

            string ci = txtCi.Text;
            String rol = comborol.Text;
            String celular = txtNum.Text;
            string apellido = txtApellido.Text;
            string nombre = txtNombre.Text;
            string idioma = comboidioma.Text;
            string usuario = txtUsuario.Text;
            string longitud = txtlongitud.Text;
            string latitud = txtlatitud.Text;

            double flongitud;
            bool isLongitudValid = double.TryParse(longitud, out flongitud);
            if (!isLongitudValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The provided length is not a valid number. Do not use ',' use '.' ");
                }
                else
                {
                    Console.WriteLine("La longitud proporcionada no es un número válido. No utilice ',' utilice '.' ");
                }
            }

            double flatitud;
            bool isLatitudValid = double.TryParse(latitud, out flatitud);
            if (!isLatitudValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The provided latitude is not a valid number. Do not use ',' use '.'");
                }
                else
                {
                    Console.WriteLine("La latitud proporcionada no es un número válido. No utilice ',' utilice '.'");
                }
            }

            int intci;
            bool isCiValid = int.TryParse(ci, out intci);
            if (!isCiValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The data type of ci is not valid, only numbers.");
                }
                else
                {
                    Console.WriteLine("El tipo de dato de ci no es valido, solo numeros.");
                }
            }


            if (idioma == "español")
            {
                U.idIdioma = 1;
            }
            else if (rol == "ingles")
            {
                U.idIdioma = 2;
            }


            if (rol == "cliente")
            {
                U.rol = 4;
            }
            else if(rol == "backoffice")
            {
                U.rol = 3;
            }
            else if (rol == "camionero")
            {
                U.rol = 2;
            }
            else if (rol == "almacenero")
            {
                U.rol = 1;
            }
            U.ci = intci;
            
            U.celular = celular;
            U.apellido = apellido;
            U.nombre = nombre;
            U.usuario = usuario;
            U.latitud = flatitud;
            U.longitud = flongitud;


            int devolucion = U.modificarUsario();
            if (devolucion == 1) //eror al buscarlo 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, check the data");
                }
                else
                {
                    MessageBox.Show("Error, revise los datos");
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The user was not found, nothing to modify");
                }
                else
                {
                    MessageBox.Show("no se encontro el usuario, nada para modificar ");
                }

            }

            else if (devolucion == 3) //ENcontramos el paquete 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Modified correctly");
                }
                else
                {
                    MessageBox.Show("se modifico correctamente ");
                }



            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Connection closed");
                }
                else
                {
                    MessageBox.Show("conexion cerrada  ");
                }
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            Usuario U = new Usuario();

            string ci = txtCi.Text;
            int intci = int.Parse(ci);
            U.ci = intci;


            int devolucion = U.eliminarUsuario();
            if (devolucion == 3)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Deleted correctly");
                }
                else
                {
                    MessageBox.Show("se elimino correctamente");
                }
            }
            else if (devolucion == 1)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error searching for the user, check the data");
                }
                else
                {
                    MessageBox.Show("Error al buscar el usuario, revise los datos");
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The user was not found, nothing to delete");
                }
                else
                {
                    MessageBox.Show("no se encontro el usuario, nada para eliminar ");
                }

            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Resounding error");
                }
                else
                {
                    MessageBox.Show("error rotundo ");
                }
            }
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {

            Usuario U = new Usuario();

            string longitud = txtlongitud.Text;
            string latitud = txtlatitud.Text;
            string ci = txtCi.Text;
            String rol = comborol.Text;
            String celular = txtNum.Text;
            string apellido = txtApellido.Text;
            string nombre = txtNombre.Text;
            string idioma = comboidioma.Text;
            string ususario = txtUsuario.Text;
            string contrasenia = txtContraseña.Text;


            double flongitud;
            bool isLongitudValid = double.TryParse(longitud, out flongitud);
            if (!isLongitudValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The provided length is not a valid number. Do not use ',' use '.' ");
                }
                else
                {
                    Console.WriteLine("La longitud proporcionada no es un número válido. No utilice ',' utilice '.' ");
                }
            }

            double flatitud;
            bool isLatitudValid = double.TryParse(latitud, out flatitud);
            if (!isLatitudValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The provided latitude is not a valid number. Do not use ',' use '.'");
                }
                else
                {
                    Console.WriteLine("La latitud proporcionada no es un número válido. No utilice ',' utilice '.'");
                }
            }

            int intci;
            bool isCiValid = int.TryParse(ci, out intci);
            if (!isCiValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The data type of ci is not valid, only numbers.");
                }
                else
                {
                    Console.WriteLine("El tipo de dato de ci no es valido, solo numeros.");
                }
            }

            if (idioma == "español")
            {
                U.idIdioma = 1;
            }
            else if (rol == "ingles")
            {
                U.idIdioma = 2;
            }



            if (rol == "cliente")
            {
                U.rol = 4;
            }
            else if (rol == "backoffice")
            {
                U.rol = 3;
            }
            else if (rol == "camionero")
            {
                U.rol = 2;
            }
            else if (rol == "almacenero")
            {
                U.rol = 1;
            }

            U.ci = intci;
          
            U.celular = celular;
            U.apellido = apellido;
            U.nombre = nombre;
            U.usuario = ususario;
            U.contrasenia = contrasenia;
            U.latitud = flatitud;
            U.longitud = flongitud;

            int devolucion = U.registrarUsuario();

            if (devolucion == 1) //eror al buscarlo 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, check the data");
                }
                else
                {
                    MessageBox.Show("Error, revise los datos");
                }
            }
           

            else if (devolucion == 3) //ENcontramos el paquete 
            {
                 string nomrol="";
                if (U.rol == 3)
                {
                    nomrol = "backoffice";
                }
                else if(U.rol==1)
                {
                    nomrol = "almacenero";
                }
                else if (U.rol==2)
                {
                    nomrol = "camionero";
                }

                if (variables.idiom == true)
                {
                    MessageBox.Show("The user " + U.usuario + " whose role is " + nomrol + " was registered and created correctly");
                }
                else
                {
                    MessageBox.Show("Se registró y creó correctamente el usuario " + U.usuario + " cuyo rol es " + nomrol);
                }




            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Connection closed");
                }
                else
                {
                    MessageBox.Show("conexion cerrada  ");
                }
            }

        }

        private void btnbuscar_Click(object sender, EventArgs e)
        {

            Usuario U = new Usuario();


            string nombreUsuario = txtUsuario.Text;
            
            U.usuario = nombreUsuario;


            int devolucion = U.buscarUsuario();
            if (devolucion == 1) //eror al buscarlo 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error searching for the ci");
                }
                else
                {
                    MessageBox.Show("Error al buscar el ci");
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The user was not found, if you want to add it press register");
                }
                else
                {
                    MessageBox.Show("no se encontro el ususario, si desea añadirlo apriete registrar");
                }
                btnRegistrar.Enabled = true;
                btnEliminar.Enabled = false;
                btnModificar.Enabled = false;
            }

            else if (devolucion == 3) //ENcontramos el paquete 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The user was found, do you want to delete or modify it?");
                }
                else
                {
                    MessageBox.Show("se encontro el ususario, desea eliminarlo o modificarlo?");
                }
                U.registrardDatos();
                string ci = U.ci.ToString();
                txtCi.Text = ci;

                txtlatitud.Text = U.latitud.ToString();
                txtlongitud.Text = U.longitud.ToString();

                string celular = U.celular;
                txtNum.Text = celular;
                string apellido = U.apellido;
                txtApellido.Text = apellido;
                string nombre = U.nombre;
                txtNombre.Text = nombre;
                
                btnEliminar.Enabled = true;
                btnModificar.Enabled = true;
                btnRegistrar.Enabled = false;

                string idioma = U.idIdioma.ToString();
                comboidioma.Text = idioma;
                if (idioma == "1")
                {
                    comboidioma.Text = "español";
                }
                else if (idioma == "2")
                {
                    comboidioma.Text = "ingles";
                }

                string rol = U.rol.ToString();
                comborol.Text = rol;
                if (rol == "4")
                {
                    comborol.Text = "cliente";
                }
                else if (rol == "3")
                {
                    comborol.Text = "backoffice";
                }
                else if (rol == "2")
                {
                    comborol.Text = "camionero";
                }
                else if (rol == "1")
                {
                    comborol.Text = "almacenero";
                }
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Resounding error");
                }
                else
                {
                    MessageBox.Show("error rotundo ");
                }
            }



















        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnlimpiar_Click(object sender, EventArgs e)
        {
            txtApellido.Text = null;
            txtCi.Text = null;
            txtContraseña.Text = null;
            comboidioma.Text = null;
            txtNombre.Text = null;
            txtNum.Text = null;
            comborol.Text = null;
            txtUsuario.Text = null;
            txtlongitud.Text = null;
            txtlatitud.Text = null;
        }

        private void gridusuarios_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            backofficeApp frmbackofficeApp = new backofficeApp();
            this.Hide();
            frmbackofficeApp.Show();
        }


        private void customizeDesign()
        {
            panelListaUsuarios.Visible = false;
        }

        private void hideSubMenu()
        {
            if (panelListaUsuarios.Visible == true)
                panelListaUsuarios.Visible = false;
        }

        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            showSubMenu(panelListaUsuarios);
        }
    }
}
