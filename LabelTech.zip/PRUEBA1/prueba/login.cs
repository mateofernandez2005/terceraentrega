﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.Json;


namespace prueba
{
    


    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
            //Menu frmmenu = new Menu();
            //if (frmmenu.IsRadioButton1Checked)
            //{

            //}

            

            if (variables.idiom == true)
            {
                lblogusuario.Text = "user";
                lblogcontra.Text = "password";
                btnEntrar.Text = "enter";
                btnSalir.Text = "exit";
            }

        }
        internal class usupass
        {
           public String usuario { set; get; }
            public String contraseña { set; get; }

        }

        internal class usurol
        {
            public String usuario { set; get; }
            public byte rol { set; get; }
        }



        private void btnEntrar_Click(object sender, EventArgs e)
        {
           
            Menu frmMenu = new Menu();
            Usuario u = new Usuario();
            Program P = new Program();

            String upSerializado;
            String resultado;
            usupass up = new usupass();
            usurol ur;

            if (string.IsNullOrEmpty(txtContraseña.Text) || string.IsNullOrEmpty(txtUsuario.Text))
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Incorrect username or password");
                }
                else
                {
                    MessageBox.Show("usuario o contraseña incorrectas");
                }
            }
            else
            {
                Console.WriteLine("hola");
                up.usuario = txtUsuario.Text;
            up.contraseña = txtContraseña.Text;
            upSerializado = JsonSerializer.Serialize(up);
            
            resultado = apiAutenticacion.ValidoUsuario(upSerializado);
            
            upSerializado = JsonSerializer.Serialize(up);
            resultado = apiAutenticacion.ValidoUsuario(upSerializado);
            ur = JsonSerializer.Deserialize<usurol>(resultado);
            
            if (ur.usuario == up.usuario && ur.rol > 0)
            {
                switch (ur.rol)
                {
                    case 1:
                        frmMenu.almacenero.Enabled = true;
                            if (variables.idiom == true)
                            {
                                MessageBox.Show("Registered as a warehouse worker");
                            }
                            else
                            {
                                MessageBox.Show("se registro como almacenero");
                            }
                            almaceneroApp frmalmaceneroApp = new almaceneroApp();
                        frmMenu.Hide();
                        frmalmaceneroApp.Show();
                        variables.registro = 1;
                        this.Hide();
                        break;
                    case 2:
                        frmMenu.camionero.Enabled = true;
                            if (variables.idiom == true)
                            {
                                MessageBox.Show("Registered as a truck driver");
                            }
                            else
                            {
                                MessageBox.Show("se registro como camionero");
                            }
                            camioneroApp frmcamioneroApp = new camioneroApp();
                        frmMenu.Hide();
                        frmcamioneroApp.Show();
                        variables.registro = 2;
                        this.Hide();
                        break;
                    case 3:
                        frmMenu.almacenero.Enabled = true;
                        frmMenu.camionero.Enabled = true;
                        frmMenu.backoffice.Enabled = true;
                            if (variables.idiom == true)
                            {
                                MessageBox.Show("Registered as backoffice");
                            }
                            else
                            {
                                MessageBox.Show("se registro como backoffice");
                            }
                            backofficeApp frmbackofficeApp = new backofficeApp();
                        frmMenu.Hide();
                        frmbackofficeApp.Show();
                        variables.registro = 3;
                        
                        this.Hide();
                        break;
                        
                }
            }
            else
            {
                    if (variables.idiom == true)
                    {
                        MessageBox.Show("Incorrect username or password");
                    }
                    else
                    {
                        MessageBox.Show("usuario o contraseña incorrectas");
                    }
                }

            }

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {

            Menu frmMenu = new Menu();
            this.Hide();
            frmMenu.Show();



        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void login_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
    }

