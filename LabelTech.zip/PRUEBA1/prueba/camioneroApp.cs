﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.Json;
using System.Data;

namespace prueba
{
    public partial class camioneroApp : Form
    {
        public camioneroApp()
        {
            InitializeComponent();
            if (variables.idiom == true)
            {

                gbcamion.Text = "information of the truck";
                lbCammatricula.Text = "Enter truck registration:";
                btnRegistrar.Text = "register";
                lbCamlotes.Text = "Lots assigned to your truck:";
                lbCamdestinos.Text = "Delivery destinations due to distance:";
                button1.Text = "register";
                gbentrega.Text = "Packages delivered";
                lbCamentrega.Text = "Enter delivered package ID:";
                lbCam.Text = "truck driver";
                btnSalir.Text = "exit";



            }
        }

        internal class camionL
        {
            public String matricula { set; get; }
            public int id { set; get; }

            protected List<Int32> _data;
            protected List<Tuple<Int32, double, double, double>> _dataordenada;

            public camionL()
            {
                _data = new List<Int32>();
                _dataordenada = new List<Tuple<Int32, double, double, double>>();
            }
            public List<Int32> data
            {
                get { return (_data); }
                set { _data = value; }
            }
            public List<Tuple<Int32, double, double, double>> dataordenada
            {
                get { return (_dataordenada); }
                set { _dataordenada = value; }
            }
        }

        private void camioneroApp_Load(object sender, EventArgs e)
        {

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
           
        }

        private void btnSalir_Click_1(object sender, EventArgs e)
        {
            Menu frmMenu = new Menu();
            this.Hide();
            frmMenu.Show();
        }

        private void btnIngresarMatricula_Click(object sender, EventArgs e)
        {
           





                }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            camionLote cl = new camionLote();


            Menu frmMenu = new Menu();


            String lcSerializado;
            String resultado;
            camionL lc = new camionL();
            camionL lcc;
            cl.id = lc.id;
            lc.matricula = txtMatricula.Text;
            cl.matricula = txtMatricula.Text;
            //lcSerializado = JsonSerializer.Serialize(lc);

            //resultado = apiTransito.registroLotes(lcSerializado);

            lcSerializado = JsonSerializer.Serialize(lc);
            resultado = apiTransito.registroLotes(lcSerializado);
            lcc = JsonSerializer.Deserialize<camionL>(resultado);

            DataTable dt = new DataTable();


            if (lcc.data.Count == 0)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The truck was not found");
                }
                else
                {
                    MessageBox.Show("no se encontro el camion");
                }
                gridlotes.DataSource = null;
            }
            else
            {
                dt.Columns.Add("id_lote", typeof(Int32));
                foreach (Int32 i in lcc.data)
                {
                    dt.Rows.Add(i);
                }

            }
            gridlotes.DataSource = dt;

            DataTable dtordenada = new DataTable();

            if (lcc.dataordenada.Count == 0)
            {
                
                gridbultos.DataSource = null;
            }
            else
            {
                dtordenada.Columns.Add("id_bulto", typeof(Int32));
                dtordenada.Columns.Add("longitud", typeof(double));
                dtordenada.Columns.Add("latitud", typeof(double));
                dtordenada.Columns.Add("distancia en km", typeof(double));

                foreach (Tuple<Int32, double, double, double> t in lcc.dataordenada)
                {
                    dtordenada.Rows.Add(t.Item1, t.Item2, t.Item3, t.Item4);
                }
            }
            gridbultos.DataSource = dtordenada;

        }
        internal class paqueteEntrega
        {
            
            public int id { set; get; }
            public int result { set; get; }
            public int resu { set; get; }
            public int devolucion { set; get; }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Paquete p = new Paquete();


            Menu frmMenu = new Menu();


            String peSerializado;
            String resultado;
            paqueteEntrega pe = new paqueteEntrega();
            paqueteEntrega pee;

            string sid = txtIdPaquete.Text;
            int intid;
            bool isIdValid = int.TryParse(sid, out intid);
            if (!isIdValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The id type is not valid");
                }
                else
                {
                    Console.WriteLine("El tipo de id no es valido");
                }
            }

            pe.id = intid;
            p.id = pe.id;

            

            peSerializado = JsonSerializer.Serialize(pe);
            resultado = apiTransito.entrega(peSerializado);
            pee = JsonSerializer.Deserialize<paqueteEntrega>(resultado);


            

            switch (pee.devolucion)
            {
                case 3:


                    if (variables.idiom == true)
                    {
                        MessageBox.Show("Delivery registered correctly, thank you very much");
                    }
                    else
                    {
                        MessageBox.Show("entrega registrada correctamente, muchas gracias");
                    }

                    break;
                case 2:
                    if (variables.idiom == true)
                    {
                        MessageBox.Show("The package you want to enter was not found, check if everything is fine");
                    }
                    else
                    {
                        MessageBox.Show("no se encontro el paquete que desea ingresar, chequee si esta todo bien");
                    }

                    break;
                default:
                    MessageBox.Show("error");
                    break;
            }

        }


            private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
    }

