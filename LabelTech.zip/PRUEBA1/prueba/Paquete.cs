﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace prueba
{
    class Paquete
    {
        protected int _id;
        protected string _nombre;
        protected float _pesokg;
        protected float _volumen;
        protected int _ciCliente;
        protected String _estadoEnvio;
        protected ADODB.Connection _conexion;

        Program P = new Program();

        public Paquete()
        {
            _conexion = Program.cn;
            _id = 0;
            _nombre = "";
            _pesokg = 0;
            _volumen = 0;
            _ciCliente = 0;
            _estadoEnvio = "";

        }

        public Paquete(int id, string nombre,float pesokg,float volumen, int ciCliente, string estadoEnvio,
ADODB.Connection cn)
        {
            _id = id;
            _nombre = nombre;
            _pesokg = pesokg;
            _conexion = cn;
            _volumen = volumen;
            _ciCliente = ciCliente;
            _estadoEnvio = estadoEnvio;
        }



        public ADODB.Connection conexion
        {
            get { return (_conexion); }
            set { _conexion = value; }
        }
        public string nombre
        {
            get { return (_nombre); }
            set { _nombre = value; }
        }

        public int id
        {
            get { return (_id); }
            set { _id = value; }
        }
        public float pesokg
        {
            get { return (_pesokg); }
            set { _pesokg = value; }
        }

        public float volumen
        {
            get { return (_volumen); }
            set { _volumen = value; }
        }
      

        public int ciCliente
        {
            get { return (_ciCliente); }
            set { _ciCliente = value; }
        }

        public String estadoEnvio
        {
            get { return (_estadoEnvio); }
            set { _estadoEnvio = value; }
        }



        public int eliminarPaquete()
        {
            String sql;
            String sql1;
            String sql2;
            String sql3;

            object filasAfectadas;
            int totalFilasAfectadas = 0;

            if (_conexion.State != 0)
            {
                //conexion abierta

                sql = "DELETE FROM paquete WHERE id=" + _id;
                sql1 = "DELETE FROM articulo WHERE id=" + _id;
                sql2 = "DELETE FROM bulto_lote WHERE id_bulto=" + _id;
                sql3 = "DELETE FROM bulto WHERE id=" + _id;

                try
                {
                    ADODB.Recordset rs1 = _conexion.Execute(sql, out filasAfectadas);
                    totalFilasAfectadas += (int)filasAfectadas;

                    ADODB.Recordset rs2 = _conexion.Execute(sql1, out filasAfectadas);
                    totalFilasAfectadas += (int)filasAfectadas;

                    ADODB.Recordset rs3 = _conexion.Execute(sql2, out filasAfectadas);
                    totalFilasAfectadas += (int)filasAfectadas;

                    ADODB.Recordset rs4 = _conexion.Execute(sql3, out filasAfectadas);
                    totalFilasAfectadas += (int)filasAfectadas;

                    
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }

                if (totalFilasAfectadas > 0) //eliminamos el bulto
                {
                    return 3;
                }
                else //no encontre el bulto
                {
                    return 2;
                }
            }
            else
            {
                return 4;
            }
        }

    

    public int buscarPaquete()
        {

            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;
            
            


            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "select id from bulto where id='" + _id + "'";

                try
                {
                    rs = _conexion.Execute(sql, out filasAfectadas);

                    if (!rs.EOF) //encontramos el paquete
                    {
                        return 3;
                    }
                    else //no encontre el paquete
                    {
                        return 2;
                    }
                }
                catch
                {
                    //int num = int.Parse(sql);
                    return 1;
                }
            }
            else
            {
                return 4;
            }
        }
        public int registrarPaquete()
        {
            string sql;
           
            ADODB.Recordset rs;
            object filasAfectadas;



            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "INSERT INTO bulto (id,nombre, pesoKg, volumenM3, ci_cliente, estadoDeEnvio) VALUES(" + _id + ",'" + _nombre + "'," + _pesokg + "," + _volumen + "," + _ciCliente + ",'" + _estadoEnvio  + "')";
              
                try
                {

                    _conexion.Execute(sql, out filasAfectadas);
                  
                    
                    
                    return 3;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }
            }
            else
            {
                return 4;
            }


        }
        public int registrardDatos()
        {
            string sql;
            string sql1;
            string sql2;
            string sql3;
            string sql4;
           
            ADODB.Recordset rs;

            object filasAfectadas;

            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "select nombre from bulto where id=" + _id + "";
                sql1 = "select pesoKg from bulto where id=" + _id + "";
                sql2 = "select volumenM3 from bulto where id=" + _id + "";
                sql3 = "select ci_cliente from bulto where id=" + _id + "";
                sql4 = "select estadoDeEnvio from bulto where id=" + _id + "";
           

                try
                {

                    rs = _conexion.Execute(sql, out filasAfectadas);
                    _nombre = rs.Fields["nombre"].Value.ToString();
                   

                    rs = _conexion.Execute(sql1, out filasAfectadas);
                    _pesokg = Convert.ToSingle(rs.Fields["pesoKg"].Value);
                    

                    rs = _conexion.Execute(sql2, out filasAfectadas);
                    _volumen = Convert.ToSingle(rs.Fields["volumenM3"].Value);
                    

                    rs = _conexion.Execute(sql3, out filasAfectadas);
                    _ciCliente = Convert.ToInt32(rs.Fields["ci_cliente"].Value);
                    

                    rs = _conexion.Execute(sql4, out filasAfectadas);
                    _estadoEnvio = rs.Fields["estadoDeEnvio"].Value.ToString();
                    


                    return 3;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }
            }
            else
            {
                return 4;
            }
        }
        public int modificarBulto()
        {
            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;



            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "UPDATE bulto SET nombre = '" + _nombre + "', pesoKg = " + _pesokg + ", volumenM3 = " + _volumen + ", ci_cliente = " + _ciCliente + ", estadoDeEnvio = '" + _estadoEnvio + "' WHERE id = " + _id;

                try
                {

                    _conexion.Execute(sql, out filasAfectadas);



                    return 3;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }
            }
            else
            {
                return 4;
            }


        }
        public DataTable RecordsetToDataTable(ADODB.Recordset recordset)
        {
            DataTable dataTable = new DataTable();

            for (int i = 0; i < recordset.Fields.Count; i++)
            {
                dataTable.Columns.Add(recordset.Fields[i].Name, typeof(string));
            }

            while (!recordset.EOF)
            {
                DataRow dataRow = dataTable.NewRow();
                for (int i = 0; i < recordset.Fields.Count; i++)
                {
                    dataRow[i] = recordset.Fields[i].Value.ToString();
                }
                dataTable.Rows.Add(dataRow);
                recordset.MoveNext();
            }

            return dataTable;
        }

        public DataTable ObtenerDatosPaquete()
        {

            DataTable dataTable = new DataTable();

            if (_conexion.State != 0)
            {
                //conexion abierta
                string sql = "SELECT * FROM bulto;";

                try
                {

                    ADODB.Recordset rs = new ADODB.Recordset();


                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic);


                    dataTable = RecordsetToDataTable(rs);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("hpla");
                    Console.WriteLine(ex.Message);

                }
            }

            return dataTable;
        }

        public string obtenerMatriculaCamion()
        {
            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;

            if (_conexion.State != 0)
            {
                sql = "SELECT cl.matricula FROM camion_lote cl JOIN bulto_lote bl ON cl.id_lote = bl.id_lote WHERE bl.id_bulto = " + _id;

                try
                {
                    rs = _conexion.Execute(sql, out filasAfectadas);
                    return rs.Fields[0].Value.ToString();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return null;
                }
            }
            else
            {
                return null;
            }
        }

        public string obtenerNombreCamionero()
        {
            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;

            if (_conexion.State != 0)
            {
                sql = "SELECT u.nombre FROM usuario u JOIN manejar m ON u.Ci = m.Ci_camionero JOIN camion_lote cl ON m.matricula = cl.matricula JOIN bulto_lote bl ON cl.id_lote = bl.id_lote WHERE bl.id_bulto = " + _id;

                try
                {
                    rs = _conexion.Execute(sql, out filasAfectadas);
                    return rs.Fields[0].Value.ToString();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return null;
                }
            }
            else
            {
                return null;
            }
        }

        public string obtenerApellidoCamionero( )
        {
            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;

            if (_conexion.State != 0)
            {
                sql = "SELECT u.apellido FROM usuario u JOIN manejar m ON u.Ci = m.Ci_camionero JOIN camion_lote cl ON m.matricula = cl.matricula JOIN bulto_lote bl ON cl.id_lote = bl.id_lote WHERE bl.id_bulto = " + _id;

                try
                {
                    rs = _conexion.Execute(sql, out filasAfectadas);
                    return rs.Fields[0].Value.ToString();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return null;
                }
            }
            else
            {
                return null;
            }
        }

        public DateTime? obtenerfecha()
        {
            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;

            if (_conexion.State != 0)
            {
                sql = "SELECT cl.fecha FROM camion_lote AS cl JOIN bulto_lote AS bl ON cl.id_lote = bl.id_lote WHERE bl.id_bulto = " + _id;

                try
                {
                    rs = _conexion.Execute(sql, out filasAfectadas);
                    string resultado = rs.Fields[0].Value.ToString();
                    Console.WriteLine("Resultado de la consulta: " + resultado);
                    return DateTime.Parse(resultado);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return null;
                }
            }
            else
            {
                return null;
            }
        }
        public int obtenerIdLote()
        {
            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;

            if (_conexion.State != 0)
            {
                sql = "SELECT id_lote FROM bulto_lote WHERE id_bulto = " + _id;

                try
                {
                    rs = _conexion.Execute(sql, out filasAfectadas);
                    return Convert.ToInt32(rs.Fields[0].Value);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return -1;
                }
            }
            else
            {
                return -1;
            }
        }

        public int entrega()
        {

            string sql;
            string sql1;
            string sql2;

            
            object filasAfectadas;


            int devolucion = buscarBulto();
            //Console.Write("devolucion " + devolucion);
            if (devolucion == 3) {
                
            if (_conexion.State != 0)
            {
 
                        sql = "DELETE FROM bulto_lote WHERE id_bulto = " + _id;
                        sql1 = "UPDATE bulto SET estadoDeEnvio = 'recibido por el cliente' WHERE id = " + _id;
                        sql2 = "DELETE FROM articulo WHERE id=" + _id;
                    
                    try
                        {
                            _conexion.Execute(sql, out filasAfectadas);
                            _conexion.Execute(sql1, out filasAfectadas);
                            _conexion.Execute(sql2, out filasAfectadas);

                            return 3; // Operación exitosa
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                            return 1; // Error durante la operación
                        }
                    }
            else
            {
                return 4;
            }
        }
else
            {
                return 2;
            }


        }

        public int buscarBulto()
        {

            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;




            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "select id_bulto from bulto_lote where id_bulto='" + _id + "'";

                try
                {
                    rs = _conexion.Execute(sql, out filasAfectadas);

                    if (!rs.EOF) //encontramos el paquete
                    {
                        return 3;
                    }
                    else //no encontre el paquete
                    {
                        Console.WriteLine(_id);
                        return 2;
                       
                    }
                }
                catch
                {
                    //int num = int.Parse(sql);
                    return 1;
                }
            }
            else
            {
                return 4;
            }
        }
        public string obtenerEstadoDeEnvio()
        {
            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;

            if (_conexion.State != 0)
            {
                sql = "SELECT estadoDeEnvio FROM bulto WHERE id = " + _id;

                try
                {
                    rs = _conexion.Execute(sql, out filasAfectadas);
                    return Convert.ToString(rs.Fields[0].Value);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return null;
                }
            }
            else
            {
                return null;
            }
        }


    }
}