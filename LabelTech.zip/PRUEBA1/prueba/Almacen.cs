﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Numerics;
using System.Data;

namespace prueba
{
    class Almacen
    {

        protected int _id;
        protected double _longitud;
        protected double _latitud;
        protected BigInteger _rutEmpresa;
        protected int _ciAlmacenero;
        protected float _capacidadKg;
        protected float _capacidadM3;
        protected ADODB.Connection _conexion;

        Program P = new Program();

        public Almacen()
        {
            _conexion = Program.cn;
            _id = 0;
            _longitud = 0;
            _latitud = 0;
            _rutEmpresa = 0;
            _ciAlmacenero = 0;
            _capacidadKg = 0;
            _capacidadM3 = 0;


        }

        public Almacen(int id, float latitud, float longitud, BigInteger rutEmpresa, int ciAlmacenero, float capacidadKg,
ADODB.Connection cn, float capacidadM3)
        {
            _id = id;
            _longitud = longitud;
            _latitud = latitud;
            _conexion = cn;
            _rutEmpresa = rutEmpresa;
            _ciAlmacenero = ciAlmacenero;
            _capacidadKg = capacidadKg;
            _capacidadM3 = capacidadM3;
        }



        public ADODB.Connection conexion
        {
            get { return (_conexion); }
            set { _conexion = value; }
        }
        public double latitud
        {
            get { return (_latitud); }
            set { _latitud = value; }
        }

        public int id
        {
            get { return (_id); }
            set { _id = value; }
        }
        public double longitud
        {
            get { return (_longitud); }
            set { _longitud = value; }
        }

        public BigInteger rutEmpresa
        {
            get { return (_rutEmpresa); }
            set { _rutEmpresa = value; }
        }


        public int ciAlmacenero
        {
            get { return (_ciAlmacenero); }
            set { _ciAlmacenero = value; }
        }

        public float capacidadKg
        {
            get { return (_capacidadKg); }
            set { _capacidadKg = value; }
        }

        public float capacidadM3
        {
            get { return (_capacidadM3); }
            set { _capacidadM3 = value; }
        }


        public int buscarAlmacen()
        {

            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;




            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "select id from almacen where id='" + _id + "'";

                try
                {
                    rs = _conexion.Execute(sql, out filasAfectadas);

                    if (!rs.EOF) //encontramos el paquete
                    {
                        return 3;
                    }
                    else //no encontre el paquete
                    {
                        return 2;
                    }
                }
                catch
                {
                    //int num = int.Parse(sql);
                    return 1;
                }
            }
            else
            {
                return 4;
            }
        }

        public int registrarAlmacen()
        {
            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;



            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "INSERT INTO almacen (id, longitud, latitud, rut_empresa, ci_almacenero,capacidadKg,capacidadM3) VALUES (" + _id + "," + _longitud + "," + _latitud + "," + _rutEmpresa +","+ _ciAlmacenero+","+_capacidadKg+","+_capacidadM3+")";

                try
                {

                    _conexion.Execute(sql, out filasAfectadas);



                    return 3;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }
            }
            else
            {
                return 4;
            }


        }
        public int modificarAlmacen()
        {
            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;



            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "UPDATE almacen SET longitud = " + _longitud + ", latitud = " + _latitud + ", rut_empresa = " + _rutEmpresa + ", ci_almacenero = " + _ciAlmacenero + ", capacidadKg = " + _capacidadKg + ", capacidadM3 = " + _capacidadM3 + " WHERE id = " + _id + ";"; 

                try
                {

                    _conexion.Execute(sql, out filasAfectadas);



                    return 3;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }
            }
            else
            {
                return 4;
            }


        }
        public int registrardDatos()
        {
            string sql;
            string sql1;
            string sql2;
            string sql3;
            string sql4;
            string sql5;
            ADODB.Recordset rs;
           
            object filasAfectadas;

            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "select latitud from almacen where id='" + _id + "'";
                sql1 = "select longitud from almacen where id='" + _id + "'";
                sql2 = "select rut_empresa from almacen where id='" + _id + "'";
                sql3 = "select ci_almacenero from almacen where id='" + _id + "'";
                sql4 = "select capacidadKg from almacen where id='" + _id + "'";
                sql5 = "select capacidadM3 from almacen where id='" + _id + "'";

                try
                {
                    rs = _conexion.Execute(sql, out filasAfectadas);
                    _latitud = Convert.ToSingle(rs.Fields["latitud"].Value);
                    rs = _conexion.Execute(sql1, out filasAfectadas);
                    _longitud = Convert.ToSingle(rs.Fields["longitud"].Value);
                     rs = _conexion.Execute(sql2, out filasAfectadas);
                    _rutEmpresa = BigInteger.Parse(rs.Fields["rut_empresa"].Value.ToString());

                    rs = _conexion.Execute(sql3, out filasAfectadas);
                    _ciAlmacenero = Convert.ToInt32(rs.Fields["ci_almacenero"].Value);
                    rs = _conexion.Execute(sql4, out filasAfectadas);
                    _capacidadKg = Convert.ToSingle(rs.Fields["capacidadKg"].Value);
                    rs = _conexion.Execute(sql5, out filasAfectadas);
                    _capacidadM3 = Convert.ToSingle(rs.Fields["capacidadM3"].Value);

                    return 3;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }
            }
            else
            {
                return 4;
            }
        }
       

        public DataTable RecordsetToDataTable(ADODB.Recordset recordset)
        {
            DataTable dataTable = new DataTable();

            for (int i = 0; i < recordset.Fields.Count; i++)
            {
                dataTable.Columns.Add(recordset.Fields[i].Name, typeof(string));
            }

            while (!recordset.EOF)
            {
                DataRow dataRow = dataTable.NewRow();
                for (int i = 0; i < recordset.Fields.Count; i++)
                {
                    dataRow[i] = recordset.Fields[i].Value.ToString();
                }
                dataTable.Rows.Add(dataRow);
                recordset.MoveNext();
            }

            return dataTable;
        }

        public DataTable ObtenerDatosAlmacen()
        {
            
            DataTable dataTable = new DataTable();

            if (_conexion.State != 0)
            {
                //conexion abierta
                string sql = "SELECT * FROM almacen;";

                try
                {
                    
                    ADODB.Recordset rs = new ADODB.Recordset();

                    
                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic);

                   
                    dataTable = RecordsetToDataTable(rs);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            
            return dataTable;
        }


        public int eliminarAlmacen()
        {
            String sql;
            String sql1;
            String sql2;
            String sql3;
            String sql4;

            object filasAfectadas;

            if (_conexion.State != 0)
            {
                //conexion abierta

                sql = "DELETE FROM bulto_lote WHERE id_lote IN (SELECT id FROM lote WHERE id_almacen=" + _id + ")";
                sql1 = "DELETE FROM camion_lote WHERE id_lote IN (SELECT id FROM lote WHERE id_almacen=" + _id + ")";
                sql2 = "DELETE FROM lote WHERE id_almacen=" + _id;
                sql3 = "DELETE FROM almacen WHERE id=" + _id;

                try
                {
                    ADODB.Recordset rs1 = _conexion.Execute(sql, out filasAfectadas);
                    

                    ADODB.Recordset rs2 = _conexion.Execute(sql1, out filasAfectadas);
                    

                    ADODB.Recordset rs3 = _conexion.Execute(sql2, out filasAfectadas);
                   

                    ADODB.Recordset rs4 = _conexion.Execute(sql3, out filasAfectadas);
                    
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }

                return 3; // Operación exitosa
            }
            else
            {
                return 4; // La conexión no está abierta
            }

        }

        public (double, double) ObtenerLongitudLatitudAlmacen()
        {
            Paquete p = new Paquete();
            ADODB.Recordset rs;
            
            p.id = id;
            
            string sqlLongitud;
            string sqlLatitud;
            object filasAfectadas;
            if (_conexion.State != 0)
            {
                // Consulta para obtener la longitud
                 sqlLongitud = "SELECT almacen.longitud FROM bulto JOIN bulto_lote ON bulto.id = bulto_lote.id_bulto  JOIN lote ON bulto_lote.id_lote = lote.id JOIN almacen ON lote.id_almacen = almacen.id WHERE bulto.id = " + p.id;

                // Consulta para obtener la latitud
                 sqlLatitud = "SELECT almacen.latitud FROM bulto JOIN bulto_lote ON bulto.id = bulto_lote.id_bulto  JOIN lote ON bulto_lote.id_lote = lote.id JOIN almacen ON lote.id_almacen = almacen.id WHERE bulto.id = " + p.id;

                try
                {
                    

                   rs = _conexion.Execute(sqlLatitud, out filasAfectadas);
                    _latitud = Convert.ToSingle(rs.Fields["latitud"].Value);
                    rs = _conexion.Execute(sqlLongitud, out filasAfectadas);
                    _longitud = Convert.ToSingle(rs.Fields["longitud"].Value);
                }
                catch (Exception ex)
                {
                    
                    Console.WriteLine(ex.Message);
                }
            }

            return (_longitud, _latitud);
        }

    }
}














