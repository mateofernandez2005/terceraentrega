﻿namespace prueba
{
    partial class RegistroUsuarioApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegistroUsuarioApp));
            this.lbbousurol = new System.Windows.Forms.Label();
            this.contrasenia = new System.Windows.Forms.Label();
            this.lbbousuusuario = new System.Windows.Forms.Label();
            this.txtContraseña = new System.Windows.Forms.TextBox();
            this.txtUsuario = new System.Windows.Forms.TextBox();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.txtlongitud = new System.Windows.Forms.TextBox();
            this.txtlatitud = new System.Windows.Forms.TextBox();
            this.lbbousulatitud = new System.Windows.Forms.Label();
            this.lbbousulongitud = new System.Windows.Forms.Label();
            this.comboidioma = new System.Windows.Forms.ComboBox();
            this.comborol = new System.Windows.Forms.ComboBox();
            this.btnlimpiar = new System.Windows.Forms.Button();
            this.txtNum = new System.Windows.Forms.TextBox();
            this.lbbousucelular = new System.Windows.Forms.Label();
            this.txtApellido = new System.Windows.Forms.TextBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtCi = new System.Windows.Forms.TextBox();
            this.cc = new System.Windows.Forms.Label();
            this.lbbousuidioma = new System.Windows.Forms.Label();
            this.lbbousunombre = new System.Windows.Forms.Label();
            this.lbbousuci = new System.Windows.Forms.Label();
            this.btnModificar = new System.Windows.Forms.Button();
            this.btnbuscar = new System.Windows.Forms.Button();
            this.gridusuarios = new System.Windows.Forms.DataGridView();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panelListaUsuarios = new System.Windows.Forms.Panel();
            this.lbbousulistausuario = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbbousulistas = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbbousuregistro = new System.Windows.Forms.Label();
            this.btnSaliir = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gridusuarios)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panelListaUsuarios.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbbousurol
            // 
            this.lbbousurol.AutoSize = true;
            this.lbbousurol.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbousurol.ForeColor = System.Drawing.Color.White;
            this.lbbousurol.Location = new System.Drawing.Point(155, 214);
            this.lbbousurol.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbbousurol.Name = "lbbousurol";
            this.lbbousurol.Size = new System.Drawing.Size(105, 20);
            this.lbbousurol.TabIndex = 12;
            this.lbbousurol.Text = "Ingrese rol:";
            // 
            // contrasenia
            // 
            this.contrasenia.AutoSize = true;
            this.contrasenia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contrasenia.ForeColor = System.Drawing.Color.White;
            this.contrasenia.Location = new System.Drawing.Point(155, 182);
            this.contrasenia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.contrasenia.Name = "contrasenia";
            this.contrasenia.Size = new System.Drawing.Size(176, 20);
            this.contrasenia.TabIndex = 11;
            this.contrasenia.Text = "Ingrese contraseña:";
            // 
            // lbbousuusuario
            // 
            this.lbbousuusuario.AutoSize = true;
            this.lbbousuusuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbousuusuario.ForeColor = System.Drawing.Color.White;
            this.lbbousuusuario.Location = new System.Drawing.Point(155, 124);
            this.lbbousuusuario.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbbousuusuario.Name = "lbbousuusuario";
            this.lbbousuusuario.Size = new System.Drawing.Size(239, 20);
            this.lbbousuusuario.TabIndex = 10;
            this.lbbousuusuario.Text = "Ingrese nombre de usuario:";
            // 
            // txtContraseña
            // 
            this.txtContraseña.Location = new System.Drawing.Point(356, 177);
            this.txtContraseña.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtContraseña.Name = "txtContraseña";
            this.txtContraseña.Size = new System.Drawing.Size(212, 22);
            this.txtContraseña.TabIndex = 8;
            // 
            // txtUsuario
            // 
            this.txtUsuario.Location = new System.Drawing.Point(425, 123);
            this.txtUsuario.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtUsuario.Name = "txtUsuario";
            this.txtUsuario.Size = new System.Drawing.Size(143, 22);
            this.txtUsuario.TabIndex = 7;
            // 
            // btnSalir
            // 
            this.btnSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.ForeColor = System.Drawing.Color.Red;
            this.btnSalir.Location = new System.Drawing.Point(1352, 604);
            this.btnSalir.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(91, 36);
            this.btnSalir.TabIndex = 14;
            this.btnSalir.Text = "SALIR";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrar.ForeColor = System.Drawing.Color.Green;
            this.btnRegistrar.Location = new System.Drawing.Point(623, 366);
            this.btnRegistrar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(108, 36);
            this.btnRegistrar.TabIndex = 13;
            this.btnRegistrar.Text = "Registrar";
            this.btnRegistrar.UseVisualStyleBackColor = true;
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminar.ForeColor = System.Drawing.Color.Red;
            this.btnEliminar.Location = new System.Drawing.Point(623, 409);
            this.btnEliminar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(108, 36);
            this.btnEliminar.TabIndex = 13;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // txtlongitud
            // 
            this.txtlongitud.Location = new System.Drawing.Point(356, 420);
            this.txtlongitud.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtlongitud.Name = "txtlongitud";
            this.txtlongitud.Size = new System.Drawing.Size(212, 22);
            this.txtlongitud.TabIndex = 33;
            // 
            // txtlatitud
            // 
            this.txtlatitud.Location = new System.Drawing.Point(356, 455);
            this.txtlatitud.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtlatitud.Name = "txtlatitud";
            this.txtlatitud.Size = new System.Drawing.Size(212, 22);
            this.txtlatitud.TabIndex = 32;
            this.txtlatitud.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lbbousulatitud
            // 
            this.lbbousulatitud.AutoSize = true;
            this.lbbousulatitud.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbousulatitud.ForeColor = System.Drawing.Color.White;
            this.lbbousulatitud.Location = new System.Drawing.Point(155, 460);
            this.lbbousulatitud.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbbousulatitud.Name = "lbbousulatitud";
            this.lbbousulatitud.Size = new System.Drawing.Size(135, 20);
            this.lbbousulatitud.TabIndex = 31;
            this.lbbousulatitud.Text = "Ingrese latitud:";
            // 
            // lbbousulongitud
            // 
            this.lbbousulongitud.AutoSize = true;
            this.lbbousulongitud.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbousulongitud.ForeColor = System.Drawing.Color.White;
            this.lbbousulongitud.Location = new System.Drawing.Point(155, 425);
            this.lbbousulongitud.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbbousulongitud.Name = "lbbousulongitud";
            this.lbbousulongitud.Size = new System.Drawing.Size(149, 20);
            this.lbbousulongitud.TabIndex = 30;
            this.lbbousulongitud.Text = "Ingrese longitud:";
            // 
            // comboidioma
            // 
            this.comboidioma.FormattingEnabled = true;
            this.comboidioma.Items.AddRange(new object[] {
            "español",
            "ingles"});
            this.comboidioma.Location = new System.Drawing.Point(356, 345);
            this.comboidioma.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboidioma.Name = "comboidioma";
            this.comboidioma.Size = new System.Drawing.Size(212, 24);
            this.comboidioma.TabIndex = 29;
            // 
            // comborol
            // 
            this.comborol.FormattingEnabled = true;
            this.comborol.Items.AddRange(new object[] {
            "cliente",
            "backoffice",
            "camionero",
            "almacenero"});
            this.comborol.Location = new System.Drawing.Point(356, 208);
            this.comborol.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comborol.Name = "comborol";
            this.comborol.Size = new System.Drawing.Size(212, 24);
            this.comborol.TabIndex = 28;
            // 
            // btnlimpiar
            // 
            this.btnlimpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlimpiar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnlimpiar.Location = new System.Drawing.Point(623, 166);
            this.btnlimpiar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnlimpiar.Name = "btnlimpiar";
            this.btnlimpiar.Size = new System.Drawing.Size(108, 36);
            this.btnlimpiar.TabIndex = 17;
            this.btnlimpiar.Text = "Limpiar";
            this.btnlimpiar.UseVisualStyleBackColor = true;
            this.btnlimpiar.Click += new System.EventHandler(this.btnlimpiar_Click);
            // 
            // txtNum
            // 
            this.txtNum.Location = new System.Drawing.Point(419, 383);
            this.txtNum.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNum.Name = "txtNum";
            this.txtNum.Size = new System.Drawing.Size(149, 22);
            this.txtNum.TabIndex = 27;
            // 
            // lbbousucelular
            // 
            this.lbbousucelular.AutoSize = true;
            this.lbbousucelular.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbousucelular.ForeColor = System.Drawing.Color.White;
            this.lbbousucelular.Location = new System.Drawing.Point(155, 388);
            this.lbbousucelular.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbbousucelular.Name = "lbbousucelular";
            this.lbbousucelular.Size = new System.Drawing.Size(234, 20);
            this.lbbousucelular.TabIndex = 26;
            this.lbbousucelular.Text = "ingrese numero de celular:";
            this.lbbousucelular.Click += new System.EventHandler(this.label5_Click);
            // 
            // txtApellido
            // 
            this.txtApellido.Location = new System.Drawing.Point(356, 309);
            this.txtApellido.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtApellido.Name = "txtApellido";
            this.txtApellido.Size = new System.Drawing.Size(212, 22);
            this.txtApellido.TabIndex = 24;
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(356, 276);
            this.txtNombre.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(212, 22);
            this.txtNombre.TabIndex = 23;
            // 
            // txtCi
            // 
            this.txtCi.Location = new System.Drawing.Point(356, 242);
            this.txtCi.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtCi.Name = "txtCi";
            this.txtCi.Size = new System.Drawing.Size(212, 22);
            this.txtCi.TabIndex = 22;
            // 
            // cc
            // 
            this.cc.AutoSize = true;
            this.cc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cc.ForeColor = System.Drawing.Color.White;
            this.cc.Location = new System.Drawing.Point(155, 314);
            this.cc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.cc.Name = "cc";
            this.cc.Size = new System.Drawing.Size(148, 20);
            this.cc.TabIndex = 21;
            this.cc.Text = "Ingrese apellido:";
            // 
            // lbbousuidioma
            // 
            this.lbbousuidioma.AutoSize = true;
            this.lbbousuidioma.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbousuidioma.ForeColor = System.Drawing.Color.White;
            this.lbbousuidioma.Location = new System.Drawing.Point(155, 351);
            this.lbbousuidioma.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbbousuidioma.Name = "lbbousuidioma";
            this.lbbousuidioma.Size = new System.Drawing.Size(138, 20);
            this.lbbousuidioma.TabIndex = 20;
            this.lbbousuidioma.Text = "Ingrese idioma:";
            // 
            // lbbousunombre
            // 
            this.lbbousunombre.AutoSize = true;
            this.lbbousunombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbousunombre.ForeColor = System.Drawing.Color.White;
            this.lbbousunombre.Location = new System.Drawing.Point(155, 281);
            this.lbbousunombre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbbousunombre.Name = "lbbousunombre";
            this.lbbousunombre.Size = new System.Drawing.Size(145, 20);
            this.lbbousunombre.TabIndex = 19;
            this.lbbousunombre.Text = "Ingrese nombre:";
            // 
            // lbbousuci
            // 
            this.lbbousuci.AutoSize = true;
            this.lbbousuci.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbousuci.ForeColor = System.Drawing.Color.White;
            this.lbbousuci.Location = new System.Drawing.Point(155, 247);
            this.lbbousuci.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbbousuci.Name = "lbbousuci";
            this.lbbousuci.Size = new System.Drawing.Size(98, 20);
            this.lbbousuci.TabIndex = 18;
            this.lbbousuci.Text = "Ingrese ci:";
            this.lbbousuci.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnModificar
            // 
            this.btnModificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificar.ForeColor = System.Drawing.Color.DarkBlue;
            this.btnModificar.Location = new System.Drawing.Point(623, 452);
            this.btnModificar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(108, 36);
            this.btnModificar.TabIndex = 17;
            this.btnModificar.Text = "Modificar";
            this.btnModificar.UseVisualStyleBackColor = true;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // btnbuscar
            // 
            this.btnbuscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbuscar.ForeColor = System.Drawing.Color.Black;
            this.btnbuscar.Location = new System.Drawing.Point(623, 117);
            this.btnbuscar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnbuscar.Name = "btnbuscar";
            this.btnbuscar.Size = new System.Drawing.Size(107, 36);
            this.btnbuscar.TabIndex = 16;
            this.btnbuscar.Text = "Buscar";
            this.btnbuscar.UseVisualStyleBackColor = true;
            this.btnbuscar.Click += new System.EventHandler(this.btnbuscar_Click);
            // 
            // gridusuarios
            // 
            this.gridusuarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridusuarios.Dock = System.Windows.Forms.DockStyle.Top;
            this.gridusuarios.Location = new System.Drawing.Point(0, 0);
            this.gridusuarios.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gridusuarios.Name = "gridusuarios";
            this.gridusuarios.RowTemplate.Height = 24;
            this.gridusuarios.Size = new System.Drawing.Size(302, 199);
            this.gridusuarios.TabIndex = 18;
            this.gridusuarios.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridusuarios_CellContentClick);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.Black;
            this.splitContainer1.Panel1.Controls.Add(this.panelListaUsuarios);
            this.splitContainer1.Panel1.Controls.Add(this.lbbousulistausuario);
            this.splitContainer1.Panel1.Controls.Add(this.panel2);
            this.splitContainer1.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Panel1_Paint);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.label1);
            this.splitContainer1.Panel2.Controls.Add(this.lbbousuregistro);
            this.splitContainer1.Panel2.Controls.Add(this.btnSaliir);
            this.splitContainer1.Panel2.Controls.Add(this.txtlongitud);
            this.splitContainer1.Panel2.Controls.Add(this.txtlatitud);
            this.splitContainer1.Panel2.Controls.Add(this.comborol);
            this.splitContainer1.Panel2.Controls.Add(this.lbbousulatitud);
            this.splitContainer1.Panel2.Controls.Add(this.txtContraseña);
            this.splitContainer1.Panel2.Controls.Add(this.lbbousulongitud);
            this.splitContainer1.Panel2.Controls.Add(this.contrasenia);
            this.splitContainer1.Panel2.Controls.Add(this.comboidioma);
            this.splitContainer1.Panel2.Controls.Add(this.txtUsuario);
            this.splitContainer1.Panel2.Controls.Add(this.lbbousurol);
            this.splitContainer1.Panel2.Controls.Add(this.btnlimpiar);
            this.splitContainer1.Panel2.Controls.Add(this.lbbousuusuario);
            this.splitContainer1.Panel2.Controls.Add(this.txtNum);
            this.splitContainer1.Panel2.Controls.Add(this.btnRegistrar);
            this.splitContainer1.Panel2.Controls.Add(this.lbbousucelular);
            this.splitContainer1.Panel2.Controls.Add(this.btnbuscar);
            this.splitContainer1.Panel2.Controls.Add(this.txtApellido);
            this.splitContainer1.Panel2.Controls.Add(this.btnEliminar);
            this.splitContainer1.Panel2.Controls.Add(this.txtNombre);
            this.splitContainer1.Panel2.Controls.Add(this.btnModificar);
            this.splitContainer1.Panel2.Controls.Add(this.txtCi);
            this.splitContainer1.Panel2.Controls.Add(this.lbbousuci);
            this.splitContainer1.Panel2.Controls.Add(this.cc);
            this.splitContainer1.Panel2.Controls.Add(this.lbbousunombre);
            this.splitContainer1.Panel2.Controls.Add(this.lbbousuidioma);
            this.splitContainer1.Panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Panel2_Paint);
            this.splitContainer1.Size = new System.Drawing.Size(1193, 658);
            this.splitContainer1.SplitterDistance = 302;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 19;
            // 
            // panelListaUsuarios
            // 
            this.panelListaUsuarios.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelListaUsuarios.Controls.Add(this.gridusuarios);
            this.panelListaUsuarios.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelListaUsuarios.Location = new System.Drawing.Point(0, 215);
            this.panelListaUsuarios.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelListaUsuarios.Name = "panelListaUsuarios";
            this.panelListaUsuarios.Size = new System.Drawing.Size(302, 202);
            this.panelListaUsuarios.TabIndex = 28;
            // 
            // lbbousulistausuario
            // 
            this.lbbousulistausuario.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbbousulistausuario.FlatAppearance.BorderSize = 0;
            this.lbbousulistausuario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbbousulistausuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbousulistausuario.ForeColor = System.Drawing.Color.White;
            this.lbbousulistausuario.Location = new System.Drawing.Point(0, 149);
            this.lbbousulistausuario.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lbbousulistausuario.Name = "lbbousulistausuario";
            this.lbbousulistausuario.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lbbousulistausuario.Size = new System.Drawing.Size(302, 66);
            this.lbbousulistausuario.TabIndex = 27;
            this.lbbousulistausuario.Text = "Lista de usuarios";
            this.lbbousulistausuario.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbbousulistausuario.UseVisualStyleBackColor = true;
            this.lbbousulistausuario.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbbousulistas);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(302, 149);
            this.panel2.TabIndex = 26;
            // 
            // lbbousulistas
            // 
            this.lbbousulistas.AutoSize = true;
            this.lbbousulistas.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbousulistas.ForeColor = System.Drawing.Color.White;
            this.lbbousulistas.Location = new System.Drawing.Point(111, 59);
            this.lbbousulistas.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbbousulistas.Name = "lbbousulistas";
            this.lbbousulistas.Size = new System.Drawing.Size(81, 29);
            this.lbbousulistas.TabIndex = 24;
            this.lbbousulistas.Text = "Listas";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(309, 516);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(329, 20);
            this.label1.TabIndex = 36;
            this.label1.Text = "ingrese latitud y longitud con punto(.) ";
            // 
            // lbbousuregistro
            // 
            this.lbbousuregistro.AutoSize = true;
            this.lbbousuregistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbousuregistro.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lbbousuregistro.Location = new System.Drawing.Point(153, 59);
            this.lbbousuregistro.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbbousuregistro.Name = "lbbousuregistro";
            this.lbbousuregistro.Size = new System.Drawing.Size(255, 29);
            this.lbbousuregistro.TabIndex = 35;
            this.lbbousuregistro.Text = "Registro de usuarios";
            // 
            // btnSaliir
            // 
            this.btnSaliir.BackColor = System.Drawing.Color.AliceBlue;
            this.btnSaliir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaliir.ForeColor = System.Drawing.Color.Red;
            this.btnSaliir.Location = new System.Drawing.Point(779, 609);
            this.btnSaliir.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSaliir.Name = "btnSaliir";
            this.btnSaliir.Size = new System.Drawing.Size(91, 36);
            this.btnSaliir.TabIndex = 34;
            this.btnSaliir.Text = "SALIR";
            this.btnSaliir.UseVisualStyleBackColor = false;
            this.btnSaliir.Click += new System.EventHandler(this.button2_Click);
            // 
            // RegistroUsuarioApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1193, 658);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.btnSalir);
            this.ForeColor = System.Drawing.Color.Black;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "RegistroUsuarioApp";
            this.Text = "Registro usuario";
            this.Load += new System.EventHandler(this.RegistroUsuarioApp_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridusuarios)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.panelListaUsuarios.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lbbousurol;
        private System.Windows.Forms.Label contrasenia;
        private System.Windows.Forms.Label lbbousuusuario;
        private System.Windows.Forms.TextBox txtContraseña;
        private System.Windows.Forms.TextBox txtUsuario;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnbuscar;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.Label cc;
        private System.Windows.Forms.Label lbbousuidioma;
        private System.Windows.Forms.Label lbbousunombre;
        private System.Windows.Forms.Label lbbousuci;
        private System.Windows.Forms.TextBox txtApellido;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtCi;
        private System.Windows.Forms.Label lbbousucelular;
        private System.Windows.Forms.TextBox txtNum;
        private System.Windows.Forms.Button btnlimpiar;
        private System.Windows.Forms.DataGridView gridusuarios;
        private System.Windows.Forms.ComboBox comborol;
        private System.Windows.Forms.ComboBox comboidioma;
        private System.Windows.Forms.TextBox txtlongitud;
        private System.Windows.Forms.TextBox txtlatitud;
        private System.Windows.Forms.Label lbbousulatitud;
        private System.Windows.Forms.Label lbbousulongitud;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbbousulistas;
        private System.Windows.Forms.Button lbbousulistausuario;
        private System.Windows.Forms.Panel panelListaUsuarios;
        private System.Windows.Forms.Button btnSaliir;
        private System.Windows.Forms.Label lbbousuregistro;
        private System.Windows.Forms.Label label1;
    }
}