﻿namespace prueba
{
    partial class registroPaquetesApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(registroPaquetesApp));
            this.comboestado = new System.Windows.Forms.ComboBox();
            this.btnlimpiar = new System.Windows.Forms.Button();
            this.txtci = new System.Windows.Forms.TextBox();
            this.lbbopaqestado = new System.Windows.Forms.Label();
            this.lbbopaqci = new System.Windows.Forms.Label();
            this.lbbopaqkg = new System.Windows.Forms.Label();
            this.txtPesoPaquete = new System.Windows.Forms.TextBox();
            this.btnbuscar = new System.Windows.Forms.Button();
            this.btnModificar = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.txtIdPaquete = new System.Windows.Forms.TextBox();
            this.txtTamanioPaquete = new System.Windows.Forms.TextBox();
            this.txtNombrePaquete = new System.Windows.Forms.TextBox();
            this.lbbopaqid = new System.Windows.Forms.Label();
            this.lbbopaqL = new System.Windows.Forms.Label();
            this.lbbopaqnombre = new System.Windows.Forms.Label();
            this.btnSalir = new System.Windows.Forms.Button();
            this.eliminarBuloLote = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.txtlotea = new System.Windows.Forms.TextBox();
            this.lbbopaqasignacionlote = new System.Windows.Forms.Label();
            this.lbbopaqasignacion = new System.Windows.Forms.Label();
            this.txtidbulto = new System.Windows.Forms.TextBox();
            this.btnAsignarBultoLote = new System.Windows.Forms.Button();
            this.lbbopaqidpaquete = new System.Windows.Forms.Label();
            this.txtalmacenlote = new System.Windows.Forms.TextBox();
            this.lbbopaqidalmacen = new System.Windows.Forms.Label();
            this.btneliminarlote = new System.Windows.Forms.Button();
            this.btnregistrarlote = new System.Windows.Forms.Button();
            this.btnBuscarLote = new System.Windows.Forms.Button();
            this.txtIdLote = new System.Windows.Forms.TextBox();
            this.lbbopaqlote = new System.Windows.Forms.Label();
            this.gridpaquetes = new System.Windows.Forms.DataGridView();
            this.gridlotes = new System.Windows.Forms.DataGridView();
            this.gridbultolote = new System.Windows.Forms.DataGridView();
            this.lbbopaqlistar = new System.Windows.Forms.Label();
            this.txtidlotebulto = new System.Windows.Forms.TextBox();
            this.lbbopaqidlote = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelListaLotes = new System.Windows.Forms.Panel();
            this.panelListaPaquetes = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.lbbopaqlistarpaquetes = new System.Windows.Forms.Button();
            this.lbbopaqlistarlote = new System.Windows.Forms.Button();
            this.panelPaquetesBus = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbbopaqregistro = new System.Windows.Forms.Label();
            this.lbbopaqregistrolotes = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gridpaquetes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridlotes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridbultolote)).BeginInit();
            this.panel1.SuspendLayout();
            this.panelListaLotes.SuspendLayout();
            this.panelListaPaquetes.SuspendLayout();
            this.panelPaquetesBus.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // comboestado
            // 
            this.comboestado.BackColor = System.Drawing.SystemColors.Window;
            this.comboestado.ForeColor = System.Drawing.Color.Black;
            this.comboestado.FormattingEnabled = true;
            this.comboestado.Items.AddRange(new object[] {
            "recibido en centro de logistica",
            "en camino",
            "recibido por el cliente"});
            this.comboestado.Location = new System.Drawing.Point(649, 280);
            this.comboestado.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboestado.Name = "comboestado";
            this.comboestado.Size = new System.Drawing.Size(122, 21);
            this.comboestado.TabIndex = 23;
            this.comboestado.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // btnlimpiar
            // 
            this.btnlimpiar.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnlimpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlimpiar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnlimpiar.Location = new System.Drawing.Point(796, 145);
            this.btnlimpiar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnlimpiar.Name = "btnlimpiar";
            this.btnlimpiar.Size = new System.Drawing.Size(68, 29);
            this.btnlimpiar.TabIndex = 22;
            this.btnlimpiar.Text = "LIMPIAR";
            this.btnlimpiar.UseVisualStyleBackColor = false;
            this.btnlimpiar.Click += new System.EventHandler(this.btnlimpiar_Click);
            // 
            // txtci
            // 
            this.txtci.Location = new System.Drawing.Point(649, 253);
            this.txtci.Name = "txtci";
            this.txtci.Size = new System.Drawing.Size(122, 20);
            this.txtci.TabIndex = 20;
            this.txtci.TextChanged += new System.EventHandler(this.txtci_TextChanged);
            // 
            // lbbopaqestado
            // 
            this.lbbopaqestado.AutoSize = true;
            this.lbbopaqestado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbopaqestado.ForeColor = System.Drawing.Color.White;
            this.lbbopaqestado.Location = new System.Drawing.Point(444, 280);
            this.lbbopaqestado.Name = "lbbopaqestado";
            this.lbbopaqestado.Size = new System.Drawing.Size(160, 16);
            this.lbbopaqestado.TabIndex = 19;
            this.lbbopaqestado.Text = "Ingresar estado de envio:";
            this.lbbopaqestado.Click += new System.EventHandler(this.label10_Click);
            // 
            // lbbopaqci
            // 
            this.lbbopaqci.AutoSize = true;
            this.lbbopaqci.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbopaqci.ForeColor = System.Drawing.Color.White;
            this.lbbopaqci.Location = new System.Drawing.Point(444, 254);
            this.lbbopaqci.Name = "lbbopaqci";
            this.lbbopaqci.Size = new System.Drawing.Size(134, 16);
            this.lbbopaqci.TabIndex = 18;
            this.lbbopaqci.Text = "Ingresar ci del cliente";
            this.lbbopaqci.Click += new System.EventHandler(this.label8_Click_1);
            // 
            // lbbopaqkg
            // 
            this.lbbopaqkg.AutoSize = true;
            this.lbbopaqkg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbopaqkg.ForeColor = System.Drawing.Color.White;
            this.lbbopaqkg.Location = new System.Drawing.Point(444, 226);
            this.lbbopaqkg.Name = "lbbopaqkg";
            this.lbbopaqkg.Size = new System.Drawing.Size(187, 16);
            this.lbbopaqkg.TabIndex = 17;
            this.lbbopaqkg.Text = "Ingresar peso del paquete kg:";
            this.lbbopaqkg.Click += new System.EventHandler(this.label4_Click);
            // 
            // txtPesoPaquete
            // 
            this.txtPesoPaquete.Location = new System.Drawing.Point(649, 226);
            this.txtPesoPaquete.Name = "txtPesoPaquete";
            this.txtPesoPaquete.Size = new System.Drawing.Size(122, 20);
            this.txtPesoPaquete.TabIndex = 16;
            this.txtPesoPaquete.TextChanged += new System.EventHandler(this.txtPesoPaquete_TextChanged);
            // 
            // btnbuscar
            // 
            this.btnbuscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbuscar.ForeColor = System.Drawing.Color.Black;
            this.btnbuscar.Location = new System.Drawing.Point(796, 109);
            this.btnbuscar.Name = "btnbuscar";
            this.btnbuscar.Size = new System.Drawing.Size(68, 29);
            this.btnbuscar.TabIndex = 15;
            this.btnbuscar.Text = "Buscar";
            this.btnbuscar.UseVisualStyleBackColor = true;
            this.btnbuscar.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnModificar
            // 
            this.btnModificar.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnModificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificar.ForeColor = System.Drawing.Color.DarkBlue;
            this.btnModificar.Location = new System.Drawing.Point(796, 280);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(68, 29);
            this.btnModificar.TabIndex = 11;
            this.btnModificar.Text = "Modificar";
            this.btnModificar.UseVisualStyleBackColor = false;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnEliminar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminar.ForeColor = System.Drawing.Color.Red;
            this.btnEliminar.Location = new System.Drawing.Point(796, 241);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(68, 29);
            this.btnEliminar.TabIndex = 6;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = false;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnRegistrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrar.ForeColor = System.Drawing.Color.Green;
            this.btnRegistrar.Location = new System.Drawing.Point(796, 199);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(68, 29);
            this.btnRegistrar.TabIndex = 6;
            this.btnRegistrar.Text = "Registrar";
            this.btnRegistrar.UseVisualStyleBackColor = false;
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);
            // 
            // txtIdPaquete
            // 
            this.txtIdPaquete.Location = new System.Drawing.Point(606, 118);
            this.txtIdPaquete.Name = "txtIdPaquete";
            this.txtIdPaquete.Size = new System.Drawing.Size(165, 20);
            this.txtIdPaquete.TabIndex = 5;
            this.txtIdPaquete.TextChanged += new System.EventHandler(this.txtIdPaquete_TextChanged);
            // 
            // txtTamanioPaquete
            // 
            this.txtTamanioPaquete.Location = new System.Drawing.Point(649, 199);
            this.txtTamanioPaquete.Name = "txtTamanioPaquete";
            this.txtTamanioPaquete.Size = new System.Drawing.Size(122, 20);
            this.txtTamanioPaquete.TabIndex = 4;
            this.txtTamanioPaquete.TextChanged += new System.EventHandler(this.txtTamanioPaquete_TextChanged);
            // 
            // txtNombrePaquete
            // 
            this.txtNombrePaquete.Location = new System.Drawing.Point(649, 170);
            this.txtNombrePaquete.Name = "txtNombrePaquete";
            this.txtNombrePaquete.Size = new System.Drawing.Size(122, 20);
            this.txtNombrePaquete.TabIndex = 3;
            this.txtNombrePaquete.TextChanged += new System.EventHandler(this.txtNombrePaquete_TextChanged);
            // 
            // lbbopaqid
            // 
            this.lbbopaqid.AutoSize = true;
            this.lbbopaqid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbopaqid.Location = new System.Drawing.Point(444, 119);
            this.lbbopaqid.Name = "lbbopaqid";
            this.lbbopaqid.Size = new System.Drawing.Size(146, 16);
            this.lbbopaqid.TabIndex = 2;
            this.lbbopaqid.Text = "Ingresar id de paquete:";
            this.lbbopaqid.Click += new System.EventHandler(this.label3_Click);
            // 
            // lbbopaqL
            // 
            this.lbbopaqL.AutoSize = true;
            this.lbbopaqL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbopaqL.ForeColor = System.Drawing.Color.White;
            this.lbbopaqL.Location = new System.Drawing.Point(444, 200);
            this.lbbopaqL.Name = "lbbopaqL";
            this.lbbopaqL.Size = new System.Drawing.Size(190, 16);
            this.lbbopaqL.TabIndex = 1;
            this.lbbopaqL.Text = "Ingresar tamaño del paquete L";
            this.lbbopaqL.Click += new System.EventHandler(this.label2_Click);
            // 
            // lbbopaqnombre
            // 
            this.lbbopaqnombre.AutoSize = true;
            this.lbbopaqnombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbopaqnombre.ForeColor = System.Drawing.Color.White;
            this.lbbopaqnombre.Location = new System.Drawing.Point(444, 173);
            this.lbbopaqnombre.Name = "lbbopaqnombre";
            this.lbbopaqnombre.Size = new System.Drawing.Size(181, 16);
            this.lbbopaqnombre.TabIndex = 0;
            this.lbbopaqnombre.Text = "Ingresar nombre de paquete:";
            this.lbbopaqnombre.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.ForeColor = System.Drawing.Color.Red;
            this.btnSalir.Location = new System.Drawing.Point(1166, 403);
            this.btnSalir.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(68, 29);
            this.btnSalir.TabIndex = 8;
            this.btnSalir.Text = "SALIR";
            this.btnSalir.UseVisualStyleBackColor = false;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // eliminarBuloLote
            // 
            this.eliminarBuloLote.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.eliminarBuloLote.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eliminarBuloLote.ForeColor = System.Drawing.Color.Red;
            this.eliminarBuloLote.Location = new System.Drawing.Point(1100, 242);
            this.eliminarBuloLote.Name = "eliminarBuloLote";
            this.eliminarBuloLote.Size = new System.Drawing.Size(94, 29);
            this.eliminarBuloLote.TabIndex = 25;
            this.eliminarBuloLote.Text = "Eliminar";
            this.eliminarBuloLote.UseVisualStyleBackColor = false;
            this.eliminarBuloLote.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(1200, 114);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(68, 29);
            this.button1.TabIndex = 24;
            this.button1.Text = "Buscar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // txtlotea
            // 
            this.txtlotea.Location = new System.Drawing.Point(1101, 186);
            this.txtlotea.Name = "txtlotea";
            this.txtlotea.Size = new System.Drawing.Size(93, 20);
            this.txtlotea.TabIndex = 11;
            this.txtlotea.TextChanged += new System.EventHandler(this.txtlotea_TextChanged);
            // 
            // lbbopaqasignacionlote
            // 
            this.lbbopaqasignacionlote.AutoSize = true;
            this.lbbopaqasignacionlote.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbopaqasignacionlote.Location = new System.Drawing.Point(892, 187);
            this.lbbopaqasignacionlote.Name = "lbbopaqasignacionlote";
            this.lbbopaqasignacionlote.Size = new System.Drawing.Size(180, 16);
            this.lbbopaqasignacionlote.TabIndex = 10;
            this.lbbopaqasignacionlote.Text = "Ingresar Id del lote a asignar:";
            this.lbbopaqasignacionlote.Click += new System.EventHandler(this.label11_Click);
            // 
            // lbbopaqasignacion
            // 
            this.lbbopaqasignacion.AutoSize = true;
            this.lbbopaqasignacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbopaqasignacion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lbbopaqasignacion.Location = new System.Drawing.Point(892, 73);
            this.lbbopaqasignacion.Name = "lbbopaqasignacion";
            this.lbbopaqasignacion.Size = new System.Drawing.Size(283, 24);
            this.lbbopaqasignacion.TabIndex = 9;
            this.lbbopaqasignacion.Text = "Asignacion de paquete a lote";
            this.lbbopaqasignacion.Click += new System.EventHandler(this.label9_Click);
            // 
            // txtidbulto
            // 
            this.txtidbulto.Location = new System.Drawing.Point(1101, 119);
            this.txtidbulto.Name = "txtidbulto";
            this.txtidbulto.Size = new System.Drawing.Size(93, 20);
            this.txtidbulto.TabIndex = 8;
            this.txtidbulto.TextChanged += new System.EventHandler(this.txtidbulto_TextChanged);
            // 
            // btnAsignarBultoLote
            // 
            this.btnAsignarBultoLote.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnAsignarBultoLote.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAsignarBultoLote.ForeColor = System.Drawing.Color.Green;
            this.btnAsignarBultoLote.Location = new System.Drawing.Point(968, 242);
            this.btnAsignarBultoLote.Name = "btnAsignarBultoLote";
            this.btnAsignarBultoLote.Size = new System.Drawing.Size(94, 29);
            this.btnAsignarBultoLote.TabIndex = 7;
            this.btnAsignarBultoLote.Text = "Asignar";
            this.btnAsignarBultoLote.UseVisualStyleBackColor = false;
            this.btnAsignarBultoLote.Click += new System.EventHandler(this.btnAsignarPaquete_Click);
            // 
            // lbbopaqidpaquete
            // 
            this.lbbopaqidpaquete.AutoSize = true;
            this.lbbopaqidpaquete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbopaqidpaquete.Location = new System.Drawing.Point(892, 121);
            this.lbbopaqidpaquete.Name = "lbbopaqidpaquete";
            this.lbbopaqidpaquete.Size = new System.Drawing.Size(208, 16);
            this.lbbopaqidpaquete.TabIndex = 0;
            this.lbbopaqidpaquete.Text = "Ingresar Id del paquete a asignar:";
            this.lbbopaqidpaquete.Click += new System.EventHandler(this.label7_Click);
            // 
            // txtalmacenlote
            // 
            this.txtalmacenlote.Location = new System.Drawing.Point(703, 466);
            this.txtalmacenlote.Name = "txtalmacenlote";
            this.txtalmacenlote.Size = new System.Drawing.Size(68, 20);
            this.txtalmacenlote.TabIndex = 21;
            this.txtalmacenlote.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lbbopaqidalmacen
            // 
            this.lbbopaqidalmacen.AutoSize = true;
            this.lbbopaqidalmacen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbopaqidalmacen.Location = new System.Drawing.Point(444, 466);
            this.lbbopaqidalmacen.Name = "lbbopaqidalmacen";
            this.lbbopaqidalmacen.Size = new System.Drawing.Size(255, 16);
            this.lbbopaqidalmacen.TabIndex = 20;
            this.lbbopaqidalmacen.Text = "Ingresar id del almacen al que pertenece:";
            // 
            // btneliminarlote
            // 
            this.btneliminarlote.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btneliminarlote.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btneliminarlote.ForeColor = System.Drawing.Color.Red;
            this.btneliminarlote.Location = new System.Drawing.Point(796, 504);
            this.btneliminarlote.Name = "btneliminarlote";
            this.btneliminarlote.Size = new System.Drawing.Size(68, 29);
            this.btneliminarlote.TabIndex = 19;
            this.btneliminarlote.Text = "Eliminar";
            this.btneliminarlote.UseVisualStyleBackColor = false;
            this.btneliminarlote.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnregistrarlote
            // 
            this.btnregistrarlote.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnregistrarlote.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnregistrarlote.ForeColor = System.Drawing.Color.Green;
            this.btnregistrarlote.Location = new System.Drawing.Point(796, 461);
            this.btnregistrarlote.Name = "btnregistrarlote";
            this.btnregistrarlote.Size = new System.Drawing.Size(68, 29);
            this.btnregistrarlote.TabIndex = 18;
            this.btnregistrarlote.Text = "Registrar";
            this.btnregistrarlote.UseVisualStyleBackColor = false;
            this.btnregistrarlote.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnBuscarLote
            // 
            this.btnBuscarLote.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarLote.ForeColor = System.Drawing.Color.Black;
            this.btnBuscarLote.Location = new System.Drawing.Point(723, 407);
            this.btnBuscarLote.Name = "btnBuscarLote";
            this.btnBuscarLote.Size = new System.Drawing.Size(68, 29);
            this.btnBuscarLote.TabIndex = 16;
            this.btnBuscarLote.Text = "Buscar";
            this.btnBuscarLote.UseVisualStyleBackColor = true;
            this.btnBuscarLote.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // txtIdLote
            // 
            this.txtIdLote.Location = new System.Drawing.Point(575, 412);
            this.txtIdLote.Name = "txtIdLote";
            this.txtIdLote.Size = new System.Drawing.Size(140, 20);
            this.txtIdLote.TabIndex = 6;
            // 
            // lbbopaqlote
            // 
            this.lbbopaqlote.AutoSize = true;
            this.lbbopaqlote.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbopaqlote.Location = new System.Drawing.Point(444, 411);
            this.lbbopaqlote.Name = "lbbopaqlote";
            this.lbbopaqlote.Size = new System.Drawing.Size(118, 16);
            this.lbbopaqlote.TabIndex = 3;
            this.lbbopaqlote.Text = "Ingresar id de lote:";
            // 
            // gridpaquetes
            // 
            this.gridpaquetes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridpaquetes.GridColor = System.Drawing.Color.Black;
            this.gridpaquetes.Location = new System.Drawing.Point(2, 3);
            this.gridpaquetes.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.gridpaquetes.Name = "gridpaquetes";
            this.gridpaquetes.RowTemplate.Height = 24;
            this.gridpaquetes.Size = new System.Drawing.Size(333, 83);
            this.gridpaquetes.TabIndex = 22;
            this.gridpaquetes.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // gridlotes
            // 
            this.gridlotes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridlotes.Location = new System.Drawing.Point(2, 0);
            this.gridlotes.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.gridlotes.Name = "gridlotes";
            this.gridlotes.RowTemplate.Height = 24;
            this.gridlotes.Size = new System.Drawing.Size(337, 101);
            this.gridlotes.TabIndex = 23;
            this.gridlotes.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridlotes_CellContentClick);
            // 
            // gridbultolote
            // 
            this.gridbultolote.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridbultolote.Dock = System.Windows.Forms.DockStyle.Top;
            this.gridbultolote.Location = new System.Drawing.Point(0, 0);
            this.gridbultolote.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.gridbultolote.Name = "gridbultolote";
            this.gridbultolote.RowTemplate.Height = 24;
            this.gridbultolote.Size = new System.Drawing.Size(331, 99);
            this.gridbultolote.TabIndex = 24;
            this.gridbultolote.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridbultolote_CellContentClick);
            // 
            // lbbopaqlistar
            // 
            this.lbbopaqlistar.AutoSize = true;
            this.lbbopaqlistar.BackColor = System.Drawing.Color.Transparent;
            this.lbbopaqlistar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbopaqlistar.ForeColor = System.Drawing.Color.White;
            this.lbbopaqlistar.Location = new System.Drawing.Point(12, 26);
            this.lbbopaqlistar.Name = "lbbopaqlistar";
            this.lbbopaqlistar.Size = new System.Drawing.Size(307, 18);
            this.lbbopaqlistar.TabIndex = 26;
            this.lbbopaqlistar.Text = "Listar paquetes de un lote en especifico";
            // 
            // txtidlotebulto
            // 
            this.txtidlotebulto.Location = new System.Drawing.Point(160, 72);
            this.txtidlotebulto.Name = "txtidlotebulto";
            this.txtidlotebulto.Size = new System.Drawing.Size(86, 20);
            this.txtidlotebulto.TabIndex = 24;
            // 
            // lbbopaqidlote
            // 
            this.lbbopaqidlote.AutoSize = true;
            this.lbbopaqidlote.BackColor = System.Drawing.Color.Transparent;
            this.lbbopaqidlote.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbopaqidlote.ForeColor = System.Drawing.Color.White;
            this.lbbopaqidlote.Location = new System.Drawing.Point(12, 73);
            this.lbbopaqidlote.Name = "lbbopaqidlote";
            this.lbbopaqidlote.Size = new System.Drawing.Size(142, 16);
            this.lbbopaqidlote.TabIndex = 28;
            this.lbbopaqidlote.Text = "Ingresar id del lote:";
            this.lbbopaqidlote.Click += new System.EventHandler(this.label15_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(252, 68);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(69, 27);
            this.button2.TabIndex = 26;
            this.button2.Text = "Buscar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_2);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.panelListaLotes);
            this.panel1.Controls.Add(this.panelListaPaquetes);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.lbbopaqlistarpaquetes);
            this.panel1.Controls.Add(this.lbbopaqlistarlote);
            this.panel1.Controls.Add(this.panelPaquetesBus);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(335, 592);
            this.panel1.TabIndex = 29;
            // 
            // panelListaLotes
            // 
            this.panelListaLotes.BackColor = System.Drawing.Color.White;
            this.panelListaLotes.Controls.Add(this.gridlotes);
            this.panelListaLotes.Location = new System.Drawing.Point(3, 491);
            this.panelListaLotes.Name = "panelListaLotes";
            this.panelListaLotes.Size = new System.Drawing.Size(335, 103);
            this.panelListaLotes.TabIndex = 5;
            // 
            // panelListaPaquetes
            // 
            this.panelListaPaquetes.BackColor = System.Drawing.Color.Black;
            this.panelListaPaquetes.Controls.Add(this.gridpaquetes);
            this.panelListaPaquetes.Location = new System.Drawing.Point(0, 346);
            this.panelListaPaquetes.Name = "panelListaPaquetes";
            this.panelListaPaquetes.Size = new System.Drawing.Size(335, 90);
            this.panelListaPaquetes.TabIndex = 4;
            // 
            // button5
            // 
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(0, 437);
            this.button5.Name = "button5";
            this.button5.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.button5.Size = new System.Drawing.Size(335, 62);
            this.button5.TabIndex = 3;
            this.button5.Text = "Lista de lotes";
            this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // lbbopaqlistarpaquetes
            // 
            this.lbbopaqlistarpaquetes.FlatAppearance.BorderSize = 0;
            this.lbbopaqlistarpaquetes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbbopaqlistarpaquetes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbopaqlistarpaquetes.Location = new System.Drawing.Point(0, 280);
            this.lbbopaqlistarpaquetes.Name = "lbbopaqlistarpaquetes";
            this.lbbopaqlistarpaquetes.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.lbbopaqlistarpaquetes.Size = new System.Drawing.Size(335, 60);
            this.lbbopaqlistarpaquetes.TabIndex = 2;
            this.lbbopaqlistarpaquetes.Text = "Lista de paquetes";
            this.lbbopaqlistarpaquetes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbbopaqlistarpaquetes.UseVisualStyleBackColor = true;
            this.lbbopaqlistarpaquetes.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // lbbopaqlistarlote
            // 
            this.lbbopaqlistarlote.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbbopaqlistarlote.FlatAppearance.BorderSize = 0;
            this.lbbopaqlistarlote.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbbopaqlistarlote.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbopaqlistarlote.Location = new System.Drawing.Point(0, 109);
            this.lbbopaqlistarlote.Name = "lbbopaqlistarlote";
            this.lbbopaqlistarlote.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.lbbopaqlistarlote.Size = new System.Drawing.Size(335, 52);
            this.lbbopaqlistarlote.TabIndex = 0;
            this.lbbopaqlistarlote.Text = "Lista de paquetes del lote buscado";
            this.lbbopaqlistarlote.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbbopaqlistarlote.UseVisualStyleBackColor = true;
            this.lbbopaqlistarlote.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // panelPaquetesBus
            // 
            this.panelPaquetesBus.BackColor = System.Drawing.Color.White;
            this.panelPaquetesBus.Controls.Add(this.gridbultolote);
            this.panelPaquetesBus.ForeColor = System.Drawing.Color.White;
            this.panelPaquetesBus.Location = new System.Drawing.Point(0, 186);
            this.panelPaquetesBus.Name = "panelPaquetesBus";
            this.panelPaquetesBus.Size = new System.Drawing.Size(331, 128);
            this.panelPaquetesBus.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbbopaqidlote);
            this.panel2.Controls.Add(this.lbbopaqlistar);
            this.panel2.Controls.Add(this.txtidlotebulto);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(335, 109);
            this.panel2.TabIndex = 0;
            // 
            // lbbopaqregistro
            // 
            this.lbbopaqregistro.AutoSize = true;
            this.lbbopaqregistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbopaqregistro.Location = new System.Drawing.Point(439, 72);
            this.lbbopaqregistro.Name = "lbbopaqregistro";
            this.lbbopaqregistro.Size = new System.Drawing.Size(209, 24);
            this.lbbopaqregistro.TabIndex = 30;
            this.lbbopaqregistro.Text = "Registro de paquetes";
            // 
            // lbbopaqregistrolotes
            // 
            this.lbbopaqregistrolotes.AutoSize = true;
            this.lbbopaqregistrolotes.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbopaqregistrolotes.Location = new System.Drawing.Point(443, 366);
            this.lbbopaqregistrolotes.Name = "lbbopaqregistrolotes";
            this.lbbopaqregistrolotes.Size = new System.Drawing.Size(167, 24);
            this.lbbopaqregistrolotes.TabIndex = 31;
            this.lbbopaqregistrolotes.Text = "Registro de lotes\r\n";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button6.Location = new System.Drawing.Point(796, 407);
            this.button6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(68, 29);
            this.button6.TabIndex = 32;
            this.button6.Text = "LIMPIAR";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button7.Location = new System.Drawing.Point(1200, 146);
            this.button7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(68, 29);
            this.button7.TabIndex = 33;
            this.button7.Text = "LIMPIAR";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // registroPaquetesApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1278, 592);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.lbbopaqregistrolotes);
            this.Controls.Add(this.lbbopaqregistro);
            this.Controls.Add(this.eliminarBuloLote);
            this.Controls.Add(this.txtalmacenlote);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboestado);
            this.Controls.Add(this.txtlotea);
            this.Controls.Add(this.lbbopaqidalmacen);
            this.Controls.Add(this.lbbopaqasignacionlote);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lbbopaqasignacion);
            this.Controls.Add(this.txtidbulto);
            this.Controls.Add(this.btneliminarlote);
            this.Controls.Add(this.btnAsignarBultoLote);
            this.Controls.Add(this.btnlimpiar);
            this.Controls.Add(this.lbbopaqidpaquete);
            this.Controls.Add(this.btnregistrarlote);
            this.Controls.Add(this.btnBuscarLote);
            this.Controls.Add(this.txtci);
            this.Controls.Add(this.txtIdLote);
            this.Controls.Add(this.lbbopaqlote);
            this.Controls.Add(this.lbbopaqestado);
            this.Controls.Add(this.lbbopaqci);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.lbbopaqkg);
            this.Controls.Add(this.lbbopaqid);
            this.Controls.Add(this.txtPesoPaquete);
            this.Controls.Add(this.lbbopaqnombre);
            this.Controls.Add(this.btnbuscar);
            this.Controls.Add(this.lbbopaqL);
            this.Controls.Add(this.btnModificar);
            this.Controls.Add(this.txtNombrePaquete);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.txtTamanioPaquete);
            this.Controls.Add(this.btnRegistrar);
            this.Controls.Add(this.txtIdPaquete);
            this.ForeColor = System.Drawing.Color.White;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "registroPaquetesApp";
            this.Text = "Registro paquetes";
            this.Load += new System.EventHandler(this.registroPaquetesApp_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridpaquetes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridlotes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridbultolote)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panelListaLotes.ResumeLayout(false);
            this.panelListaPaquetes.ResumeLayout(false);
            this.panelPaquetesBus.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.TextBox txtIdPaquete;
        private System.Windows.Forms.TextBox txtTamanioPaquete;
        private System.Windows.Forms.TextBox txtNombrePaquete;
        private System.Windows.Forms.Label lbbopaqid;
        private System.Windows.Forms.Label lbbopaqL;
        private System.Windows.Forms.Label lbbopaqnombre;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.Label lbbopaqasignacion;
        private System.Windows.Forms.TextBox txtidbulto;
        private System.Windows.Forms.Button btnAsignarBultoLote;
        private System.Windows.Forms.Label lbbopaqidpaquete;
        private System.Windows.Forms.Button btnbuscar;
        private System.Windows.Forms.Label lbbopaqkg;
        private System.Windows.Forms.TextBox txtPesoPaquete;
        private System.Windows.Forms.Button btneliminarlote;
        private System.Windows.Forms.Button btnregistrarlote;
        private System.Windows.Forms.Button btnBuscarLote;
        private System.Windows.Forms.TextBox txtIdLote;
        private System.Windows.Forms.Label lbbopaqlote;
        private System.Windows.Forms.TextBox txtci;
        private System.Windows.Forms.Label lbbopaqestado;
        private System.Windows.Forms.Label lbbopaqci;
        private System.Windows.Forms.Button btnlimpiar;
        private System.Windows.Forms.TextBox txtlotea;
        private System.Windows.Forms.Label lbbopaqasignacionlote;
        private System.Windows.Forms.DataGridView gridpaquetes;
        private System.Windows.Forms.DataGridView gridlotes;
        private System.Windows.Forms.TextBox txtalmacenlote;
        private System.Windows.Forms.Label lbbopaqidalmacen;
        private System.Windows.Forms.ComboBox comboestado;
        private System.Windows.Forms.Button eliminarBuloLote;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView gridbultolote;
        private System.Windows.Forms.Label lbbopaqlistar;
        private System.Windows.Forms.TextBox txtidlotebulto;
        private System.Windows.Forms.Label lbbopaqidlote;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbbopaqregistro;
        private System.Windows.Forms.Label lbbopaqregistrolotes;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button lbbopaqlistarlote;
        private System.Windows.Forms.Panel panelPaquetesBus;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button lbbopaqlistarpaquetes;
        private System.Windows.Forms.Panel panelListaLotes;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Panel panelListaPaquetes;
    }
}