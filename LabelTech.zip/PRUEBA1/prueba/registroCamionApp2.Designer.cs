﻿namespace prueba
{
    partial class registroCamionApp2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(registroCamionApp2));
            this.btnSalir = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.btndesasignarcamionlote = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.txtCamionA = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtCamioneroA = new System.Windows.Forms.TextBox();
            this.txtcamionlote = new System.Windows.Forms.TextBox();
            this.lbbocammatriculalote = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lbbocamasignacion = new System.Windows.Forms.Label();
            this.btnAsignarcamionLote = new System.Windows.Forms.Button();
            this.txtlotecamion = new System.Windows.Forms.TextBox();
            this.lbbocamlote = new System.Windows.Forms.Label();
            this.gridcamiones = new System.Windows.Forms.DataGridView();
            this.gridmanejar = new System.Windows.Forms.DataGridView();
            this.lbbocamlistas = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnlistacamiones = new System.Windows.Forms.Button();
            this.btnlistasasignados = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.panelListaCamiones = new System.Windows.Forms.Panel();
            this.panelListaCamionesA = new System.Windows.Forms.Panel();
            this.lbbocammatricula = new System.Windows.Forms.Label();
            this.lbbocamlitros = new System.Windows.Forms.Label();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtLtsCamion = new System.Windows.Forms.TextBox();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.btnModificar = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.lbbocamkg = new System.Windows.Forms.Label();
            this.txtKgsCamion = new System.Windows.Forms.TextBox();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.lbbocamregistro = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panelListaLotesA = new System.Windows.Forms.Panel();
            this.gridcamionlote = new System.Windows.Forms.DataGridView();
            this.lbbocammin = new System.Windows.Forms.Label();
            this.hs = new System.Windows.Forms.Label();
            this.dia = new System.Windows.Forms.Label();
            this.mes = new System.Windows.Forms.Label();
            this.lbbocamanio = new System.Windows.Forms.Label();
            this.txtmin = new System.Windows.Forms.TextBox();
            this.txths = new System.Windows.Forms.TextBox();
            this.txtdia = new System.Windows.Forms.TextBox();
            this.txtmes = new System.Windows.Forms.TextBox();
            this.txtanio = new System.Windows.Forms.TextBox();
            this.fecha2 = new System.Windows.Forms.Label();
            this.lbbocamfecha1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gridcamiones)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridmanejar)).BeginInit();
            this.panel2.SuspendLayout();
            this.panelListaCamiones.SuspendLayout();
            this.panelListaCamionesA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panelListaLotesA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridcamionlote)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSalir
            // 
            this.btnSalir.BackColor = System.Drawing.Color.AliceBlue;
            this.btnSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.ForeColor = System.Drawing.Color.Red;
            this.btnSalir.Location = new System.Drawing.Point(592, 756);
            this.btnSalir.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(91, 36);
            this.btnSalir.TabIndex = 13;
            this.btnSalir.Text = "SALIR";
            this.btnSalir.UseVisualStyleBackColor = false;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.Black;
            this.button8.Location = new System.Drawing.Point(465, 640);
            this.button8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(91, 36);
            this.button8.TabIndex = 27;
            this.button8.Text = "Buscar";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.Black;
            this.button6.Location = new System.Drawing.Point(492, 384);
            this.button6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(91, 36);
            this.button6.TabIndex = 26;
            this.button6.Text = "Buscar";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.Red;
            this.button5.Location = new System.Drawing.Point(172, 756);
            this.button5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(125, 36);
            this.button5.TabIndex = 23;
            this.button5.Text = "deasignar";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // btndesasignarcamionlote
            // 
            this.btndesasignarcamionlote.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndesasignarcamionlote.ForeColor = System.Drawing.Color.Red;
            this.btndesasignarcamionlote.Location = new System.Drawing.Point(172, 527);
            this.btndesasignarcamionlote.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btndesasignarcamionlote.Name = "btndesasignarcamionlote";
            this.btndesasignarcamionlote.Size = new System.Drawing.Size(125, 36);
            this.btndesasignarcamionlote.TabIndex = 22;
            this.btndesasignarcamionlote.Text = "desasignar";
            this.btndesasignarcamionlote.UseVisualStyleBackColor = true;
            this.btndesasignarcamionlote.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.AliceBlue;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button2.Location = new System.Drawing.Point(465, 702);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(91, 25);
            this.button2.TabIndex = 21;
            this.button2.Text = "LIMPIAR";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.AliceBlue;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button1.Location = new System.Drawing.Point(492, 434);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 27);
            this.button1.TabIndex = 20;
            this.button1.Text = "LIMPIAR";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.Blue;
            this.button7.Location = new System.Drawing.Point(380, 756);
            this.button7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(125, 36);
            this.button7.TabIndex = 18;
            this.button7.Text = "Asignar";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // txtCamionA
            // 
            this.txtCamionA.Location = new System.Drawing.Point(336, 702);
            this.txtCamionA.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtCamionA.Name = "txtCamionA";
            this.txtCamionA.Size = new System.Drawing.Size(119, 22);
            this.txtCamionA.TabIndex = 17;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(81, 702);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(225, 20);
            this.label14.TabIndex = 16;
            this.label14.Text = "Ingrese matricula de camion:";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // txtCamioneroA
            // 
            this.txtCamioneroA.Location = new System.Drawing.Point(340, 646);
            this.txtCamioneroA.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtCamioneroA.Name = "txtCamioneroA";
            this.txtCamioneroA.Size = new System.Drawing.Size(115, 22);
            this.txtCamioneroA.TabIndex = 15;
            // 
            // txtcamionlote
            // 
            this.txtcamionlote.Location = new System.Drawing.Point(323, 433);
            this.txtcamionlote.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtcamionlote.Name = "txtcamionlote";
            this.txtcamionlote.Size = new System.Drawing.Size(132, 22);
            this.txtcamionlote.TabIndex = 14;
            this.txtcamionlote.TextChanged += new System.EventHandler(this.txtMatriculaA_TextChanged);
            // 
            // lbbocammatriculalote
            // 
            this.lbbocammatriculalote.AutoSize = true;
            this.lbbocammatriculalote.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbocammatriculalote.ForeColor = System.Drawing.Color.White;
            this.lbbocammatriculalote.Location = new System.Drawing.Point(81, 434);
            this.lbbocammatriculalote.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbbocammatriculalote.Name = "lbbocammatriculalote";
            this.lbbocammatriculalote.Size = new System.Drawing.Size(225, 20);
            this.lbbocammatriculalote.TabIndex = 13;
            this.lbbocammatriculalote.Text = "Ingrese matricula de camion:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(81, 647);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(233, 20);
            this.label12.TabIndex = 12;
            this.label12.Text = "Ingrese cedula del camionero:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label11.Location = new System.Drawing.Point(81, 591);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(340, 24);
            this.label11.TabIndex = 11;
            this.label11.Text = "Asignacion de camion a camionero";
            // 
            // lbbocamasignacion
            // 
            this.lbbocamasignacion.AutoSize = true;
            this.lbbocamasignacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbocamasignacion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lbbocamasignacion.Location = new System.Drawing.Point(81, 331);
            this.lbbocamasignacion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbbocamasignacion.Name = "lbbocamasignacion";
            this.lbbocamasignacion.Size = new System.Drawing.Size(275, 24);
            this.lbbocamasignacion.TabIndex = 10;
            this.lbbocamasignacion.Text = "Asignacion de lote a camion";
            // 
            // btnAsignarcamionLote
            // 
            this.btnAsignarcamionLote.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAsignarcamionLote.ForeColor = System.Drawing.Color.Blue;
            this.btnAsignarcamionLote.Location = new System.Drawing.Point(380, 527);
            this.btnAsignarcamionLote.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAsignarcamionLote.Name = "btnAsignarcamionLote";
            this.btnAsignarcamionLote.Size = new System.Drawing.Size(125, 36);
            this.btnAsignarcamionLote.TabIndex = 8;
            this.btnAsignarcamionLote.Text = "Asignar";
            this.btnAsignarcamionLote.UseVisualStyleBackColor = true;
            this.btnAsignarcamionLote.Click += new System.EventHandler(this.btnAsignarLote_Click);
            // 
            // txtlotecamion
            // 
            this.txtlotecamion.Location = new System.Drawing.Point(309, 390);
            this.txtlotecamion.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtlotecamion.Name = "txtlotecamion";
            this.txtlotecamion.Size = new System.Drawing.Size(145, 22);
            this.txtlotecamion.TabIndex = 1;
            // 
            // lbbocamlote
            // 
            this.lbbocamlote.AutoSize = true;
            this.lbbocamlote.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbocamlote.ForeColor = System.Drawing.Color.White;
            this.lbbocamlote.Location = new System.Drawing.Point(81, 390);
            this.lbbocamlote.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbbocamlote.Name = "lbbocamlote";
            this.lbbocamlote.Size = new System.Drawing.Size(181, 20);
            this.lbbocamlote.TabIndex = 0;
            this.lbbocamlote.Text = "Ingresar lote a asignar:";
            // 
            // gridcamiones
            // 
            this.gridcamiones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridcamiones.Location = new System.Drawing.Point(0, 2);
            this.gridcamiones.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gridcamiones.Name = "gridcamiones";
            this.gridcamiones.RowTemplate.Height = 24;
            this.gridcamiones.Size = new System.Drawing.Size(351, 156);
            this.gridcamiones.TabIndex = 19;
            this.gridcamiones.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // gridmanejar
            // 
            this.gridmanejar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridmanejar.Location = new System.Drawing.Point(0, 0);
            this.gridmanejar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gridmanejar.Name = "gridmanejar";
            this.gridmanejar.RowTemplate.Height = 24;
            this.gridmanejar.Size = new System.Drawing.Size(353, 155);
            this.gridmanejar.TabIndex = 23;
            this.gridmanejar.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridmanejar_CellContentClick);
            // 
            // lbbocamlistas
            // 
            this.lbbocamlistas.AutoSize = true;
            this.lbbocamlistas.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbocamlistas.ForeColor = System.Drawing.Color.White;
            this.lbbocamlistas.Location = new System.Drawing.Point(125, 57);
            this.lbbocamlistas.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbbocamlistas.Name = "lbbocamlistas";
            this.lbbocamlistas.Size = new System.Drawing.Size(81, 29);
            this.lbbocamlistas.TabIndex = 24;
            this.lbbocamlistas.Text = "Listas";
            this.lbbocamlistas.Click += new System.EventHandler(this.lbbocamlistas_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbbocamlistas);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(351, 134);
            this.panel2.TabIndex = 25;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // btnlistacamiones
            // 
            this.btnlistacamiones.FlatAppearance.BorderSize = 0;
            this.btnlistacamiones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnlistacamiones.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlistacamiones.ForeColor = System.Drawing.Color.White;
            this.btnlistacamiones.Location = new System.Drawing.Point(0, 138);
            this.btnlistacamiones.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnlistacamiones.Name = "btnlistacamiones";
            this.btnlistacamiones.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnlistacamiones.Size = new System.Drawing.Size(349, 76);
            this.btnlistacamiones.TabIndex = 26;
            this.btnlistacamiones.Text = "Camiones";
            this.btnlistacamiones.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnlistacamiones.UseVisualStyleBackColor = true;
            this.btnlistacamiones.Click += new System.EventHandler(this.button3_Click_2);
            // 
            // btnlistasasignados
            // 
            this.btnlistasasignados.BackColor = System.Drawing.Color.Black;
            this.btnlistasasignados.FlatAppearance.BorderSize = 0;
            this.btnlistasasignados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnlistasasignados.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlistasasignados.ForeColor = System.Drawing.Color.White;
            this.btnlistasasignados.Location = new System.Drawing.Point(0, 362);
            this.btnlistasasignados.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnlistasasignados.Name = "btnlistasasignados";
            this.btnlistasasignados.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnlistasasignados.Size = new System.Drawing.Size(353, 76);
            this.btnlistasasignados.TabIndex = 27;
            this.btnlistasasignados.Text = "Lotes asignados a camiones";
            this.btnlistasasignados.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnlistasasignados.UseVisualStyleBackColor = false;
            this.btnlistasasignados.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Black;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(0, 591);
            this.button10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button10.Name = "button10";
            this.button10.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.button10.Size = new System.Drawing.Size(353, 76);
            this.button10.TabIndex = 28;
            this.button10.Text = "Camioneros asignados a camiones";
            this.button10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // panelListaCamiones
            // 
            this.panelListaCamiones.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panelListaCamiones.Controls.Add(this.gridcamiones);
            this.panelListaCamiones.Location = new System.Drawing.Point(0, 207);
            this.panelListaCamiones.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelListaCamiones.Name = "panelListaCamiones";
            this.panelListaCamiones.Size = new System.Drawing.Size(349, 159);
            this.panelListaCamiones.TabIndex = 29;
            // 
            // panelListaCamionesA
            // 
            this.panelListaCamionesA.BackColor = System.Drawing.Color.White;
            this.panelListaCamionesA.Controls.Add(this.gridmanejar);
            this.panelListaCamionesA.Location = new System.Drawing.Point(4, 665);
            this.panelListaCamionesA.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelListaCamionesA.Name = "panelListaCamionesA";
            this.panelListaCamionesA.Size = new System.Drawing.Size(353, 155);
            this.panelListaCamionesA.TabIndex = 31;
            // 
            // lbbocammatricula
            // 
            this.lbbocammatricula.AutoSize = true;
            this.lbbocammatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbocammatricula.ForeColor = System.Drawing.Color.White;
            this.lbbocammatricula.Location = new System.Drawing.Point(81, 121);
            this.lbbocammatricula.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbbocammatricula.Name = "lbbocammatricula";
            this.lbbocammatricula.Size = new System.Drawing.Size(231, 20);
            this.lbbocammatricula.TabIndex = 0;
            this.lbbocammatricula.Text = "Ingresar matricula de camion:";
            // 
            // lbbocamlitros
            // 
            this.lbbocamlitros.AutoSize = true;
            this.lbbocamlitros.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbocamlitros.ForeColor = System.Drawing.Color.White;
            this.lbbocamlitros.Location = new System.Drawing.Point(81, 185);
            this.lbbocamlitros.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbbocamlitros.Name = "lbbocamlitros";
            this.lbbocamlitros.Size = new System.Drawing.Size(302, 20);
            this.lbbocamlitros.TabIndex = 1;
            this.lbbocamlitros.Text = "Ingresar capacidad de camion (en Lts):";
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrar.ForeColor = System.Drawing.Color.Green;
            this.btnRegistrar.Location = new System.Drawing.Point(592, 169);
            this.btnRegistrar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(91, 36);
            this.btnRegistrar.TabIndex = 7;
            this.btnRegistrar.Text = "Registrar";
            this.btnRegistrar.UseVisualStyleBackColor = true;
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrarCamion_Click);
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(336, 119);
            this.txtMatricula.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(132, 22);
            this.txtMatricula.TabIndex = 8;
            // 
            // txtLtsCamion
            // 
            this.txtLtsCamion.Location = new System.Drawing.Point(417, 180);
            this.txtLtsCamion.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtLtsCamion.Name = "txtLtsCamion";
            this.txtLtsCamion.Size = new System.Drawing.Size(149, 22);
            this.txtLtsCamion.TabIndex = 9;
            // 
            // btnEliminar
            // 
            this.btnEliminar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminar.ForeColor = System.Drawing.Color.Red;
            this.btnEliminar.Location = new System.Drawing.Point(592, 219);
            this.btnEliminar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(91, 36);
            this.btnEliminar.TabIndex = 12;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminarCamion_Click);
            // 
            // btnModificar
            // 
            this.btnModificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnModificar.Location = new System.Drawing.Point(592, 273);
            this.btnModificar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(91, 36);
            this.btnModificar.TabIndex = 21;
            this.btnModificar.Text = "Modificar";
            this.btnModificar.UseVisualStyleBackColor = true;
            this.btnModificar.Click += new System.EventHandler(this.btnModificarCamion_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.Black;
            this.button4.Location = new System.Drawing.Point(477, 113);
            this.button4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(91, 36);
            this.button4.TabIndex = 23;
            this.button4.Text = "Buscar";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // lbbocamkg
            // 
            this.lbbocamkg.AutoSize = true;
            this.lbbocamkg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbocamkg.ForeColor = System.Drawing.Color.White;
            this.lbbocamkg.Location = new System.Drawing.Point(81, 222);
            this.lbbocamkg.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbbocamkg.Name = "lbbocamkg";
            this.lbbocamkg.Size = new System.Drawing.Size(307, 20);
            this.lbbocamkg.TabIndex = 24;
            this.lbbocamkg.Text = "Ingresar capacidad de camion (en Kgs):";
            // 
            // txtKgsCamion
            // 
            this.txtKgsCamion.Location = new System.Drawing.Point(417, 220);
            this.txtKgsCamion.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtKgsCamion.Name = "txtKgsCamion";
            this.txtKgsCamion.Size = new System.Drawing.Size(149, 22);
            this.txtKgsCamion.TabIndex = 25;
            this.txtKgsCamion.TextChanged += new System.EventHandler(this.txtKgsCamion_TextChanged);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.BackColor = System.Drawing.Color.AliceBlue;
            this.btnLimpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnLimpiar.Location = new System.Drawing.Point(592, 113);
            this.btnLimpiar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(91, 36);
            this.btnLimpiar.TabIndex = 19;
            this.btnLimpiar.Text = "LIMPIAR";
            this.btnLimpiar.UseVisualStyleBackColor = false;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // lbbocamregistro
            // 
            this.lbbocamregistro.AutoSize = true;
            this.lbbocamregistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbocamregistro.ForeColor = System.Drawing.Color.White;
            this.lbbocamregistro.Location = new System.Drawing.Point(80, 57);
            this.lbbocamregistro.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbbocamregistro.Name = "lbbocamregistro";
            this.lbbocamregistro.Size = new System.Drawing.Size(268, 29);
            this.lbbocamregistro.TabIndex = 31;
            this.lbbocamregistro.Text = "Registro de camiones";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Location = new System.Drawing.Point(4, 0);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.Black;
            this.splitContainer1.Panel1.Controls.Add(this.panel2);
            this.splitContainer1.Panel1.Controls.Add(this.panelListaLotesA);
            this.splitContainer1.Panel1.Controls.Add(this.button10);
            this.splitContainer1.Panel1.Controls.Add(this.btnlistacamiones);
            this.splitContainer1.Panel1.Controls.Add(this.panelListaCamiones);
            this.splitContainer1.Panel1.Controls.Add(this.btnlistasasignados);
            this.splitContainer1.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Panel1_Paint);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.lbbocammin);
            this.splitContainer1.Panel2.Controls.Add(this.hs);
            this.splitContainer1.Panel2.Controls.Add(this.dia);
            this.splitContainer1.Panel2.Controls.Add(this.mes);
            this.splitContainer1.Panel2.Controls.Add(this.lbbocamanio);
            this.splitContainer1.Panel2.Controls.Add(this.txtmin);
            this.splitContainer1.Panel2.Controls.Add(this.txths);
            this.splitContainer1.Panel2.Controls.Add(this.txtdia);
            this.splitContainer1.Panel2.Controls.Add(this.txtmes);
            this.splitContainer1.Panel2.Controls.Add(this.txtanio);
            this.splitContainer1.Panel2.Controls.Add(this.fecha2);
            this.splitContainer1.Panel2.Controls.Add(this.lbbocamfecha1);
            this.splitContainer1.Panel2.Controls.Add(this.txtCamioneroA);
            this.splitContainer1.Panel2.Controls.Add(this.txtlotecamion);
            this.splitContainer1.Panel2.Controls.Add(this.lbbocamregistro);
            this.splitContainer1.Panel2.Controls.Add(this.lbbocamlote);
            this.splitContainer1.Panel2.Controls.Add(this.button8);
            this.splitContainer1.Panel2.Controls.Add(this.btnAsignarcamionLote);
            this.splitContainer1.Panel2.Controls.Add(this.btnLimpiar);
            this.splitContainer1.Panel2.Controls.Add(this.btnRegistrar);
            this.splitContainer1.Panel2.Controls.Add(this.button6);
            this.splitContainer1.Panel2.Controls.Add(this.lbbocamasignacion);
            this.splitContainer1.Panel2.Controls.Add(this.button5);
            this.splitContainer1.Panel2.Controls.Add(this.lbbocamlitros);
            this.splitContainer1.Panel2.Controls.Add(this.txtKgsCamion);
            this.splitContainer1.Panel2.Controls.Add(this.label11);
            this.splitContainer1.Panel2.Controls.Add(this.btndesasignarcamionlote);
            this.splitContainer1.Panel2.Controls.Add(this.txtMatricula);
            this.splitContainer1.Panel2.Controls.Add(this.button2);
            this.splitContainer1.Panel2.Controls.Add(this.label12);
            this.splitContainer1.Panel2.Controls.Add(this.button1);
            this.splitContainer1.Panel2.Controls.Add(this.lbbocammatricula);
            this.splitContainer1.Panel2.Controls.Add(this.lbbocamkg);
            this.splitContainer1.Panel2.Controls.Add(this.lbbocammatriculalote);
            this.splitContainer1.Panel2.Controls.Add(this.button7);
            this.splitContainer1.Panel2.Controls.Add(this.txtLtsCamion);
            this.splitContainer1.Panel2.Controls.Add(this.btnSalir);
            this.splitContainer1.Panel2.Controls.Add(this.txtcamionlote);
            this.splitContainer1.Panel2.Controls.Add(this.txtCamionA);
            this.splitContainer1.Panel2.Controls.Add(this.btnEliminar);
            this.splitContainer1.Panel2.Controls.Add(this.button4);
            this.splitContainer1.Panel2.Controls.Add(this.btnModificar);
            this.splitContainer1.Panel2.Controls.Add(this.label14);
            this.splitContainer1.Size = new System.Drawing.Size(1069, 820);
            this.splitContainer1.SplitterDistance = 351;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 32;
            // 
            // panelListaLotesA
            // 
            this.panelListaLotesA.BackColor = System.Drawing.Color.White;
            this.panelListaLotesA.Controls.Add(this.gridcamionlote);
            this.panelListaLotesA.Location = new System.Drawing.Point(0, 446);
            this.panelListaLotesA.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelListaLotesA.Name = "panelListaLotesA";
            this.panelListaLotesA.Size = new System.Drawing.Size(353, 155);
            this.panelListaLotesA.TabIndex = 30;
            this.panelListaLotesA.Paint += new System.Windows.Forms.PaintEventHandler(this.panelListaLotesA_Paint);
            // 
            // gridcamionlote
            // 
            this.gridcamionlote.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridcamionlote.Location = new System.Drawing.Point(0, 0);
            this.gridcamionlote.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gridcamionlote.Name = "gridcamionlote";
            this.gridcamionlote.Size = new System.Drawing.Size(353, 155);
            this.gridcamionlote.TabIndex = 0;
            this.gridcamionlote.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridcamionlote_CellContentClick_1);
            // 
            // lbbocammin
            // 
            this.lbbocammin.AutoSize = true;
            this.lbbocammin.ForeColor = System.Drawing.Color.Coral;
            this.lbbocammin.Location = new System.Drawing.Point(441, 462);
            this.lbbocammin.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbbocammin.Name = "lbbocammin";
            this.lbbocammin.Size = new System.Drawing.Size(30, 17);
            this.lbbocammin.TabIndex = 44;
            this.lbbocammin.Text = "min";
            // 
            // hs
            // 
            this.hs.AutoSize = true;
            this.hs.ForeColor = System.Drawing.Color.Coral;
            this.hs.Location = new System.Drawing.Point(413, 460);
            this.hs.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.hs.Name = "hs";
            this.hs.Size = new System.Drawing.Size(23, 17);
            this.hs.TabIndex = 43;
            this.hs.Text = "hs";
            // 
            // dia
            // 
            this.dia.AutoSize = true;
            this.dia.ForeColor = System.Drawing.Color.Coral;
            this.dia.Location = new System.Drawing.Point(385, 462);
            this.dia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.dia.Name = "dia";
            this.dia.Size = new System.Drawing.Size(27, 17);
            this.dia.TabIndex = 42;
            this.dia.Text = "dia";
            // 
            // mes
            // 
            this.mes.AutoSize = true;
            this.mes.ForeColor = System.Drawing.Color.Coral;
            this.mes.Location = new System.Drawing.Point(353, 462);
            this.mes.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.mes.Name = "mes";
            this.mes.Size = new System.Drawing.Size(34, 17);
            this.mes.TabIndex = 41;
            this.mes.Text = "mes";
            // 
            // lbbocamanio
            // 
            this.lbbocamanio.AutoSize = true;
            this.lbbocamanio.ForeColor = System.Drawing.Color.Coral;
            this.lbbocamanio.Location = new System.Drawing.Point(319, 462);
            this.lbbocamanio.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbbocamanio.Name = "lbbocamanio";
            this.lbbocamanio.Size = new System.Drawing.Size(32, 17);
            this.lbbocamanio.TabIndex = 40;
            this.lbbocamanio.Text = "año";
            // 
            // txtmin
            // 
            this.txtmin.Location = new System.Drawing.Point(445, 480);
            this.txtmin.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtmin.Name = "txtmin";
            this.txtmin.Size = new System.Drawing.Size(19, 22);
            this.txtmin.TabIndex = 38;
            // 
            // txths
            // 
            this.txths.Location = new System.Drawing.Point(417, 480);
            this.txths.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txths.Name = "txths";
            this.txths.Size = new System.Drawing.Size(19, 22);
            this.txths.TabIndex = 37;
            // 
            // txtdia
            // 
            this.txtdia.Location = new System.Drawing.Point(389, 481);
            this.txtdia.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtdia.Name = "txtdia";
            this.txtdia.Size = new System.Drawing.Size(19, 22);
            this.txtdia.TabIndex = 36;
            // 
            // txtmes
            // 
            this.txtmes.Location = new System.Drawing.Point(357, 481);
            this.txtmes.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtmes.Name = "txtmes";
            this.txtmes.Size = new System.Drawing.Size(19, 22);
            this.txtmes.TabIndex = 35;
            // 
            // txtanio
            // 
            this.txtanio.Location = new System.Drawing.Point(323, 481);
            this.txtanio.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtanio.Name = "txtanio";
            this.txtanio.Size = new System.Drawing.Size(19, 22);
            this.txtanio.TabIndex = 34;
            // 
            // fecha2
            // 
            this.fecha2.AutoSize = true;
            this.fecha2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fecha2.ForeColor = System.Drawing.Color.White;
            this.fecha2.Location = new System.Drawing.Point(80, 501);
            this.fecha2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.fecha2.Name = "fecha2";
            this.fecha2.Size = new System.Drawing.Size(140, 20);
            this.fecha2.TabIndex = 33;
            this.fecha2.Text = "del lote al camion";
            // 
            // lbbocamfecha1
            // 
            this.lbbocamfecha1.AutoSize = true;
            this.lbbocamfecha1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbocamfecha1.ForeColor = System.Drawing.Color.White;
            this.lbbocamfecha1.Location = new System.Drawing.Point(80, 481);
            this.lbbocamfecha1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbbocamfecha1.Name = "lbbocamfecha1";
            this.lbbocamfecha1.Size = new System.Drawing.Size(223, 20);
            this.lbbocamfecha1.TabIndex = 32;
            this.lbbocamfecha1.Text = "ingrese la fecha de la subida";
            // 
            // registroCamionApp2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1073, 823);
            this.Controls.Add(this.panelListaCamionesA);
            this.Controls.Add(this.splitContainer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MinimumSize = new System.Drawing.Size(1037, 589);
            this.Name = "registroCamionApp2";
            this.Text = "Registro camiones";
            this.Load += new System.EventHandler(this.registroCamionApp2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridcamiones)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridmanejar)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panelListaCamiones.ResumeLayout(false);
            this.panelListaCamionesA.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.panelListaLotesA.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridcamionlote)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox txtCamionA;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtCamioneroA;
        private System.Windows.Forms.TextBox txtcamionlote;
        private System.Windows.Forms.Label lbbocammatriculalote;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lbbocamasignacion;
        private System.Windows.Forms.Button btnAsignarcamionLote;
        private System.Windows.Forms.TextBox txtlotecamion;
        private System.Windows.Forms.Label lbbocamlote;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView gridcamiones;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btndesasignarcamionlote;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.DataGridView gridmanejar;
        private System.Windows.Forms.Label lbbocamlistas;
        private System.Windows.Forms.Button btnlistacamiones;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button btnlistasasignados;
        private System.Windows.Forms.Panel panelListaCamiones;
        private System.Windows.Forms.Panel panelListaCamionesA;
        private System.Windows.Forms.Label lbbocammatricula;
        private System.Windows.Forms.Label lbbocamlitros;
        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtLtsCamion;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label lbbocamkg;
        private System.Windows.Forms.TextBox txtKgsCamion;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Label lbbocamregistro;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label fecha2;
        private System.Windows.Forms.Label lbbocamfecha1;
        private System.Windows.Forms.Label lbbocammin;
        private System.Windows.Forms.Label hs;
        private System.Windows.Forms.Label dia;
        private System.Windows.Forms.Label mes;
        private System.Windows.Forms.Label lbbocamanio;
        private System.Windows.Forms.TextBox txtmin;
        private System.Windows.Forms.TextBox txths;
        private System.Windows.Forms.TextBox txtdia;
        private System.Windows.Forms.TextBox txtmes;
        private System.Windows.Forms.TextBox txtanio;
        private System.Windows.Forms.DataGridView gridcamionlote;
        private System.Windows.Forms.Panel panelListaLotesA;
    }
}