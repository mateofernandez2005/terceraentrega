﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace prueba
{
    class Lote
    {
        protected int _id;
        protected int _idAlmacen;
        protected ADODB.Connection _conexion;

       

        public Lote()
        {
            _conexion = Program.cn;
            _id = 0;
            _idAlmacen = 0;
            

        }

        public Lote(int id, int idAlmacen, ADODB.Connection cn)
        {
            _id = id;
            _idAlmacen = idAlmacen;
            _conexion = cn;
            
        }



        public ADODB.Connection conexion
        {
            get { return (_conexion); }
            set { _conexion = value; }
        }
        public int id
        {
            get { return (_id); }
            set { _id = value; }
        }
        public int idAlmacen
        {
            get { return (_idAlmacen); }
            set { _idAlmacen = value; }
        }

        public int buscarLote()
        {

            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;




            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "select id from lote where id='" + _id + "'";

                try
                {
                    rs = _conexion.Execute(sql, out filasAfectadas);

                    if (!rs.EOF) //encontramos el paquete
                    {
                        return 3;
                    }
                    else //no encontre el paquete
                    {
                        return 2;
                    }
                }
                catch
                {
                    //int num = int.Parse(sql);
                    return 1;
                }
            }
            else
            {
                return 4;
            }
        }
        public DataTable RecordsetToDataTable(ADODB.Recordset recordset)
        {
            DataTable dataTable = new DataTable();

            for (int i = 0; i < recordset.Fields.Count; i++)
            {
                dataTable.Columns.Add(recordset.Fields[i].Name, typeof(string));
            }

            while (!recordset.EOF)
            {
                DataRow dataRow = dataTable.NewRow();
                for (int i = 0; i < recordset.Fields.Count; i++)
                {
                    dataRow[i] = recordset.Fields[i].Value.ToString();
                }
                dataTable.Rows.Add(dataRow);
                recordset.MoveNext();
            }

            return dataTable;
        }

        public DataTable ObtenerDatosLote()
        {

            DataTable dataTable = new DataTable();

            if (_conexion.State != 0)
            {
                //conexion abierta
                string sql = "SELECT * FROM lote;";

                try
                {

                    ADODB.Recordset rs = new ADODB.Recordset();


                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic);


                    dataTable = RecordsetToDataTable(rs);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }


            return dataTable;
        }

        public int registrarLote()
        {
            string sql;
            object filasAfectadas;

            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "INSERT INTO lote (id, id_almacen) VALUES ('" + _id + "', '" + _idAlmacen + "')";

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                    return 3; 
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1; 
                }
            }
            else
            {
                return 2; 
            }
        }
        public int eliminarLote()
        {
            string sql;
            object filasAfectadas;
            int totalFilasAfectadas = 0;

            if (_conexion.State != 0)
            {
                //conexion abierta
                try
                {
                   
                    sql = "DELETE FROM bulto_lote WHERE id_lote=" + _id;
                    _conexion.Execute(sql, out filasAfectadas);
                    totalFilasAfectadas += (int)filasAfectadas;

                   
                    sql = "DELETE FROM camion_lote WHERE id_lote=" + _id;
                    _conexion.Execute(sql, out filasAfectadas);
                    totalFilasAfectadas += (int)filasAfectadas;

                   
                    sql = "DELETE FROM lote WHERE id=" + _id;
                    _conexion.Execute(sql, out filasAfectadas);
                    totalFilasAfectadas += (int)filasAfectadas;

                    if (totalFilasAfectadas > 0) 
                    {
                        return 3;
                    }
                    else 
                    {
                        return 2;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1; // Ocurrió un error
                }
            }
            else
            {
                return 4; // La conexión no está abierta
            }
        }
        public int registrardDatos()
        {
            string sql;
            
            ADODB.Recordset rs;

            object filasAfectadas;

            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "select id_almacen from lote where id='" + _id + "'";
                

                try
                {
                    rs = _conexion.Execute(sql, out filasAfectadas);
                    _idAlmacen = Convert.ToInt32(rs.Fields["id_almacen"].Value);
                    return 3;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }
            }
            else
            {
                return 4;
            }
        }
    }
}
