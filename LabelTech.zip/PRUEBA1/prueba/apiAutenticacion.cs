﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;

namespace prueba
{
    static class apiAutenticacion
    {
 
    internal class usupass
        {
           public String usuario { set; get; }
            public String contraseña { set; get; }
        }

        internal class usurol
        {
            public String usuario { set; get; }
            public byte rol { set; get; }
        }

        public static String ValidoUsuario(String usuarioValido)
        {
            byte rol; String resultado;
            usupass up;
            usurol ur = new usurol();
            Usuario u = new Usuario();
            up = JsonSerializer.Deserialize<usupass>(usuarioValido);
            
            u.usuario = up.usuario;
            u.contrasenia = up.contraseña;
           
            rol = u.ValidoUsuario();
            ur.usuario = u.usuario;
            ur.rol = rol;
            resultado = JsonSerializer.Serialize(ur);
            return (resultado);




        }
}
}