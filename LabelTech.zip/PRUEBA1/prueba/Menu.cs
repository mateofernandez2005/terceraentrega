﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static prueba.Program;

namespace prueba
{
    public partial class Menu : Form
    {
        protected ADODB.Connection _conexion = Program.cn;



        //public bool IsRadioButton1Checked
        //{
        //    get { return radioButton1.Checked; }
        //}

        public ADODB.Connection conexion
        {
            get { return (_conexion); }
            set { _conexion = value; }
        }

        internal class usupass
        {
            public String usuario { set; get; }
            public String contraseña { set; get; }

        }

       


        public Menu()
        {
          

            _conexion = Program.cn;
            InitializeComponent();

            

            panelAppSubMenu.Visible = false;
            almacenero.Enabled = false;
            camionero.Enabled = false;
            backoffice.Enabled = false;
            if (variables.registro == 2)
            {
                camionero.Enabled = true;
            }
            else if (variables.registro == 3)
            {
                almacenero.Enabled = true;
                camionero.Enabled = true;
                backoffice.Enabled = true;

            }
            else if (variables.registro == 1)
            {
                almacenero.Enabled = true;
                
            }

            if (variables.idiom == true)
            {
                almacenero.Text = "grocer";
                camionero.Text = "truck driver";
                cliente.Text = "Customer";
                
            }


        }
        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void camioneroToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        

        private void loginToolStripMenuItem1_Click(object sender, EventArgs e)
        {


            login frmLoginBackoffice = new login();
            this.Hide();
            frmLoginBackoffice.Show();

        }

       

       
        private void backoficeToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip2_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

       
        private void usuarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            camioneroApp frmcamioneroApp = new camioneroApp();
            this.Hide();
            frmcamioneroApp.Show();

        }

        private void almceneroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            almaceneroApp frmalmaceneroApp = new almaceneroApp();
            this.Hide();
            frmalmaceneroApp.Show();


        }

        private void backofficeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            backofficeApp frmBackofficeApp = new backofficeApp();
            this.Hide();
            frmBackofficeApp.Show();
        }

        private void clienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Program P = new Program();
            try
            {
                if(_conexion.State != 0)
                {
                    _conexion.Close();
                }
else
                {
                    _conexion.Open("br", "cliente", "cliente");
                }

           
                
            }


            catch
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error opening connection");
                }
                else
                {
                    MessageBox.Show("error al abrir conexion");
                }
                return;
            }
            //P.conexion.CursorLocation = ADODB.CursorLocationEnum.adUseClient;

            

            



            usuarioApp frmusuarioApp = new usuarioApp();
            this.Hide();
            frmusuarioApp.Show();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Program P = new Program();
            if (_conexion.State != 0)
            {
                _conexion.Close();
                almacenero.Enabled = false;
                camionero.Enabled = false;
                backoffice.Enabled = false;
                if (variables.idiom == true)
                {
                    MessageBox.Show("You logged out, your functions were deactivated");
                }
                else
                {
                    MessageBox.Show("cerraste sesion, se desactivaron tus funciones ");
                }
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("There is no session to close");
                }
                else
                {
                    MessageBox.Show("no hay sesion para cerrar");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            almaceneroApp frmalmaceneroApp = new almaceneroApp();
            this.Hide();
            frmalmaceneroApp.Show();
            hideSubMenu();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            camioneroApp frmcamioneroApp = new camioneroApp();
            this.Hide();
            frmcamioneroApp.Show();
            hideSubMenu();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            backofficeApp frmBackofficeApp = new backofficeApp();
            this.Hide();
            frmBackofficeApp.Show();
            hideSubMenu();

        }

        private void customizeDesign()
        {
            panelAppSubMenu.Visible = false;
        }

        private void hideSubMenu()
        {
            if (panelAppSubMenu.Visible == true)
                panelAppSubMenu.Visible = false;
        }

        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }

        private void btnApps_Click(object sender, EventArgs e)
        {
            showSubMenu(panelAppSubMenu);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {


            login frmLoginBackoffice = new login();
            this.Hide();
            frmLoginBackoffice.Show();
        }

        private void Logout_Click(object sender, EventArgs e)
        {
            Program P = new Program();
            if (_conexion.State != 0)
            {
                _conexion.Close();
                almacenero.Enabled = false;
                camionero.Enabled = false;
                backoffice.Enabled = false;
                if (variables.idiom == true)
                {
                    MessageBox.Show("You logged out, your functions were deactivated");
                }
                else
                {
                    MessageBox.Show("cerraste sesion, se desactivaron tus funciones ");
                }
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("There is no session to close");
                }
                else
                {
                    MessageBox.Show("no hay sesion para cerrar");
                }
            }
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
           
            try
            {
                if (Program.cn.State != 0)
                {
                    Program.cn.Close();
                }
                Program.cn.Open("br", "cliente", "cliente");
                usuarioApp frmusuarioApp = new usuarioApp();
                this.Hide();
                frmusuarioApp.Show();
            }

            catch
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error opening connection");
                }
                else
                {
                    MessageBox.Show("error al abrir conexion");
                }

            }





        }

        private void panelAppSubMenu_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnidioma_Click(object sender, EventArgs e)
        {



            variables.idiom = true;

            almacenero.Text = "grocer";
            camionero.Text = "truck driver";
            cliente.Text = "Customer";


        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

            //GlobalVariables.IsRadioButtonChecked = radioButton1.Checked;
           
            
            
        }

        private void button1_Click_3(object sender, EventArgs e)
        {
            variables.idiom = false;
            almacenero.Text = "almacenero";
            camionero.Text = "camionero";
            cliente.Text = "cliente";
        }
    }
}
