﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace prueba
{
    

    public partial class loginBackoffice : Form
    {
        public loginBackoffice()
        {
            InitializeComponent();
        }

        //SqlConnection conexion = new SqlConnection("server=proyecto; database=MIODBC;");
        private void btnEntrar_Click(object sender, EventArgs e)
        {
            //conexion.Open();
            try
            {
                Program.cn.Open("MIODBC", txtUsuario.Text, txtContraseña.Text);
                //Program.cn.Open ("select * from usuario where (usuario= '" + txtUsuario.Text + "'and contrasenia='" + txtContraseña.Text) ;
            }
            catch
            {
                MessageBox.Show("Usuario o contraseña erròneos");
                return;
            }
            Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
            //Program.frmPrincipal.menuLogin.Text = "logout";
            Program.DoyPermisos(txtUsuario.Text);

            this.Close();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {

            Menu frmMenu = new Menu();
            this.Hide();
            frmMenu.Show();



        }
    }
    }

