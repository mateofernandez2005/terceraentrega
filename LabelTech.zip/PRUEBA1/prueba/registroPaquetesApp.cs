﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace prueba
{

    public partial class registroPaquetesApp : Form
    {
        public static Menu frmMenu;


        protected ADODB.Connection _conexion;

        public ADODB.Connection conexion
        {
            get { return (_conexion); }
            set { _conexion = value; }
        }




        public registroPaquetesApp()
        {
            InitializeComponent();

            panelPaquetesBus.Visible = false;
            panelListaLotes.Visible = false;
            panelListaPaquetes.Visible = false;
            btnAsignarBultoLote.Enabled = false;
            eliminarBuloLote.Enabled = false;
            btnregistrarlote.Enabled = false;
            btneliminarlote.Enabled = false;

            btnEliminar.Enabled = false;
            btnRegistrar.Enabled = false;
            btnModificar.Enabled = false;

            Paquete C = new Paquete();
            gridpaquetes.DataSource = C.ObtenerDatosPaquete();
            gridpaquetes.DefaultCellStyle.ForeColor = Color.Black;
            Lote L = new Lote();
            gridlotes.DataSource = L.ObtenerDatosLote();
            gridlotes.DefaultCellStyle.ForeColor = Color.Black;
            if (variables.idiom == true)
            {
                lbbopaqlistar.Text = "List packages from a specific lot";
                lbbopaqidlote.Text = "Enter lot id:";
                button2.Text = "search";
                btnSalir.Text = "exit";
                lbbopaqlistarlote.Text = "Package list of the searched lot";
                lbbopaqlistarpaquetes.Text = "Package List";
                button5.Text = "Lot List";
                lbbopaqregistro.Text = "Package registration";
                lbbopaqid.Text = "Enter package id:";
                lbbopaqnombre.Text = "Ingresar nombre de paquete:";
                lbbopaqL.Text = "Enter package size L";
                lbbopaqkg.Text = "Enter package weight kg:";
                lbbopaqci.Text = "Enter customer's ci";
                lbbopaqestado.Text = "Enter shipping status:";
                btnbuscar.Text = "search";
                btnlimpiar.Text = "clean";
                btnRegistrar.Text = "register";
                btnModificar.Text = "modify";
                lbbopaqregistrolotes.Text = "lot registration";
                lbbopaqlote.Text = "Enter lot id:";
                lbbopaqidalmacen.Text = "Enter the ID of the warehouse to which it belongs:";
                btneliminarlote.Text = "delete";
                btnregistrarlote.Text = "register";
                button6.Text = "clean";
                lbbopaqasignacion.Text = "Package to lot assignment";
                lbbopaqidpaquete.Text = "Enter the ID of the package to be assigned:";
                lbbopaqasignacionlote.Text = "Enter the ID of the batch to be assigned:";
                button1.Text = "search";
                button7.Text = "clean";
                eliminarBuloLote.Text = "delete";
                btnAsignarBultoLote.Text = "assign";
               
              
            }



        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            backofficeApp frmbackofficeApp = new backofficeApp();
            this.Hide();
            frmbackofficeApp.Show();

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Paquete P = new Paquete();

            string idpaquete = txtIdPaquete.Text;
            int intpaquete;
            bool success = int.TryParse(idpaquete, out intpaquete);

            if (success)
            {
                // El parseo fue exitoso, puedes usar intpaquete aquí.
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, check the data type of the package id");
                }
                else
                {
                    MessageBox.Show("Error, revisa el tipo de dato del id del paquete");
                }
            }

            P.id = intpaquete;


            int devolucion = P.buscarPaquete();
            if (devolucion == 1) //eror al buscarlo 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error searching for the id");
                }
                else
                {
                    MessageBox.Show("Error al buscar el id");
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The package was not found, if you want to add it press register");
                }
                else
                {
                    MessageBox.Show("no se encontro el paquete, si desea añadirlo apriete registrar");
                }
                btnRegistrar.Enabled = true;
                btnEliminar.Enabled = false;
                btnModificar.Enabled = false;
            }

            else if (devolucion == 3) //ENcontramos el paquete 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The package was found, do you want to delete or modify it?");
                }
                else
                {
                    MessageBox.Show("se encontro el paquete, desea eliminarlo o modificarlo?");
                }
                P.registrardDatos();

                string nombre = P.nombre;
                txtNombrePaquete.Text = nombre;
                string peso = P.pesokg.ToString();
                txtPesoPaquete.Text = peso;
                string volumen = P.volumen.ToString();
                txtTamanioPaquete.Text = volumen;
                string ci = P.ciCliente.ToString();
                txtci.Text = ci;
                string estado = P.estadoEnvio;
                comboestado.Text = estado;

                btnEliminar.Enabled = true;
                btnModificar.Enabled = true;
                btnRegistrar.Enabled = false;

            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Resounding error");
                }
                else
                {
                    MessageBox.Show("error rotundo ");
                }
            }



        }

        private void txtIdPaquete_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {

            Paquete P = new Paquete();

            string idpaquete = txtIdPaquete.Text;
            int intpaquete = int.Parse(idpaquete);
            P.id = intpaquete;


            int devolucion = P.eliminarPaquete();
            if (devolucion == 3)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Deleted correctly");
                }
                else
                {
                    MessageBox.Show("se elimino correctamente");
                }
            }
            else if (devolucion == 1)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error searching for the id, check the data");
                }
                else
                {
                    MessageBox.Show("Error al buscar el id, revise los datos");
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The package was not found, nothing to delete");
                }
                else
                {
                    MessageBox.Show("no se encontro el paquete, nada para eliminar ");
                }
                btnRegistrar.Enabled = true;
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Resounding error");
                }
                else
                {
                    MessageBox.Show("error rotundo ");
                }
            }


        }

        private void registroPaquetesApp_Load(object sender, EventArgs e)
        {

        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            Paquete P = new Paquete();



            string id = txtIdPaquete.Text;
            String peso = txtPesoPaquete.Text;
            String volumen = txtTamanioPaquete.Text;
            string cicliente = txtci.Text;
            string nombre = txtNombrePaquete.Text;
            string estado = comboestado.Text;


            int intci;
            bool isCiValid = int.TryParse(cicliente, out intci);
            if (!isCiValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The provided CI is not a valid integer.");
                }
                else
                {
                    Console.WriteLine("El CI proporcionado no es un número entero válido.");
                }
            }

            int intid;
            bool isIdValid = int.TryParse(id, out intid);
            if (!isIdValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The provided ID is not a valid integer.");
                }
                else
                {
                    Console.WriteLine("El ID proporcionado no es un número entero válido.");
                }
            }

            float intpeso;
            bool isPesoValid = float.TryParse(peso, out intpeso);
            if (!isPesoValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The provided weight is not a valid number.");
                }
                else
                {
                    Console.WriteLine("El peso proporcionado no es un número válido.");
                }
            }

            float intvolumen;
            bool isVolumenValid = float.TryParse(volumen, out intvolumen);
            if (!isVolumenValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The provided volume is not a valid number.");
                }
                else
                {
                    Console.WriteLine("El volumen proporcionado no es un número válido.");
                }
            }

            P.id = intid;
            P.pesokg = intpeso;
            P.volumen = intvolumen;
            P.ciCliente = intci;
            P.nombre = nombre;
            P.estadoEnvio = estado;



            int devolucion = P.modificarBulto();
            if (devolucion == 1) //eror al buscarlo 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, verify the customer's ci (if registered) and the shipping status");
                }
                else
                {
                    MessageBox.Show("Error, verifique el ci del cliente (si se encuentra registrado) y el estado de envio");
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The user was not found, nothing to modify");
                }
                else
                {
                    MessageBox.Show("no se encontro el usuario, nada para modificar ");
                }

            }

            else if (devolucion == 3) //ENcontramos el paquete 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Modified correctly");
                }
                else
                {
                    MessageBox.Show("se modifico correctamente ");
                }



            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Connection closed");
                }
                else
                {
                    MessageBox.Show("conexion cerrada  ");
                }
            }

        }

        private void listPaquetes_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void btnAsignarPaquete_Click(object sender, EventArgs e)
        {
            BultoLote bl = new BultoLote();
            int idBulto;
            bool isIdBultoValid = int.TryParse(txtidbulto.Text, out idBulto);
            if (!isIdBultoValid)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The data type of the id bulto is not valid.");
                }
                else
                {
                    MessageBox.Show("El tipo de dato del id bulto no es valido.");
                }
            }
            else
            {
                bl.id_bulto = idBulto;
            }

            int idLote;
            bool isIdLoteValid = int.TryParse(txtlotea.Text, out idLote);
            if (!isIdLoteValid)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The data type of the id lote is not valid.");
                }
                else
                {
                    MessageBox.Show("El tipo de dato del id lote no es valido.");
                }
            }
            else
            {
                bl.id_lote = idLote;
            }


            int devolucion = bl.asignarDatos();
            if (devolucion == 3)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Registered correctly");
                }
                else
                {
                    MessageBox.Show("se registro correctamente");
                }
            }
            else if (devolucion == 1)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, verify the id of the batch (if registered)");
                }
                else
                {
                    MessageBox.Show("Error, verifique el id del lote (si se encuentra registrado) ");
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The connection is not open");
                }
                else
                {
                    MessageBox.Show("no esta abierta la conexion ");
                }

            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Resounding error");
                }
                else
                {
                    MessageBox.Show("error rotundo ");
                }
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
             Paquete P = new Paquete();

            string id = txtIdPaquete.Text;
            String peso = txtPesoPaquete.Text;
            String volumen = txtTamanioPaquete.Text;
            string cicliente = txtci.Text;
            string nombre = txtNombrePaquete.Text;
            string estado = comboestado.Text;


            int intci;
            bool isCiValid = int.TryParse(cicliente, out intci);
            if (!isCiValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The provided CI is not a valid integer.");
                }
                else
                {
                    Console.WriteLine("El CI proporcionado no es un número entero válido.");
                }
            }

            int intid;
            bool isIdValid = int.TryParse(id, out intid);
            if (!isIdValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The provided ID is not a valid integer.");
                }
                else
                {
                    Console.WriteLine("El ID proporcionado no es un número entero válido.");
                }
            }

            float intpeso;
            bool isPesoValid = float.TryParse(peso, out intpeso);
            if (!isPesoValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The provided weight is not a valid number.");
                }
                else
                {
                    Console.WriteLine("El peso proporcionado no es un número válido.");
                }
            }

            float intvolumen;
            bool isVolumenValid = float.TryParse(volumen, out intvolumen);
            if (!isVolumenValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The provided volume is not a valid number.");
                }
                else
                {
                    Console.WriteLine("El volumen proporcionado no es un número válido.");
                }
            }

            P.id = intid;
            P.pesokg = intpeso;
            P.volumen = intvolumen;
            P.ciCliente = intci;
            P.nombre = nombre;
            P.estadoEnvio = estado;
            int devolucion = P.registrarPaquete();

            if (devolucion == 1) //eror al buscarlo 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, verify the customer's ci (if registered) and the shipping status");
                }
                else
                {
                    MessageBox.Show("Error, verifique el ci del cliente (si se encuentra registrado) y el estado de envio");
                }
            }


            else if (devolucion == 3) //ENcontramos el paquete 
            {


                if (variables.idiom == true)
                {
                    MessageBox.Show("The package was registered and created correctly");
                }
                else
                {
                    MessageBox.Show("Se registró y creó correctamente el paquete");
                }




            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Connection closed");
                }
                else
                {
                    MessageBox.Show("conexion cerrada  ");
                }
            }

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Lote L = new Lote();


            string ciusuario = txtIdLote.Text;
            int intId = int.Parse(ciusuario);
            L.id = intId;


            int devolucion = L.buscarLote();
            if (devolucion == 1) //eror al buscarlo 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error searching for the id");
                }
                else
                {
                    MessageBox.Show("Error al buscar el id");
                }
            }
            else if (devolucion == 2)//no encontre el lote
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The batch was not found, if you want to add it press register");
                }
                else
                {
                    MessageBox.Show("no se encontro el lote, si desea añadirlo apriete registrar");
                }
                btnregistrarlote.Enabled = true;
                btneliminarlote.Enabled = false;
            }

            else if (devolucion == 3) //ENcontramos el lote 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The batch was found, do you want to delete it?");
                }
                else
                {
                    MessageBox.Show("se encontro el lote, desea eliminarlo?");
                }
                btneliminarlote.Enabled = true;
                btnregistrarlote.Enabled = false;


            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Resounding error");
                }
                else
                {
                    MessageBox.Show("error rotundo ");
                }
            }

        }

        private void btnlimpiar_Click(object sender, EventArgs e)
        {
            comboestado.Text = null;
            txtci.Text = null;
            txtIdPaquete.Text = null;
            txtNombrePaquete.Text = null;
            txtPesoPaquete.Text = null;
            txtTamanioPaquete.Text = null;


        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Lote L = new Lote();

            L.id = int.Parse(txtIdLote.Text);
            int idAlmacen;
            bool isIdAlmacenValid = int.TryParse(txtalmacenlote.Text, out idAlmacen);
            if (!isIdAlmacenValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The format of the warehouse id is not valid.");
                }
                else
                {
                    Console.WriteLine("El formato del id de almacen no es valido.");
                }
            }
            else
            {
                L.idAlmacen = idAlmacen;
            }


            int devolucion = L.registrarLote();
            if (devolucion == 3)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Registered correctly");
                }
                else
                {
                    MessageBox.Show("se registro correctamente");
                }
            }
            else if (devolucion == 1)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, verify the id of the warehouse (if registered)");
                }
                else
                {
                    MessageBox.Show("Error, verifique el id del almacen (si se encuentra registrado)");
                }
            }
            else if (devolucion == 2)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The connection is not open");
                }
                else
                {
                    MessageBox.Show("no esta abierta la conexion ");
                }

            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Resounding error");
                }
                else
                {
                    MessageBox.Show("error rotundo ");
                }
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Lote L = new Lote();

            L.id = int.Parse(txtIdLote.Text);


            int devolucion = L.eliminarLote();
            if (devolucion == 3)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Deleted correctly");
                }
                else
                {
                    MessageBox.Show("se elimino correctamente");
                }
            }
            else if (devolucion == 1)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error searching for the id");
                }
                else
                {
                    MessageBox.Show("Error al buscar el id");
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The package was not found, nothing to delete");
                }
                else
                {
                    MessageBox.Show("no se encontro el paquete, nada para eliminar ");
                }

            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Resounding error");
                }
                else
                {
                    MessageBox.Show("error rotundo ");
                }
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            BultoLote bl = new BultoLote();
            Paquete P = new Paquete();

            string idpaquete = txtidbulto.Text;
            int intpaquete = int.Parse(idpaquete);
            P.id = intpaquete;


            int devolucion = P.buscarPaquete();
            if (devolucion == 1) //eror al buscarlo 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error searching for the id");
                }
                else
                {
                    MessageBox.Show("Error al buscar el id");
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The package was not found, nothing to assign");
                }
                else
                {
                    MessageBox.Show("no se encontro el paquete, nada para asignar");
                }

            }

            else if (devolucion == 3) //ENcontramos el paquete 
            {
                string idbulto = txtidbulto.Text;
                int intbulto = int.Parse(idbulto);
                bl.id_bulto = intbulto;

                int devolucion2 = bl.buscarBultoLote();
                if (devolucion2 == 1) //eror al buscarlo 
                {
                    if (variables.idiom == true)
                    {
                        MessageBox.Show("Error searching for the id");
                    }
                    else
                    {
                        MessageBox.Show("Error al buscar el id");
                    }
                }
                else if (devolucion2 == 2)//no encontre el paquete
                {
                    if (variables.idiom == true)
                    {
                        MessageBox.Show("The package is not assigned, do you want to assign it?");
                    }
                    else
                    {
                        MessageBox.Show("el paquete no se encuetra asignado, desea asignarlo?");
                    }
                    btnAsignarBultoLote.Enabled = true;
                    eliminarBuloLote.Enabled = false;
                }

                else if (devolucion2 == 3) //ENcontramos el paquete 
                {
                    if (variables.idiom == true)
                    {
                        MessageBox.Show("The package is already assigned, do you want to unassign it?");
                    }
                    else
                    {
                        MessageBox.Show("el paquete ya esta asignado, desea desasignarlo?");
                    }
                    btnAsignarBultoLote.Enabled = false;
                    eliminarBuloLote.Enabled = true;

                }
                else
                {
                    if (variables.idiom == true)
                    {
                        MessageBox.Show("Resounding error");
                    }
                    else
                    {
                        MessageBox.Show("error rotundo ");
                    }
                }

            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Resounding error");
                }
                else
                {
                    MessageBox.Show("error rotundo ");
                }
            }





        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            BultoLote bl = new BultoLote();

            bl.id_bulto = int.Parse(txtidbulto.Text);


            int devolucion = bl.eliminarBultoLote();
            if (devolucion == 3)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Deleted correctly");
                }
                else
                {
                    MessageBox.Show("se elimino correctamente");
                }
            }
            else if (devolucion == 1)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error searching for the id");
                }
                else
                {
                    MessageBox.Show("Error al buscar el id");
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The package was not found, nothing to delete");
                }
                else
                {
                    MessageBox.Show("no se encontro el paquete, nada para eliminar ");
                }

            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Resounding error");
                }
                else
                {
                    MessageBox.Show("error rotundo ");
                }
            }

        }

        private void gridlotes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click_2(object sender, EventArgs e)
        {
            showSubMenu(panelPaquetesBus);

            BultoLote bl = new BultoLote();

            string idbulto = txtidlotebulto.Text;
            int intbulto = int.Parse(idbulto);
            bl.id_lote = intbulto;


            gridbultolote.DataSource = bl.obtenerdatosbultolote();
            gridbultolote.DefaultCellStyle.ForeColor = Color.Black;
        }

        private void gridbultolote_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void txtci_TextChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click_1(object sender, EventArgs e)
        {

        }

        private void txtPesoPaquete_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTamanioPaquete_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNombrePaquete_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void txtlotea_TextChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void txtidbulto_TextChanged(object sender, EventArgs e)
        {

        }

        private void customizeDesign()
        {
            panelPaquetesBus.Visible = false;
            panelListaPaquetes.Visible = false;
            panelListaLotes.Visible = false;
        }

        private void hideSubMenu()
        {
            if (panelPaquetesBus.Visible == true)
                panelPaquetesBus.Visible = false;

            if (panelListaPaquetes.Visible == true)
                panelListaPaquetes.Visible = false;

            if (panelListaLotes.Visible == true)
                panelListaLotes.Visible = false;
        }

        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            txtIdLote.Text = null;
            txtalmacenlote.Text = null;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            txtidbulto.Text = null;
            txtlotea.Text = null;
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            showSubMenu(panelListaPaquetes);
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            showSubMenu(panelPaquetesBus);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            showSubMenu(panelListaLotes);
        }
    }
}      

    


  
