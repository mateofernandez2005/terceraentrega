﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prueba
{
    public partial class registroCamionApp2 : Form
    {
        public registroCamionApp2()
        {
        


            InitializeComponent();
            panelListaCamiones.Visible = false;
            panelListaLotesA.Visible = false;
            panelListaCamionesA.Visible = false;
           // panel4 = false;
            btnAsignarcamionLote.Enabled = false;
            btndesasignarcamionlote.Enabled = false;
            btnEliminar.Enabled = false;
            btnRegistrar.Enabled = false;
            btnModificar.Enabled = false;
            Camion C = new Camion();
            gridcamiones.DataSource = C.ObtenerDatosAlmacen();

            camionLote Cl = new camionLote();
            gridcamionlote.DataSource = Cl.ObtenerDatoscamionlote();

            camionCamionero cc = new camionCamionero();
            gridmanejar.DataSource = cc.obtenerdatosmanejar();


            if (variables.idiom == true)
            {
                lbbocamlistas.Text = "list";
                btnlistacamiones.Text = "trucks";
                btnlistasasignados.Text = "Lots assigned to trucks";
                btnSalir.Text = "exit";
                button10.Text = "Truckers assigned to trucks";
                lbbocamregistro.Text = "Truck registration";
                lbbocammatricula.Text = "Enter truck registration:";
                lbbocamlitros.Text = "Enter truck capacity (in Lts):";
                lbbocamkg.Text = "Enter truck capacity (in Kgs):";
                button4.Text = "search";
                btnLimpiar.Text = "celan";
                btnRegistrar.Text = "register";
                btnEliminar.Text = "delete";
                btnModificar.Text = "modify";
                lbbocamasignacion.Text = "Lot assignment to truck";
                lbbocamlote.Text = "Enter lot to assign:";
                lbbocammatriculalote.Text = "Enter truck registration:";
                lbbocamfecha1.Text = "enter the date the batch ";
                fecha2.Text = "was loaded onto the truck ";
                lbbocamanio.Text = "year";
                mes.Text = "month";
                dia.Text = "day";
                hs.Text = "hs";
                lbbocammin.Text = "min";
                button6.Text = "search";
                button1.Text = "clean";
                btndesasignarcamionlote.Text = "unassign";
                btnAsignarcamionLote.Text = "assign";
                label11.Text = "Truck to truck driver assignment";
                label12.Text = "Enter truck driver ID:";
                label14.Text = "Ingrese matricula de camion:";
                button8.Text = "search";
                button2.Text = "clean";
                button5.Text = "unassign";
                button7.Text = "assign";

            }






        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            backofficeApp frmbackofficeApp = new backofficeApp();
            this.Hide();
            frmbackofficeApp.Show();

        }

        private void txtMatriculaA_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {


            Camion C = new Camion();

            string idmatricula = txtMatricula.Text;

            C.matricula = idmatricula;


            int devolucion = C.buscarCamion();
            if (devolucion == 1) //eror al buscarlo 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error searching for the id" + devolucion);
                }
                else
                {
                    MessageBox.Show("Error al buscar el id" + devolucion);
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The truck was not found, if you want to add it press register");
                }
                else
                {
                    MessageBox.Show("no se encontro el camion, si desea añadirlo apriete registrar");
                }
                btnRegistrar.Enabled = true;
                btnEliminar.Enabled = false;
                btnModificar.Enabled = false;
            }

            else if (devolucion == 3) //ENcontramos el paquete 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The truck was found, do you want to delete or modify it?");
                }
                else
                {
                    MessageBox.Show("se encontro el camion, desea eliminarlo o modificarlo?");
                }
                C.registrardDatos();
                string matricula = C.matricula;
                txtMatricula.Text = matricula;
                string ScapacidadL = C.capacidadM3.ToString();
                txtLtsCamion.Text = ScapacidadL;
                string ScapacidadKg = C.capacidadKg.ToString();
                txtKgsCamion.Text = ScapacidadKg;
                btnEliminar.Enabled = true;
                btnModificar.Enabled = true;
                btnRegistrar.Enabled = false;

            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Resounding error");
                }
                else
                {
                    MessageBox.Show("error rotundo ");
                }
            }


        }

        private void btnRegistrarCamion_Click(object sender, EventArgs e)
        {



            Camion C = new Camion();

            string idmatricula = txtMatricula.Text;
            String capacidadLts = txtLtsCamion.Text;
            String capaciadKg = txtKgsCamion.Text;
            int intcapacidadLts;
            bool isCapacidadLtsValid = int.TryParse(capacidadLts, out intcapacidadLts);
            if (!isCapacidadLtsValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The provided liters capacity is not a valid integer.");
                }
                else
                {
                    Console.WriteLine("La capacidad en litros proporcionada no es un número entero válido.");
                }
            }

            int intcapacidadKg;
            bool isCapacidadKgValid = int.TryParse(capaciadKg, out intcapacidadKg);
            if (!isCapacidadKgValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The provided kilograms capacity is not a valid integer.");
                }
                else
                {
                    Console.WriteLine("La capacidad en kilogramos proporcionada no es un número entero válido.");
                }
            }

            C.matricula = idmatricula;
            C.capacidadKg = intcapacidadKg;
            C.capacidadM3 = intcapacidadLts;

            int devolucion = C.registrarCamion();
            if (devolucion == 1) //eror al buscarlo 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, check the data");
                }
                else
                {
                    MessageBox.Show("Error, revise los datos ");
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The truck was not found, if you want to add it press register");
                }
                else
                {
                    MessageBox.Show("no se encontro el camion, si desea añadirlo apriete registrar");
                }

            }

            else if (devolucion == 3) //ENcontramos el paquete 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Registered correctly");
                }
                else
                {
                    MessageBox.Show("se registro correctamente ");
                }



            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Connection closed");
                }
                else
                {
                    MessageBox.Show("conexion cerrada  ");
                }
            }






        }

        private void txtKgsCamion_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void btnbuscar_Click(object sender, EventArgs e)
        {

        }

        private void btnModificarCamion_Click(object sender, EventArgs e)
        {


            Camion C = new Camion();

            string matricula = txtMatricula.Text;
            String capacidadLts = txtLtsCamion.Text;
            String capaciadKg = txtKgsCamion.Text;




            float FL;
            bool isCapacidadLtsValid = float.TryParse(capacidadLts, out FL);
            if (!isCapacidadLtsValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The provided liters capacity is not a valid number.");
                }
                else
                {
                    Console.WriteLine("La capacidad en litros proporcionada no es un número válido.");
                }
            }

            float FKg;
            bool isCapacidadKgValid = float.TryParse(capaciadKg, out FKg);
            if (!isCapacidadKgValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The provided kilograms capacity is not a valid number.");
                }
                else
                {
                    Console.WriteLine("La capacidad en kilogramos proporcionada no es un número válido.");
                }
            }

            C.matricula = matricula;
            C.capacidadKg = FKg;
            C.capacidadM3 = FL;


            int devolucion = C.modificarCamion();
            if (devolucion == 1) //eror al buscarlo 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, check the data");
                }
                else
                {
                    MessageBox.Show("Error, revise los datos");
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The truck was not found, if you want to add it press register");
                }
                else
                {
                    MessageBox.Show("no se encontro el camion, si desea añadirlo apriete registrar");
                }

            }

            else if (devolucion == 3) //ENcontramos el paquete 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Registered correctly");
                }
                else
                {
                    MessageBox.Show("se registro correctamente ");
                }



            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Connection closed");
                }
                else
                {
                    MessageBox.Show("conexion cerrada  ");
                }
            }



        }

        private void btnEliminarCamion_Click(object sender, EventArgs e)
        {
            Camion C = new Camion();

            string matricula = txtMatricula.Text;

            C.matricula = matricula;


            int devolucion = C.eliminarCamion();
            if (devolucion == 3)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Deleted correctly");
                }
                else
                {
                    MessageBox.Show("se elimino correctamente");
                }
            }
            else if (devolucion == 1)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error searching for the id, check the data");
                }
                else
                {
                    MessageBox.Show("Error al buscar el id, revise los datos");
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The package was not found, nothing to delete");
                }
                else
                {
                    MessageBox.Show("no se encontro el paquete, nada para eliminar ");
                }

            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Resounding error");
                }
                else
                {
                    MessageBox.Show("error rotundo ");
                }
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtMatricula.Text = null;
            txtLtsCamion.Text = null;
            txtKgsCamion.Text = null;
        }

        private void btnAsignarLote_Click(object sender, EventArgs e)
        {

            camionLote cl = new camionLote();

            cl.matricula = txtcamionlote.Text;
            string id = txtlotecamion.Text;
            
            int numeroci;
            if (int.TryParse(txtlotecamion.Text, out numeroci))
            {
                cl.id = numeroci;
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The entered batch value is not valid, only integers");
                }
                else
                {
                    MessageBox.Show("el valor ingresado del lote no es valido, solo nunmeros enteros");
                }
            }

            int año, mes, dia, hora, minuto;

            bool esAñoValido = int.TryParse(txtanio.Text, out año);
            bool esMesValido = int.TryParse(txtmes.Text, out mes);
            bool esDiaValido = int.TryParse(txtdia.Text, out dia);
            bool esHoraValido = int.TryParse(txths.Text, out hora);
            bool esMinutoValido = int.TryParse(txtmin.Text, out minuto);

            if (esAñoValido && esMesValido && esDiaValido && esHoraValido && esMinutoValido)
            {
                 cl.fecha = new DateTime(año, mes, dia, hora, minuto, 0);
                // Utiliza la variable fecha aquí
            }
            else
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("One or more entered date values are not valid numbers.");
                }
                else
                {
                    Console.WriteLine("Uno o más valores ingresados de la fecha no son números válidos.");
                }
            }


            int devolucion = cl.InsertarDatos2();
            if (devolucion == 3)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Registered correctly");
                }
                else
                {
                    MessageBox.Show("se registro correctamente");
                }
            }
            else if (devolucion == 1)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, check the data");
                }
                else
                {
                    MessageBox.Show("Error, los datos");
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The connection is not open");
                }
                else
                {
                    MessageBox.Show("no esta abierta la conexion ");
                }

            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Resounding error");
                }
                else
                {
                    MessageBox.Show("error rotundo ");
                }
            }


        }

        private void button7_Click(object sender, EventArgs e)
        {
            camionCamionero Cc = new camionCamionero();

            Cc.matricula = txtCamionA.Text;
            string ci = txtCamioneroA.Text;
            Cc.ci = int.Parse(ci);


            int devolucion = Cc.InsertarDatos();
            if (devolucion == 3)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Registered correctly");
                }
                else
                {
                    MessageBox.Show("se registro correctamente");
                }
            }
            else if (devolucion == 1)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, check the registration");
                }
                else
                {
                    MessageBox.Show("Error, revise la matricula");
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The connection is not open");
                }
                else
                {
                    MessageBox.Show("no esta abierta la conexion ");
                }

            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Resounding error");
                }
                else
                {
                    MessageBox.Show("error rotundo ");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtlotecamion.Text = null;
            txtcamionlote.Text = null;
            txtanio.Text = null;
            txtmes.Text = null;
            txtdia.Text = null;
            txths.Text = null;
            txtmin.Text = null;

        } 

        private void button2_Click(object sender, EventArgs e)
        {
            txtCamioneroA.Text = null;
            txtCamionA.Text = null;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            camionLote cl = new camionLote();

            cl.id = int.Parse(txtlotecamion.Text);


            int devolucion = cl.eliminarcamionlote();
            if (devolucion == 3)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Deleted correctly");
                }
                else
                {
                    MessageBox.Show("se elimino correctamente");
                }
            }
            else if (devolucion == 1)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error searching for the id, check the data");
                }
                else
                {
                    MessageBox.Show("Error al buscar el id, revise los datos");
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The package was not found, nothing to delete");
                }
                else
                {
                    MessageBox.Show("no se encontro el paquete, nada para eliminar ");
                }

            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Resounding error");
                }
                else
                {
                    MessageBox.Show("error rotundo ");
                }
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {

          
            Lote L = new Lote();


            string idlote = txtlotecamion.Text;
            int intId = int.Parse(idlote);
            L.id = intId;


            int devolucion = L.buscarLote();
            if (devolucion == 1) //eror al buscarlo 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error searching for the id");
                }
                else
                {
                    MessageBox.Show("Error al buscar el id");
                }
            }
            else if (devolucion == 2)//no encontre el lote
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The batch was not found, nothing to assign");
                }
                else
                {
                    MessageBox.Show("no se encontro el lote, nada para asignar");
                }
            }

            else if (devolucion == 3) //ENcontramos el lote 
            {

                camionLote Cl = new camionLote();

                string idmatricula = txtlotecamion.Text;

                Cl.id = int.Parse(idmatricula);


                int devolucion2 = Cl.buscarLoteCamion();
                if (devolucion2 == 1) //eror al buscarlo 
                {
                    if (variables.idiom == true)
                    {
                        MessageBox.Show("Error searching for the id");
                    }
                    else
                    {
                        MessageBox.Show("Error al buscar el id");
                    }
                }
                else if (devolucion2 == 2)//no encontre el lote
                {
                    if (variables.idiom == true)
                    {
                        MessageBox.Show("The batch is not assigned, do you want to assign it?");
                    }
                    else
                    {
                        if (variables.idiom == true)
                        {
                            MessageBox.Show("The batch is already assigned, do you want to unassign it?");
                        }
                        else
                        {
                            MessageBox.Show("el lote ya esta asignado, desea desasignarlo?");
                        }
                    }
                    btnAsignarcamionLote.Enabled = true;
                    btndesasignarcamionlote.Enabled = false;
                }

                else if (devolucion2 == 3) //ENcontramos el lote 
                {
                    if (variables.idiom == true)
                    {
                        MessageBox.Show("The batch is already assigned, do you want to unassign it?");
                    }
                    else
                    {
                        MessageBox.Show("el lote ya esta asignado, desea desasignarlo?");
                    }
                    btnAsignarcamionLote.Enabled = false;
                    btndesasignarcamionlote.Enabled = true;

                }
                else
                {
                    if (variables.idiom == true)
                    {
                        MessageBox.Show("Resounding error");
                    }
                    else
                    {
                        MessageBox.Show("error rotundo ");
                    }
                }
            }




            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Resounding error");
                }
                else
                {
                    MessageBox.Show("error rotundo ");
                }
            }

        }



        private void button8_Click(object sender, EventArgs e)
        {
            Usuario U = new Usuario();


            string cicamionero = txtCamioneroA.Text;
            int ciC = int.Parse(cicamionero);
            U.ci = ciC;


            int devolucion = U.buscarCamionero();
            if (devolucion == 1) //eror al buscarlo 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error searching for the id");
                }
                else
                {
                    MessageBox.Show("Error al buscar el id");
                }
            }
            else if (devolucion == 2)//no encontre el lote
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The truck driver was not found, nothing to assign");
                }
                else
                {
                    MessageBox.Show("no se encontro el camionero, nada para asignar");
                }
            }

            else if (devolucion == 3) //ENcontramos el camionero 
            {

                camionCamionero Cc = new camionCamionero();

                string cicamion= txtCamioneroA.Text;

                Cc.ci = int.Parse(cicamion);


                int devolucion2 = Cc.buscarmanejar();
                if (devolucion2 == 1) //eror al buscarlo 
                {
                    if (variables.idiom == true)
                    {
                        MessageBox.Show("Error searching for the ci");
                    }
                    else
                    {
                        MessageBox.Show("Error al buscar el ci");
                    }
                }
                else if (devolucion2 == 2)//no encontre el lote
                {
                    if (variables.idiom == true)
                    {
                        MessageBox.Show("The truck driver is not assigned, do you want to assign it?");
                    }
                    else
                    {
                        MessageBox.Show("el camionero no esta asigando, desea asignarlo?");
                    }
                    btnAsignarcamionLote.Enabled = true;
                    btndesasignarcamionlote.Enabled = false;
                }

                else if (devolucion2 == 3) //ENcontramos el lote 
                {
                    if (variables.idiom == true)
                    {
                        MessageBox.Show("The truck driver is already assigned, do you want to unassign it?");
                    }
                    else
                    {
                        MessageBox.Show("el camionero ya esta asignado, desea desasignarlo?");
                    }
                    btnAsignarcamionLote.Enabled = false;
                    btndesasignarcamionlote.Enabled = true;

                }
                else
                {
                    if (variables.idiom == true)
                    {
                        MessageBox.Show("Resounding error");
                    }
                    else
                    {
                        MessageBox.Show("error rotundo ");
                    }
                }
            }




            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Resounding error");
                }
                else
                {
                    MessageBox.Show("error rotundo ");
                }
            }

        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            camionCamionero cc = new camionCamionero();

            cc.ci = int.Parse(txtCamioneroA.Text);


            int devolucion = cc.eliminarmanejar();
            if (devolucion == 3)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Deleted correctly");
                }
                else
                {
                    MessageBox.Show("se elimino correctamente");
                }
            }
            else if (devolucion == 1)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error searching for the ci");
                }
                else
                {
                    MessageBox.Show("Error al buscar el ci");
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The truck driver was not found, nothing to delete");
                }
                else
                {
                    MessageBox.Show("no se encontro el camionero, nada para eliminar ");
                }

            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Resounding error");
                }
                else
                {
                    MessageBox.Show("error rotundo ");
                }
            }

        }

        private void registroCamionApp2_Load(object sender, EventArgs e)
        {

        }

        private void gridcamionlote_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void gridmanejar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            showSubMenu(panelListaCamionesA);

        }

        private void button9_Click(object sender, EventArgs e)
        {
            showSubMenu(panelListaLotesA);

        }

        private void customizeDesign()
        {
            panelListaCamiones.Visible = false;
            panelListaCamionesA.Visible = false;
            panelListaLotesA.Visible = false;
        }

        private void hideSubMenu()
        {
            if (panelListaCamiones.Visible == true)
                panelListaCamiones.Visible = false;

            if (panelListaCamionesA.Visible == true)
                panelListaCamionesA.Visible = false;

            if (panelListaLotesA.Visible == true)
                panelListaLotesA.Visible = false;
        }

        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }

        private void button3_Click_2(object sender, EventArgs e)
        {
            showSubMenu(panelListaCamiones);
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void panelListaLotesA_Paint(object sender, PaintEventArgs e)
        {

        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void gridcamionlote_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void lbbocamlistas_Click(object sender, EventArgs e)
        {

        }
    }
}