﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace prueba
{
    class almacenLote
    {

        protected int _idalmacen;
        protected int _idlote;
        
        protected ADODB.Connection _conexion;

        public almacenLote()
        {
            _conexion = Program.cn;
            _idalmacen = 0;
            _idlote = 0;
            

        }
        public almacenLote(int idlote, int idalmacen,
        ADODB.Connection cn)
        {
            _idlote = idlote;
            _idalmacen = idalmacen;
            
        }
        public ADODB.Connection conexion
        {
            get { return (_conexion); }
            set { _conexion = value; }
        }
        public int idalmacen
        {
            get { return (_idalmacen); }
            set { _idalmacen = value; }
        }

        public int idlote
        {
            get { return (_idlote); }
            set { _idlote = value; }
        }

       

        public List<Int32> obtenerLotesAlmacen()
        {

            List<Int32> lista = new List<Int32>();
            Almacen A = new Almacen();

            A.id = _idalmacen;
            int devolucion = A.buscarAlmacen();
            if (devolucion == 3) {  
            if (_conexion.State != 0)
            {
                    
                string sql = "select id from lote where id_almacen = '" + _idalmacen + "'";

                try
                {

                    ADODB.Recordset rs = new ADODB.Recordset();
                    object filasAfectadas;
                    rs = _conexion.Execute(sql, out filasAfectadas);
                   


                    while (!rs.EOF)
                    {
                        lista.Add(Convert.ToInt32(rs.Fields[0].Value));
                        rs.MoveNext();
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.WriteLine(_idalmacen);
                }
                return lista;
            }

         }
            else 
            {
                return lista;
            }
            return lista;
        }



        public DataTable RecordsetToDataTable(ADODB.Recordset recordset)
        {
            DataTable dataTable = new DataTable();

            for (int i = 0; i < recordset.Fields.Count; i++)
            {
                dataTable.Columns.Add(recordset.Fields[i].Name, typeof(string));
            }

            while (!recordset.EOF)
            {
                DataRow dataRow = dataTable.NewRow();
                for (int i = 0; i < recordset.Fields.Count; i++)
                {
                    dataRow[i] = recordset.Fields[i].Value.ToString();
                }
                dataTable.Rows.Add(dataRow);
                recordset.MoveNext();
            }

            return dataTable;
        }


        public DataTable obtenerlotesalmacen()
        {

            DataTable dataTable = new DataTable();
            Console.Write("hola" + _idalmacen);
            if (_conexion.State != 0)
            {
                //conexion abierta
                string sql = "select id from lote where id_almacen = '" + _idalmacen + "'";

                try
                {

                    ADODB.Recordset rs = new ADODB.Recordset();


                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic);


                    dataTable = RecordsetToDataTable(rs);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }


            return dataTable;
        }

    }



}

