﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace prueba
{
    class BultoLote
    {
        protected int _id_lote;
        protected int _id_bulto;
        protected ADODB.Connection _conexion;

        public BultoLote()
        {
            _conexion = Program.cn;
            _id_lote = 0;
            _id_bulto = 0;


        }
        public BultoLote(int id_lote, int id_bulto,
        ADODB.Connection cn)
        {
            _id_lote = id_lote;
            _id_bulto = id_bulto;
        }
        public ADODB.Connection conexion
        {
            get { return (_conexion); }
            set { _conexion = value; }
        }
        public int id_bulto
        {
            get { return (_id_bulto); }
            set { _id_bulto = value; }
        }

        public int id_lote
        {
            get { return (_id_lote); }
            set { _id_lote = value; }
        }

        public int buscarBultoLote()
        {

            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;



            Console.WriteLine("hola0");
            Console.WriteLine(_id_bulto);

            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "select id_bulto from bulto_lote where id_bulto='" + _id_bulto + "'";

                try
                {
                    rs = _conexion.Execute(sql, out filasAfectadas);

                    if (!rs.EOF) //encontramos el paquete
                    {
                        Console.WriteLine("hola");
                        return 3;
                    }
                    else //no encontre el paquete
                    {
                        Console.WriteLine("hola2");
                        return 2;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.WriteLine("hola3");
                    return 1;
                }
            }
            else
            {
                Console.WriteLine("hola4");
                return 4;
            }


        }

        public int asignarDatos()
        {
            string sql;
            object filasAfectadas;

            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "INSERT INTO bulto_lote(id_lote,id_bulto ) VALUES ('" + _id_lote + "', '" + _id_bulto + "')";

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                    return 3; // Retorno 0 para indicar éxito
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1; // Retorno 1 para indicar error
                }
            }
            else
            {
                return 2; // Retorno 2 para indicar que la conexión no está abierta
            }
        }

        public int eliminarBultoLote()
        {
            String sql;
            String sql1;
            

            object filasAfectadas;
            int totalFilasAfectadas = 0;

            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "DELETE FROM articulo WHERE id='" + _id_bulto + "'";
                sql1 = "DELETE FROM bulto_lote WHERE id_bulto='" + _id_bulto + "'";

                try
                {
                   

                    ADODB.Recordset rs1 = _conexion.Execute(sql, out filasAfectadas);
                    totalFilasAfectadas += (int)filasAfectadas;

                    ADODB.Recordset rs2 = _conexion.Execute(sql1, out filasAfectadas);
                    totalFilasAfectadas += (int)filasAfectadas;


                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }

                if (totalFilasAfectadas > 0) //eliminamos el camion
                {
                    return 3;
                }
                else //no encontre el camion
                {
                    return 2;
                }
            }
            else
            {
                return 4; // La conexión no está abierta
            }
        }


        public DataTable RecordsetToDataTable(ADODB.Recordset recordset)
        {
            DataTable dataTable = new DataTable();

            for (int i = 0; i < recordset.Fields.Count; i++)
            {
                dataTable.Columns.Add(recordset.Fields[i].Name, typeof(string));
            }

            while (!recordset.EOF)
            {
                DataRow dataRow = dataTable.NewRow();
                for (int i = 0; i < recordset.Fields.Count; i++)
                {
                    dataRow[i] = recordset.Fields[i].Value.ToString();
                }
                dataTable.Rows.Add(dataRow);
                recordset.MoveNext();
            }

            return dataTable;
        }

        public DataTable obtenerdatosbultolote()
        {

            DataTable dataTable = new DataTable();

            if (_conexion.State != 0)
            {
                //conexion abierta
                string sql = "select id_bulto from bulto_lote where id_lote = '" + _id_lote + "'";
                
                try
                {

                    ADODB.Recordset rs = new ADODB.Recordset();


                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic);


                    dataTable = RecordsetToDataTable(rs);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }


            return dataTable;
        }


        public int obtenerIdLote()
        {
            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;

            if (_conexion.State != 0)
            {
                sql = "SELECT id_lote FROM bulto_lote WHERE id_lote = " + _id_lote;

                try
                {
                    rs = _conexion.Execute(sql, out filasAfectadas);
                    return Convert.ToInt32(rs.Fields[0].Value);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return -1;
                }
            }
            else
            {
                return -1;
            }
        }
        public List<Int32> obteneridslote()
        {

            List<Int32> lista = new List<Int32>();
            Lote l = new Lote();

            l.id = _id_lote;

            Console.WriteLine(_id_lote);

            int devolucion = l.buscarLote();
            if (devolucion == 3)
                Console.WriteLine(devolucion);
            {
                if (_conexion.State != 0)
                {
                    //conexion abierta
                   
                    string sql = "select id_bulto from bulto_lote where id_lote = '" + _id_lote + "'";
                    
                    try
                    {

                        ADODB.Recordset rs = new ADODB.Recordset();
                        object filasAfectadas;
                        rs = _conexion.Execute(sql, out filasAfectadas);



                        while (!rs.EOF)
                        {
                            lista.Add(Convert.ToInt32(rs.Fields[0].Value));
                            rs.MoveNext();
                        }

                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(_id_lote);
                    }
                    return lista;
                }

            
        
    
        
            else
            {
                return lista;
            }
            
        }
    }
    }
}
