﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using System.Data;


namespace prueba
{
    static class apiAlmacen
    {

        internal class almacenL
        {
            public int idalmacen { set; get; }
            public int idlote { set; get; }
            protected List<Int32> _data;

            public almacenL()
            {
                _data = new List<Int32>();

            }
            public List<Int32> data
            {
                get { return (_data); }
                set { _data = value; }
            }
        }

        public static String registroLotes(String ids)
        {

            List<Int32> lista;
            String resultado;
            almacenL la = new almacenL();
            almacenLote al = new almacenLote();
            la = JsonSerializer.Deserialize<almacenL>(ids); /////

            al.idalmacen = la.idalmacen;
            al.idlote = la.idlote;


            lista = al.obtenerLotesAlmacen();
            la.data = lista;

            la.idlote = al.idlote;
            //Console.WriteLine(la.data[1]);

            resultado = JsonSerializer.Serialize(la);
            return (resultado);

        }
        internal class bultoL
        {
            public int idbulto { set; get; }
            public int idlote { set; get; }
            protected List<Int32> _data;

            public bultoL()
            {
                _data = new List<Int32>();

            }
            public List<Int32> data
            {
                get { return (_data); }
                set { _data = value; }
            }
        }
        public static String registropaquetes(String ids)
        {

            List<Int32> lista;
            String resultado;
            bultoL lb = new bultoL();
            BultoLote bl = new BultoLote();
            lb = JsonSerializer.Deserialize<bultoL>(ids); /////

            bl.id_lote = lb.idlote;
            bl.id_bulto = bl.id_bulto;


            lista = bl.obteneridslote();
            lb.data = lista;

            lb.idlote = bl.id_lote;
            //Console.WriteLine(la.data[1]);

            resultado = JsonSerializer.Serialize(lb);
            return (resultado);

        }

        internal class lotelote
        {
            public int idalmacen { set; get; }
            public int idlote { set; get; }
            protected List<Int32> _data;
            public int devu { set; get; }

            public lotelote()
            {
                _data = new List<Int32>();

            }
            public List<Int32> data
            {
                get { return (_data); }
                set { _data = value; }
            }
        }

        public static String ingresarLote(String lotes)
        {
            List<Int32> lista;
            String resultado;
            almacenLote al = new almacenLote();
           
            lotelote ll = new lotelote();
            Lote l = new Lote();
            ll = JsonSerializer.Deserialize<lotelote>(lotes); /////

            l.idAlmacen = ll.idalmacen;
            l.id = ll.idlote;
            al.idalmacen = ll.idalmacen;
            al.idlote = ll.idlote;

            int devolucion = l.registrarLote();
           

            if (devolucion == 3)
            {


                lista = al.obtenerLotesAlmacen();
                ll.data = lista;
                
                ll.idlote = al.idlote;
                ll.devu = 3;


                
            }
            else if (devolucion == 1)
            {
                ll.devu = 1;
                
            }
            else if (devolucion == 2)
            {
               

            }
            else
            {
                ll.devu = 2;
                
            }



            resultado = JsonSerializer.Serialize(ll);
            return (resultado);

        }

        internal class idmatrifecha
        {
            public string matricula { set; get; }
            public int idlote { set; get; }
            public DateTime _fecha { set; get; }
            public int devu { set; get; }
            protected List<Int32> _data;
            public int idalmacen { set; get; }

            public idmatrifecha()
            {
                _data = new List<Int32>();

            }
            public List<Int32> data
            {
                get { return (_data); }
                set { _data = value; }
            }
        }


        //public static String salidaLote(String salidas)
        //{
        //    List<Int32> lista;
        //    String resultado;
        //    almacenLote al = new almacenLote();
        //    camionLote cl = new camionLote();


        //    idmatrifecha imf = new idmatrifecha();
        //    Lote l = new Lote();

        //    imf = JsonSerializer.Deserialize<idmatrifecha>(salidas); /////

        //    imf.matricula = cl.matricula;
        //    imf.idlote = cl.id;

        //    Console.Write(imf.matricula);
        //    imf._fecha = cl.fecha;

        //    al.idalmacen = imf.idalmacen;
        //    al.idlote = imf.idlote;
        //    al.idalmacen = imf.idalmacen;
        //    Console.Write(imf.idlote);
        //    int devolucion = cl.buscarLoteCamion();

        //    if (devolucion == 3)
        //    {
        //        imf.devu = 4;
        //    }
        //    else if (devolucion == 2)
        //    {
        //        int devolucion2;

        //        devolucion2 = cl.InsertarDatos();
        //        if (devolucion2 == 3)
        //        {

        //            lista = al.obtenerLotesAlmacen();
        //            imf.data = lista;

        //            imf.idlote = al.idlote;

        //            imf.devu = 3;

        //        }
        //        else if (devolucion2 == 2)
        //        {

        //            imf.devu = 2;
        //        }
        //        else
        //        {
        //            imf.devu = 1;
        //        }

        //    }
        //    else
        //    {
        //        imf.devu = 5;
        //    }
        //    resultado = JsonSerializer.Serialize(imf);
        //    return (resultado);

        //}


    }
}
