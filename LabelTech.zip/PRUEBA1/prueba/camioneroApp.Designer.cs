﻿namespace prueba
{
    partial class camioneroApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(camioneroApp));
            this.lbCammatricula = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.lbCamlotes = new System.Windows.Forms.Label();
            this.gbcamion = new System.Windows.Forms.GroupBox();
            this.gridbultos = new System.Windows.Forms.DataGridView();
            this.gridlotes = new System.Windows.Forms.DataGridView();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.lbCamdestinos = new System.Windows.Forms.Label();
            this.gbentrega = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.txtIdPaquete = new System.Windows.Forms.TextBox();
            this.lbCamentrega = new System.Windows.Forms.Label();
            this.btnSalir = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbCam = new System.Windows.Forms.Label();
            this.gbcamion.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridbultos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridlotes)).BeginInit();
            this.gbentrega.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbCammatricula
            // 
            this.lbCammatricula.AutoSize = true;
            this.lbCammatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCammatricula.Location = new System.Drawing.Point(8, 66);
            this.lbCammatricula.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbCammatricula.Name = "lbCammatricula";
            this.lbCammatricula.Size = new System.Drawing.Size(301, 25);
            this.lbCammatricula.TabIndex = 0;
            this.lbCammatricula.Text = "Ingresar matricula del camion:";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(349, 62);
            this.txtMatricula.Margin = new System.Windows.Forms.Padding(4);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(159, 30);
            this.txtMatricula.TabIndex = 1;
            // 
            // lbCamlotes
            // 
            this.lbCamlotes.AutoSize = true;
            this.lbCamlotes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCamlotes.ForeColor = System.Drawing.Color.Red;
            this.lbCamlotes.Location = new System.Drawing.Point(95, 175);
            this.lbCamlotes.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbCamlotes.Name = "lbCamlotes";
            this.lbCamlotes.Size = new System.Drawing.Size(299, 25);
            this.lbCamlotes.TabIndex = 3;
            this.lbCamlotes.Text = "Lotes asignados a su camion:";
            this.lbCamlotes.Click += new System.EventHandler(this.label2_Click);
            // 
            // gbcamion
            // 
            this.gbcamion.BackColor = System.Drawing.Color.AliceBlue;
            this.gbcamion.Controls.Add(this.gridbultos);
            this.gbcamion.Controls.Add(this.gridlotes);
            this.gbcamion.Controls.Add(this.btnRegistrar);
            this.gbcamion.Controls.Add(this.lbCamdestinos);
            this.gbcamion.Controls.Add(this.lbCamlotes);
            this.gbcamion.Controls.Add(this.txtMatricula);
            this.gbcamion.Controls.Add(this.lbCammatricula);
            this.gbcamion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbcamion.Location = new System.Drawing.Point(16, 95);
            this.gbcamion.Margin = new System.Windows.Forms.Padding(4);
            this.gbcamion.Name = "gbcamion";
            this.gbcamion.Padding = new System.Windows.Forms.Padding(4);
            this.gbcamion.Size = new System.Drawing.Size(531, 559);
            this.gbcamion.TabIndex = 4;
            this.gbcamion.TabStop = false;
            this.gbcamion.Text = "Infomacion de camion";
            // 
            // gridbultos
            // 
            this.gridbultos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridbultos.Location = new System.Drawing.Point(13, 382);
            this.gridbultos.Margin = new System.Windows.Forms.Padding(4);
            this.gridbultos.Name = "gridbultos";
            this.gridbultos.Size = new System.Drawing.Size(496, 170);
            this.gridbultos.TabIndex = 10;
            // 
            // gridlotes
            // 
            this.gridlotes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridlotes.Location = new System.Drawing.Point(100, 218);
            this.gridlotes.Margin = new System.Windows.Forms.Padding(4);
            this.gridlotes.Name = "gridlotes";
            this.gridlotes.Size = new System.Drawing.Size(320, 108);
            this.gridlotes.TabIndex = 9;
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrar.ForeColor = System.Drawing.Color.Green;
            this.btnRegistrar.Location = new System.Drawing.Point(349, 101);
            this.btnRegistrar.Margin = new System.Windows.Forms.Padding(4);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(160, 36);
            this.btnRegistrar.TabIndex = 8;
            this.btnRegistrar.Text = "INGRESAR";
            this.btnRegistrar.UseVisualStyleBackColor = true;
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);
            // 
            // lbCamdestinos
            // 
            this.lbCamdestinos.AutoSize = true;
            this.lbCamdestinos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCamdestinos.ForeColor = System.Drawing.Color.Red;
            this.lbCamdestinos.Location = new System.Drawing.Point(83, 353);
            this.lbCamdestinos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbCamdestinos.Name = "lbCamdestinos";
            this.lbCamdestinos.Size = new System.Drawing.Size(318, 25);
            this.lbCamdestinos.TabIndex = 6;
            this.lbCamdestinos.Text = "Destinos de entrega por lejania:";
            // 
            // gbentrega
            // 
            this.gbentrega.BackColor = System.Drawing.Color.AliceBlue;
            this.gbentrega.Controls.Add(this.button1);
            this.gbentrega.Controls.Add(this.txtIdPaquete);
            this.gbentrega.Controls.Add(this.lbCamentrega);
            this.gbentrega.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbentrega.ForeColor = System.Drawing.Color.Black;
            this.gbentrega.Location = new System.Drawing.Point(608, 95);
            this.gbentrega.Margin = new System.Windows.Forms.Padding(4);
            this.gbentrega.Name = "gbentrega";
            this.gbentrega.Padding = new System.Windows.Forms.Padding(4);
            this.gbentrega.Size = new System.Drawing.Size(531, 170);
            this.gbentrega.TabIndex = 5;
            this.gbentrega.TabStop = false;
            this.gbentrega.Text = "Paquetes entregados";
            this.gbentrega.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Green;
            this.button1.Location = new System.Drawing.Point(373, 101);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(149, 36);
            this.button1.TabIndex = 9;
            this.button1.Text = "INGRESAR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtIdPaquete
            // 
            this.txtIdPaquete.Location = new System.Drawing.Point(373, 62);
            this.txtIdPaquete.Margin = new System.Windows.Forms.Padding(4);
            this.txtIdPaquete.Name = "txtIdPaquete";
            this.txtIdPaquete.Size = new System.Drawing.Size(148, 30);
            this.txtIdPaquete.TabIndex = 1;
            // 
            // lbCamentrega
            // 
            this.lbCamentrega.AutoSize = true;
            this.lbCamentrega.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCamentrega.Location = new System.Drawing.Point(9, 65);
            this.lbCamentrega.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbCamentrega.Name = "lbCamentrega";
            this.lbCamentrega.Size = new System.Drawing.Size(323, 25);
            this.lbCamentrega.TabIndex = 0;
            this.lbCamentrega.Text = "Ingrese ID de paqute entregado:";
            // 
            // btnSalir
            // 
            this.btnSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.ForeColor = System.Drawing.Color.Red;
            this.btnSalir.Location = new System.Drawing.Point(1049, 14);
            this.btnSalir.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(91, 36);
            this.btnSalir.TabIndex = 7;
            this.btnSalir.Text = "SALIR";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click_1);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.lbCam);
            this.panel1.Controls.Add(this.btnSalir);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1152, 63);
            this.panel1.TabIndex = 18;
            // 
            // lbCam
            // 
            this.lbCam.AutoSize = true;
            this.lbCam.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCam.ForeColor = System.Drawing.Color.White;
            this.lbCam.Location = new System.Drawing.Point(471, 18);
            this.lbCam.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbCam.Name = "lbCam";
            this.lbCam.Size = new System.Drawing.Size(191, 31);
            this.lbCam.TabIndex = 0;
            this.lbCam.Text = "CAMIONERO";
            // 
            // camioneroApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1152, 658);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.gbentrega);
            this.Controls.Add(this.gbcamion);
            this.ForeColor = System.Drawing.Color.Black;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximumSize = new System.Drawing.Size(1170, 705);
            this.MinimumSize = new System.Drawing.Size(1170, 705);
            this.Name = "camioneroApp";
            this.Text = "Camioeros";
            this.Load += new System.EventHandler(this.camioneroApp_Load);
            this.gbcamion.ResumeLayout(false);
            this.gbcamion.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridbultos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridlotes)).EndInit();
            this.gbentrega.ResumeLayout(false);
            this.gbentrega.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbCammatricula;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label lbCamlotes;
        private System.Windows.Forms.GroupBox gbcamion;
        private System.Windows.Forms.Label lbCamdestinos;
        private System.Windows.Forms.GroupBox gbentrega;
        private System.Windows.Forms.TextBox txtIdPaquete;
        private System.Windows.Forms.Label lbCamentrega;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView gridlotes;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbCam;
        private System.Windows.Forms.DataGridView gridbultos;
    }
}