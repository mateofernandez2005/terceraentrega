﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;


namespace prueba
{
    class camionLote
    {

        protected int _id;
        protected string _Matricula;
        protected DateTime _fecha;

        protected ADODB.Connection _conexion;

        public camionLote()
        {
            _conexion = Program.cn;
            _id = 0;
            _Matricula = "";
            DateTime _fecha = new DateTime(2000, 10, 01, 10, 10, 10);

        }
        public camionLote(int id, string matricula,
        ADODB.Connection cn, DateTime fecha)
        {
            _id = id;
            _Matricula = matricula;
            _fecha = fecha;
        }
        public ADODB.Connection conexion
        {
            get { return (_conexion); }
            set { _conexion = value; }
        }
        public string matricula
        {
            get { return (_Matricula); }
            set { _Matricula = value; }
        }

        public int id
        {
            get { return (_id); }
            set { _id = value; }
        }
        public DateTime fecha
        {
            get { return (_fecha); }
            set { _fecha = value; }
        }

        public int InsertarDatos()
        {
            string sql;
            object filasAfectadas;

            if (_conexion.State != 0)
            {
                Console.Write(_id);
                //conexion abierta
                sql = "INSERT INTO camion_lote (id_lote, matricula, fecha) VALUES ('" + _id + "', '" + _Matricula + "', '" + _fecha.ToString("yyyy-MM-dd HH:mm:ss") + "')";
                string sqlUpdate = "UPDATE lote SET id_almacen = 0 WHERE id = '" + _id + "'"; // Nueva consulta para modificar id_almacen

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                    _conexion.Execute(sqlUpdate, out filasAfectadas); // Ejecutar la nueva consulta
                    return 3; // Retorno 3 para indicar éxito
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1; // Retorno 1 para indicar error
                }
            }
            else
            {
                return 2; // Retorno 2 para indicar que la conexión no está abierta
            }
        }


        public int InsertarDatos2()
        {
            string sql;
            object filasAfectadas;

            if (_conexion.State != 0)
            {
                Console.Write(_id);
                //conexion abierta
                sql = "INSERT INTO camion_lote (id_lote, matricula, fecha) VALUES ('" + _id + "', '" + _Matricula + "', '" + _fecha.ToString("yyyy-MM-dd HH:mm:ss") + "')";
                /*string sqlUpdate = "UPDATE lote SET id_almacen = 0 WHERE id = '" + _id + "'";*/ // Nueva consulta para modificar id_almacen

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                    //_conexion.Execute(sqlUpdate, out filasAfectadas); // Ejecutar la nueva consulta
                    return 3; // Retorno 3 para indicar éxito
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1; // Retorno 1 para indicar error
                }
            }
            else
            {
                return 2; // Retorno 2 para indicar que la conexión no está abierta
            }
        }

        public int buscarLoteCamion()
        {

            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;




            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "select id_lote from camion_lote where id_lote='" + _id + "'";

                try
                {
                    rs = _conexion.Execute(sql, out filasAfectadas);

                    if (!rs.EOF) //encontramos el paquete
                    {
                        return 3;
                    }
                    else //no encontre el paquete
                    {
                        return 2;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }
            }
            else
            {
                return 4;
            }


        }

        public int asignarDatos()
        {
            string sql;
            object filasAfectadas;

            if (_conexion.State != 0)
            {
                //conexion abierta
                
                 sql = "INSERT INTO camion_lote (id_lote, matricula, fecha) VALUES ('" + _id + "', '" + _Matricula + "', '" + _fecha.ToString("yyyy-MM-dd HH:mm:ss") + "')";


                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                    return 3; // Retorno 0 para indicar éxito
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1; // Retorno 1 para indicar error
                }
            }
            else
            {
                return 2; // Retorno 2 para indicar que la conexión no está abierta
            }
        }


        public int eliminarcamionlote()
        {
            String sql;
            String sql1;


            object filasAfectadas;
            int totalFilasAfectadas = 0;

            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "DELETE FROM camion_lote WHERE id_lote='" + _id + "'";
                sql1 = "DELETE FROM manejar WHERE matricula NOT IN (SELECT matricula FROM camion_lote)";

                try
                {


                    ADODB.Recordset rs1 = _conexion.Execute(sql, out filasAfectadas);
                    totalFilasAfectadas += (int)filasAfectadas;

                    ADODB.Recordset rs2 = _conexion.Execute(sql1, out filasAfectadas);
                    totalFilasAfectadas += (int)filasAfectadas;


                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }

                if (totalFilasAfectadas > 0) //eliminamos el camion
                {
                    return 3;
                }
                else //no encontre el camion
                {
                    return 2;
                }
            }
            else
            {
                return 4; // La conexión no está abierta
            }
        }

        public DataTable RecordsetToDataTable(ADODB.Recordset recordset)
        {
            DataTable dataTable = new DataTable();

            for (int i = 0; i < recordset.Fields.Count; i++)
            {
                dataTable.Columns.Add(recordset.Fields[i].Name, typeof(string));
            }

            while (!recordset.EOF)
            {
                DataRow dataRow = dataTable.NewRow();
                for (int i = 0; i < recordset.Fields.Count; i++)
                {
                    dataRow[i] = recordset.Fields[i].Value.ToString();
                }
                dataTable.Rows.Add(dataRow);
                recordset.MoveNext();
            }

            return dataTable;
        }
        //ObtenerDatoscamionlote
        public DataTable ObtenerDatoscamionlote()
        {

            DataTable dataTable = new DataTable();

            if (_conexion.State != 0)
            {
                //conexion abierta
                string sql = "SELECT matricula, id_lote FROM camion_lote;";

                try
                {

                    ADODB.Recordset rs = new ADODB.Recordset();


                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic);

                    
                    dataTable = RecordsetToDataTable(rs);
                }
                catch (Exception ex)
                {
                    
                    Console.WriteLine(ex.Message);

                }
            }


            return dataTable;
        }
        public List<Int32> obtenerLotesCamionero()
        {

         List<Int32> lista = new List<Int32>();
            Camion c = new Camion();

            c.matricula = _Matricula;

            

            int devolucion = c.buscarCamion();
            if (devolucion == 3) { 

                if (_conexion.State != 0)
            {
                //conexion abierta
                string sql = "select id_lote from camion_lote where matricula = '" + _Matricula + "'";

                try
                {

                    ADODB.Recordset rs = new ADODB.Recordset();
                    object filasAfectadas;
                    rs = _conexion.Execute(sql, out filasAfectadas);
                    


                    while (!rs.EOF)
                    {
                        lista.Add(Convert.ToInt32(rs.Fields[0].Value));
                        rs.MoveNext();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                 
                }
            }
            }
            else
            {
                return lista;
            }

            return lista;
        }


        public List<Tuple<Int32, double, double, double>> obtenerbultosCamionero()
        {
            List<Tuple<Int32, double, double, double>> lista = new List<Tuple<Int32, double, double, double>>();
            Camion c = new Camion();
            Paquete p = new Paquete();
            Almacen a = new Almacen();
            Usuario u = new Usuario();
            c.matricula = _Matricula;

            int devolucion = c.buscarCamion();
            if (devolucion == 3)
            {
                if (_conexion.State != 0)
                {
                    string sql = "SELECT b.id FROM bulto b WHERE EXISTS( SELECT 1 FROM bulto_lote bl JOIN camion_lote cl ON bl.id_lote = cl.id_lote WHERE b.id = bl.id_bulto AND cl.matricula  = '" + _Matricula + "')";
                    try
                    {
                        ADODB.Recordset rs = new ADODB.Recordset();
                        object filasAfectadas;
                        rs = _conexion.Execute(sql, out filasAfectadas);

                        while (!rs.EOF)
                        {
                            try
                            {
                                p.id = Convert.ToInt32(rs.Fields[0].Value);
                                u.ci = p.id;
                                a.id = p.id;
                                (double longitud, double latitud) = a.ObtenerLongitudLatitudAlmacen();
                                (double clongitud, double clatitud) = u.ObtenerLongitudLatitudCliente();
                                double distance = CalculateDistance(latitud, longitud, clatitud, clongitud);
                                longitud= Math.Round(longitud, 6);
                                latitud = Math.Round(latitud, 6);
                                distance = Math.Round(distance, 1);
                                lista.Add(new Tuple<Int32, double, double, double>(p.id, longitud, latitud, distance));
                                
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Error al procesar el bulto con ID: " + rs.Fields[0].Value + ". Detalles del error: " + ex.Message);
                            }
                            rs.MoveNext();
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error al ejecutar la consulta SQL. Detalles del error: " + ex.Message);
                    }
                }
            }

            lista.Sort((x, y) => x.Item4.CompareTo(y.Item4)); // Ordena la lista por distancia en orden ascendente
            return lista;
        }



        double CalculateDistance(double lat1, double lon1, double lat2, double lon2)
        {
            double r = 6371; // radio de la Tierra en km


            lat1 = lat1 * Math.PI / 180;
            lon1 = lon1 * Math.PI / 180;
            lat2 = lat2 * Math.PI / 180;
            lon2 = lon2 * Math.PI / 180;

            double dLat = lat2 - lat1;
            double dLon = lon2 - lon1;

            double res = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
                        Math.Cos(lat1) * Math.Cos(lat2) *
                        Math.Sin(dLon / 2) * Math.Sin(dLon / 2);

            double c = 2 * Math.Atan2(Math.Sqrt(res), Math.Sqrt(1 - res));

            return r * c;
        }


    }


}

