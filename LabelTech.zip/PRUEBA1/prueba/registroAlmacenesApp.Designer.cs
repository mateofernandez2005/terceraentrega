﻿namespace prueba
{
    partial class registroAlmacenesApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(registroAlmacenesApp));
            this.comborut = new System.Windows.Forms.ComboBox();
            this.txtL = new System.Windows.Forms.TextBox();
            this.lbboalmL = new System.Windows.Forms.Label();
            this.btnlimpiar = new System.Windows.Forms.Button();
            this.txtKg = new System.Windows.Forms.TextBox();
            this.lbboalmkg = new System.Windows.Forms.Label();
            this.txtCi = new System.Windows.Forms.TextBox();
            this.lbboalmci = new System.Windows.Forms.Label();
            this.lbboalmrut = new System.Windows.Forms.Label();
            this.txtLatitud = new System.Windows.Forms.TextBox();
            this.lbboalmlatitud = new System.Windows.Forms.Label();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.btnModificar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.txtIdAlmacen = new System.Windows.Forms.TextBox();
            this.lbboalmid = new System.Windows.Forms.Label();
            this.txtLongitud = new System.Windows.Forms.TextBox();
            this.lbboalmlongitud = new System.Windows.Forms.Label();
            this.btnSalir = new System.Windows.Forms.Button();
            this.gridalmacenes = new System.Windows.Forms.DataGridView();
            this.btnlistar = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnlista = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbboalmlistas = new System.Windows.Forms.Label();
            this.lbboalmregistro = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gridalmacenes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // comborut
            // 
            this.comborut.FormattingEnabled = true;
            this.comborut.Items.AddRange(new object[] {
            "123456789012"});
            this.comborut.Location = new System.Drawing.Point(421, 320);
            this.comborut.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comborut.Name = "comborut";
            this.comborut.Size = new System.Drawing.Size(165, 24);
            this.comborut.TabIndex = 27;
            // 
            // txtL
            // 
            this.txtL.Location = new System.Drawing.Point(421, 417);
            this.txtL.Margin = new System.Windows.Forms.Padding(4);
            this.txtL.Name = "txtL";
            this.txtL.Size = new System.Drawing.Size(165, 22);
            this.txtL.TabIndex = 26;
            // 
            // lbboalmL
            // 
            this.lbboalmL.AutoSize = true;
            this.lbboalmL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbboalmL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbboalmL.ForeColor = System.Drawing.Color.White;
            this.lbboalmL.Location = new System.Drawing.Point(80, 414);
            this.lbboalmL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbboalmL.Name = "lbboalmL";
            this.lbboalmL.Size = new System.Drawing.Size(218, 20);
            this.lbboalmL.TabIndex = 25;
            this.lbboalmL.Text = "Ingresar capacidad en L:";
            // 
            // btnlimpiar
            // 
            this.btnlimpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlimpiar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnlimpiar.Location = new System.Drawing.Point(497, 192);
            this.btnlimpiar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnlimpiar.Name = "btnlimpiar";
            this.btnlimpiar.Size = new System.Drawing.Size(91, 36);
            this.btnlimpiar.TabIndex = 17;
            this.btnlimpiar.Text = "LIMPIAR";
            this.btnlimpiar.UseVisualStyleBackColor = true;
            this.btnlimpiar.Click += new System.EventHandler(this.btnlimpiar_Click);
            // 
            // txtKg
            // 
            this.txtKg.Location = new System.Drawing.Point(421, 385);
            this.txtKg.Margin = new System.Windows.Forms.Padding(4);
            this.txtKg.Name = "txtKg";
            this.txtKg.Size = new System.Drawing.Size(165, 22);
            this.txtKg.TabIndex = 24;
            // 
            // lbboalmkg
            // 
            this.lbboalmkg.AutoSize = true;
            this.lbboalmkg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbboalmkg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbboalmkg.ForeColor = System.Drawing.Color.White;
            this.lbboalmkg.Location = new System.Drawing.Point(81, 384);
            this.lbboalmkg.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbboalmkg.Name = "lbboalmkg";
            this.lbboalmkg.Size = new System.Drawing.Size(226, 20);
            this.lbboalmkg.TabIndex = 23;
            this.lbboalmkg.Text = "Ingresar capacidad en kg:";
            // 
            // txtCi
            // 
            this.txtCi.Location = new System.Drawing.Point(421, 353);
            this.txtCi.Margin = new System.Windows.Forms.Padding(4);
            this.txtCi.Name = "txtCi";
            this.txtCi.Size = new System.Drawing.Size(165, 22);
            this.txtCi.TabIndex = 22;
            // 
            // lbboalmci
            // 
            this.lbboalmci.AutoSize = true;
            this.lbboalmci.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbboalmci.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbboalmci.ForeColor = System.Drawing.Color.White;
            this.lbboalmci.Location = new System.Drawing.Point(80, 353);
            this.lbboalmci.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbboalmci.Name = "lbboalmci";
            this.lbboalmci.Size = new System.Drawing.Size(250, 20);
            this.lbboalmci.TabIndex = 21;
            this.lbboalmci.Text = "Ingresar el ci del encargado:";
            // 
            // lbboalmrut
            // 
            this.lbboalmrut.AutoSize = true;
            this.lbboalmrut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbboalmrut.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbboalmrut.ForeColor = System.Drawing.Color.White;
            this.lbboalmrut.Location = new System.Drawing.Point(81, 322);
            this.lbboalmrut.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbboalmrut.Name = "lbboalmrut";
            this.lbboalmrut.Size = new System.Drawing.Size(259, 20);
            this.lbboalmrut.TabIndex = 19;
            this.lbboalmrut.Text = "Ingresar el rut de la empresa:";
            // 
            // txtLatitud
            // 
            this.txtLatitud.Location = new System.Drawing.Point(421, 289);
            this.txtLatitud.Margin = new System.Windows.Forms.Padding(4);
            this.txtLatitud.Name = "txtLatitud";
            this.txtLatitud.Size = new System.Drawing.Size(165, 22);
            this.txtLatitud.TabIndex = 18;
            // 
            // lbboalmlatitud
            // 
            this.lbboalmlatitud.AutoSize = true;
            this.lbboalmlatitud.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbboalmlatitud.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbboalmlatitud.ForeColor = System.Drawing.Color.White;
            this.lbboalmlatitud.Location = new System.Drawing.Point(81, 289);
            this.lbboalmlatitud.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbboalmlatitud.Name = "lbboalmlatitud";
            this.lbboalmlatitud.Size = new System.Drawing.Size(270, 20);
            this.lbboalmlatitud.TabIndex = 17;
            this.lbboalmlatitud.Text = "Ingresar la latitud del almacen:";
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrar.ForeColor = System.Drawing.Color.Green;
            this.btnRegistrar.Location = new System.Drawing.Point(85, 469);
            this.btnRegistrar.Margin = new System.Windows.Forms.Padding(4);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(125, 36);
            this.btnRegistrar.TabIndex = 16;
            this.btnRegistrar.Text = "Registrar";
            this.btnRegistrar.UseVisualStyleBackColor = true;
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click_1);
            // 
            // btnEliminar
            // 
            this.btnEliminar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminar.ForeColor = System.Drawing.Color.Red;
            this.btnEliminar.Location = new System.Drawing.Point(280, 469);
            this.btnEliminar.Margin = new System.Windows.Forms.Padding(4);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(125, 36);
            this.btnEliminar.TabIndex = 15;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click_1);
            // 
            // btnModificar
            // 
            this.btnModificar.BackColor = System.Drawing.Color.White;
            this.btnModificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificar.ForeColor = System.Drawing.Color.DarkBlue;
            this.btnModificar.Location = new System.Drawing.Point(463, 469);
            this.btnModificar.Margin = new System.Windows.Forms.Padding(4);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(125, 36);
            this.btnModificar.TabIndex = 14;
            this.btnModificar.Text = "Modificar";
            this.btnModificar.UseVisualStyleBackColor = false;
            this.btnModificar.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(493, 150);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(95, 36);
            this.button1.TabIndex = 12;
            this.button1.Text = "Buscar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtIdAlmacen
            // 
            this.txtIdAlmacen.Location = new System.Drawing.Point(340, 156);
            this.txtIdAlmacen.Margin = new System.Windows.Forms.Padding(4);
            this.txtIdAlmacen.Name = "txtIdAlmacen";
            this.txtIdAlmacen.Size = new System.Drawing.Size(132, 22);
            this.txtIdAlmacen.TabIndex = 11;
            // 
            // lbboalmid
            // 
            this.lbboalmid.AutoSize = true;
            this.lbboalmid.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbboalmid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbboalmid.ForeColor = System.Drawing.Color.White;
            this.lbboalmid.Location = new System.Drawing.Point(81, 158);
            this.lbboalmid.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbboalmid.Name = "lbboalmid";
            this.lbboalmid.Size = new System.Drawing.Size(207, 20);
            this.lbboalmid.TabIndex = 10;
            this.lbboalmid.Text = "Ingresar id de almacen:";
            // 
            // txtLongitud
            // 
            this.txtLongitud.Location = new System.Drawing.Point(421, 255);
            this.txtLongitud.Margin = new System.Windows.Forms.Padding(4);
            this.txtLongitud.Name = "txtLongitud";
            this.txtLongitud.Size = new System.Drawing.Size(165, 22);
            this.txtLongitud.TabIndex = 9;
            // 
            // lbboalmlongitud
            // 
            this.lbboalmlongitud.AutoSize = true;
            this.lbboalmlongitud.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbboalmlongitud.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbboalmlongitud.ForeColor = System.Drawing.Color.White;
            this.lbboalmlongitud.Location = new System.Drawing.Point(81, 258);
            this.lbboalmlongitud.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbboalmlongitud.Name = "lbboalmlongitud";
            this.lbboalmlongitud.Size = new System.Drawing.Size(284, 20);
            this.lbboalmlongitud.TabIndex = 1;
            this.lbboalmlongitud.Text = "Ingresar la longitud del almacen:";
            this.lbboalmlongitud.Click += new System.EventHandler(this.label16_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.ForeColor = System.Drawing.Color.Red;
            this.btnSalir.Location = new System.Drawing.Point(571, 591);
            this.btnSalir.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(91, 36);
            this.btnSalir.TabIndex = 12;
            this.btnSalir.Text = "SALIR";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // gridalmacenes
            // 
            this.gridalmacenes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridalmacenes.Location = new System.Drawing.Point(3, 0);
            this.gridalmacenes.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gridalmacenes.Name = "gridalmacenes";
            this.gridalmacenes.RowTemplate.Height = 24;
            this.gridalmacenes.Size = new System.Drawing.Size(341, 159);
            this.gridalmacenes.TabIndex = 18;
            this.gridalmacenes.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grindalmacenes_CellContentClick);
            // 
            // btnlistar
            // 
            this.btnlistar.FlatAppearance.BorderSize = 0;
            this.btnlistar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnlistar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlistar.ForeColor = System.Drawing.Color.Red;
            this.btnlistar.Location = new System.Drawing.Point(3, 91);
            this.btnlistar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnlistar.Name = "btnlistar";
            this.btnlistar.Size = new System.Drawing.Size(344, 36);
            this.btnlistar.TabIndex = 19;
            this.btnlistar.Text = "Actualizar";
            this.btnlistar.UseVisualStyleBackColor = true;
            this.btnlistar.Click += new System.EventHandler(this.btnlistar_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Location = new System.Drawing.Point(1, 2);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.Black;
            this.splitContainer1.Panel1.Controls.Add(this.panel2);
            this.splitContainer1.Panel1.Controls.Add(this.btnlista);
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.lbboalmregistro);
            this.splitContainer1.Panel2.Controls.Add(this.btnSalir);
            this.splitContainer1.Panel2.Controls.Add(this.comborut);
            this.splitContainer1.Panel2.Controls.Add(this.lbboalmid);
            this.splitContainer1.Panel2.Controls.Add(this.txtL);
            this.splitContainer1.Panel2.Controls.Add(this.lbboalmlongitud);
            this.splitContainer1.Panel2.Controls.Add(this.lbboalmL);
            this.splitContainer1.Panel2.Controls.Add(this.txtLongitud);
            this.splitContainer1.Panel2.Controls.Add(this.btnlimpiar);
            this.splitContainer1.Panel2.Controls.Add(this.txtIdAlmacen);
            this.splitContainer1.Panel2.Controls.Add(this.txtKg);
            this.splitContainer1.Panel2.Controls.Add(this.button1);
            this.splitContainer1.Panel2.Controls.Add(this.lbboalmkg);
            this.splitContainer1.Panel2.Controls.Add(this.btnModificar);
            this.splitContainer1.Panel2.Controls.Add(this.txtCi);
            this.splitContainer1.Panel2.Controls.Add(this.btnEliminar);
            this.splitContainer1.Panel2.Controls.Add(this.lbboalmci);
            this.splitContainer1.Panel2.Controls.Add(this.btnRegistrar);
            this.splitContainer1.Panel2.Controls.Add(this.lbboalmrut);
            this.splitContainer1.Panel2.Controls.Add(this.lbboalmlatitud);
            this.splitContainer1.Panel2.Controls.Add(this.txtLatitud);
            this.splitContainer1.Size = new System.Drawing.Size(1035, 639);
            this.splitContainer1.SplitterDistance = 344;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 20;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.gridalmacenes);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 205);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(344, 161);
            this.panel2.TabIndex = 2;
            // 
            // btnlista
            // 
            this.btnlista.BackColor = System.Drawing.Color.Black;
            this.btnlista.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnlista.FlatAppearance.BorderSize = 0;
            this.btnlista.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnlista.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlista.ForeColor = System.Drawing.Color.White;
            this.btnlista.Location = new System.Drawing.Point(0, 129);
            this.btnlista.Margin = new System.Windows.Forms.Padding(4);
            this.btnlista.Name = "btnlista";
            this.btnlista.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnlista.Size = new System.Drawing.Size(344, 76);
            this.btnlista.TabIndex = 1;
            this.btnlista.Text = "Lista de almacenes";
            this.btnlista.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnlista.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbboalmlistas);
            this.panel1.Controls.Add(this.btnlistar);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(344, 129);
            this.panel1.TabIndex = 0;
            // 
            // lbboalmlistas
            // 
            this.lbboalmlistas.AutoSize = true;
            this.lbboalmlistas.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbboalmlistas.ForeColor = System.Drawing.Color.White;
            this.lbboalmlistas.Location = new System.Drawing.Point(131, 49);
            this.lbboalmlistas.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbboalmlistas.Name = "lbboalmlistas";
            this.lbboalmlistas.Size = new System.Drawing.Size(81, 29);
            this.lbboalmlistas.TabIndex = 25;
            this.lbboalmlistas.Text = "Listas";
            this.lbboalmlistas.Click += new System.EventHandler(this.lbboalmlistas_Click);
            // 
            // lbboalmregistro
            // 
            this.lbboalmregistro.AutoSize = true;
            this.lbboalmregistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbboalmregistro.ForeColor = System.Drawing.Color.White;
            this.lbboalmregistro.Location = new System.Drawing.Point(80, 100);
            this.lbboalmregistro.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbboalmregistro.Name = "lbboalmregistro";
            this.lbboalmregistro.Size = new System.Drawing.Size(282, 29);
            this.lbboalmregistro.TabIndex = 32;
            this.lbboalmregistro.Text = "Registro de almacenes";
            // 
            // registroAlmacenesApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1027, 642);
            this.Controls.Add(this.splitContainer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "registroAlmacenesApp";
            this.Text = "Registro almacenes";
            this.Load += new System.EventHandler(this.registroAlmacenesApp_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridalmacenes)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox txtLongitud;
        private System.Windows.Forms.Label lbboalmlongitud;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.TextBox txtIdAlmacen;
        private System.Windows.Forms.Label lbboalmid;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.TextBox txtL;
        private System.Windows.Forms.Label lbboalmL;
        private System.Windows.Forms.TextBox txtKg;
        private System.Windows.Forms.Label lbboalmkg;
        private System.Windows.Forms.TextBox txtCi;
        private System.Windows.Forms.Label lbboalmci;
        private System.Windows.Forms.Label lbboalmrut;
        private System.Windows.Forms.TextBox txtLatitud;
        private System.Windows.Forms.Label lbboalmlatitud;
        private System.Windows.Forms.Button btnlimpiar;
        private System.Windows.Forms.DataGridView gridalmacenes;
        private System.Windows.Forms.Button btnlistar;
        private System.Windows.Forms.ComboBox comborut;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbboalmlistas;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnlista;
        private System.Windows.Forms.Label lbboalmregistro;
    }
}