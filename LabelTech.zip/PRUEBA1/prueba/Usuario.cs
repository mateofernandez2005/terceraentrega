﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace prueba
{
    class Usuario
    {


        //public string usuario { get; set; }
        //public string contraseña { get; set; }
        //public byte rol { get; set; }

        protected double _longitud;
        protected double _latitud;
        protected int _ci;
        protected string _nombre;
        protected string _apellido;
        protected string _celular;
        protected int _idIdioma;
        protected int _rol;
        protected string _Usuario;
        protected string _contrasenia;
        protected ADODB.Connection _conexion;
        

        public Usuario()
        {
            _conexion = Program.cn;
            _ci = 0;
            _nombre = "";
            _apellido = "";
            _celular = "";
            _idIdioma = 0;
            _rol = 0;
            _Usuario = "";
            _contrasenia = "";
        }

        public Usuario(int ci, string nombre, string apellido, string celular, int idIdioma, int rol,
ADODB.Connection cn, string usuario, string contrasenia, double latitud, double longitud)
        {
            _latitud = latitud;
            _longitud = longitud;
            _ci = ci;
            _nombre = nombre;
            _apellido = apellido;
            _conexion = cn;
            _celular = celular;
            _idIdioma = idIdioma;
            _rol = rol;
            _Usuario = usuario;
            _contrasenia = contrasenia;
        }

        public ADODB.Connection conexion
        {
            get { return (_conexion); }
            set { _conexion = value; }
        }
        public string nombre
        {
            get { return (_nombre); }
            set { _nombre = value; }
        }

        public int ci
        {
            get { return (_ci); }
            set { _ci = value; }
        }
        public string apellido
        {
            get { return (_apellido); }
            set { _apellido = value; }
        }

        public int idIdioma
        {
            get { return (_idIdioma); }
            set { _idIdioma = value; }
        }


        public int rol
        {
            get { return (_rol); }
            set { _rol = value; }
        }

        public string usuario
        {
            get { return (_Usuario); }
            set { _Usuario = value; }
        }
        public string contrasenia
        {
            get { return (_contrasenia); }
            set { _contrasenia = value; }
        }
        public string celular
        {
            get { return (_celular); }
            set { _celular = value; }
        }
        public double longitud
        {
            get { return (_longitud); }
            set { _longitud = value; }
        }
        public double latitud
        {
            get { return (_latitud); }
            set { _latitud = value; }
        }


        public byte ValidoUsuario()
        {
            
            

            String sql;
            ADODB.Recordset rs;
            object filasAfectadas;
            byte rol = 0;
            try
            {
               if(Program.cn.State!=0)
                {
                    Program.cn.Close();
                }
                Program.cn.Open("br", usuario, contrasenia);
            }

            catch
            {
                Console.WriteLine("0");
                return 0;
                
           }
     
            if (Program.cn.State != 0)
            { //conexion abierta

                sql = "select id_rol from usuario where nombreUsuario='" + usuario + "'";

                try
                {
                    rs = Program.cn.Execute(sql, out filasAfectadas);
                    
                }
                catch
                {
                    Console.WriteLine("121");
                    return 121;
                }
                if (rs.RecordCount == 0) //no encontramos el rol de usuario
                {
                    Console.WriteLine("203");
                    return 203;
                }
                else //ENcontramos el rol  
                {

                    rol = Convert.ToByte(rs.Fields[0].Value);
                    return rol;
                }
            }
            else
            {
                rol = 106;
            }
            return rol;

            


        }

        public int buscarUsuario()
        {

            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;




            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "select nombreUsuario from usuario where nombreUsuario='" + _Usuario + "'";

                try
                {
                    rs = _conexion.Execute(sql, out filasAfectadas);

                    if (!rs.EOF) //encontramos el paquete
                    {
                        return 3;
                    }
                    else //no encontre el paquete
                    {
                        return 2;
                    }
                }
                catch
                {
                    //int num = int.Parse(sql);
                    return 1;
                }
            }
            else
            {
                return 4;
            }
        }

        public int registrardDatos()
        {
            string sql;
            string sql1;
            string sql2;
            string sql3;
            string sql4;
            string sql5;
            string sql6;
            string sql7;
            ADODB.Recordset rs;

            object filasAfectadas;

            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "select Ci from usuario where nombreUsuario='" + _Usuario + "'";
                sql1 = "select id_rol from usuario where nombreUsuario='" + _Usuario + "'";
                sql2 = "select celular from usuario where nombreUsuario='" + _Usuario + "'";
                sql3 = "select nombre from usuario where nombreUsuario='" + _Usuario + "'";
                sql4 = "select apellido from usuario where nombreUsuario='" + _Usuario + "'";
                sql5 = "select id_idioma from usuario where nombreUsuario='" + _Usuario + "'";
                sql6 = "select longitud from usuario where nombreUsuario='" + _Usuario + "'";
                sql7 = "select latitud from usuario where nombreUsuario='" + _Usuario + "'";

                try
                {
                   
                    rs = _conexion.Execute(sql, out filasAfectadas);
                    _ci = Convert.ToInt32(rs.Fields["Ci"].Value);
                    rs = _conexion.Execute(sql1, out filasAfectadas);
                    _rol = (sbyte)Convert.ToByte(rs.Fields["id_rol"].Value);
                    rs = _conexion.Execute(sql2, out filasAfectadas);
                    _celular = rs.Fields["celular"].Value.ToString();

                    rs = _conexion.Execute(sql3, out filasAfectadas);
                    _nombre = rs.Fields["nombre"].Value.ToString();
                    rs = _conexion.Execute(sql4, out filasAfectadas);
                    _apellido = rs.Fields["apellido"].Value.ToString();
                    rs = _conexion.Execute(sql5, out filasAfectadas);
                    _idIdioma = (sbyte)Convert.ToByte(rs.Fields["id_idioma"].Value);

                    rs = _conexion.Execute(sql7, out filasAfectadas);
                    _latitud = Convert.ToSingle(rs.Fields["latitud"].Value);
                    rs = _conexion.Execute(sql6, out filasAfectadas);
                    _longitud = Convert.ToSingle(rs.Fields["longitud"].Value);
                    return 3;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }
            }
            else
            {
                return 4;
            }
        }
        public int registrarUsuario()
        {
            string sql;
            string sql1;
            string sql2;
            ADODB.Recordset rs;
            object filasAfectadas;



            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "INSERT INTO usuario (Ci, id_rol, celular, apellido, nombre, id_idioma, nombreUsuario, longitud, latitud) VALUES(" + _ci + "," + _rol + ",'" + _celular + "','" + _apellido + "','" + _nombre + "'," + _idIdioma + ",'" + _Usuario + "',"+_longitud +"," + _latitud +")";
                
                sql2 = "select id_rol from usuario where nombreUsuario='" + usuario + "'";
                try
                {

                    _conexion.Execute(sql, out filasAfectadas);
                   
                    rs = _conexion.Execute(sql2, out filasAfectadas);
                    int rol = Convert.ToInt32(rs.Fields["id_rol"].Value);
                    Console.WriteLine("hola3"+sql2);
                    if (rol == 1)
                    {
                        Console.WriteLine("hola2");
                        string sql3;
                        sql3 = " INSERT INTO almacenero(Ci) VALUES (" + _ci + ")";
                        sql1 = "create user '" + _Usuario + "' identified by'" + _contrasenia + "'";
                        try
                        {
                            _conexion.Execute(sql1, out filasAfectadas);
                            _conexion.Execute(sql3, out filasAfectadas);

                            Console.WriteLine("hola1");
                            return 3;
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                            return 1;
                        }
                    }

                    else if (rol == 2)
                    {
                        string sql4;
                        sql4 = " INSERT INTO camionero(Ci) VALUES (" + _ci + ")";
                        sql1 = "create user '" + _Usuario + "' identified by'" + _contrasenia + "'";
                        try
                        {
                            _conexion.Execute(sql1, out filasAfectadas);
                            _conexion.Execute(sql4, out filasAfectadas);


                            return 3;
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                            return 1;
                        }
                    }
                    else if (rol == 3)
                    {
                        string sql5;
                        sql5 = " INSERT INTO backoffice(Ci) VALUES (" + _ci + ")";
                        sql1 = "create user '" + _Usuario + "' identified by'" + _contrasenia + "'";
                        try
                        {
                            _conexion.Execute(sql1, out filasAfectadas);
                            _conexion.Execute(sql5, out filasAfectadas);


                            return 3;
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                            return 1;
                        }
                    }
                    else if (rol == 4)
                    {
                        string sql5;
                        sql5 = " INSERT INTO cliente (Ci, longitud, latitud) VALUES (" + _ci + "," + _longitud + "," + _latitud + ")";

                        try
                        {
                            
                            _conexion.Execute(sql5, out filasAfectadas);


                            return 3;
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                            return 1;
                        }
                    }

                    return 3;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }
            }
            else
            {
                return 4;
            }


        }
        public int eliminarUsuario()
        {
            String sql;
            String sql1;
            String sql2;
            String sql3;
            String sql4;
            String sql5;

            object filasAfectadas;
            int totalFilasAfectadas = 0;

            if (_conexion.State != 0)
            {
                //conexion abierta

                sql = "DELETE FROM backoffice WHERE Ci=" + _ci;
                sql1 = "DELETE FROM camionero WHERE Ci=" + _ci;
                sql2 = "DELETE FROM almacenero WHERE Ci=" + _ci;
                sql3 = "DELETE FROM cliente WHERE Ci=" + _ci;
                sql4 = "DELETE FROM bulto WHERE ci_cliente=" + _ci;
                sql5 = "DELETE FROM usuario WHERE Ci=" + _ci;

                try
                {
                    ADODB.Recordset rs1 = _conexion.Execute(sql, out filasAfectadas);
                    totalFilasAfectadas += (int)filasAfectadas;

                    ADODB.Recordset rs2 = _conexion.Execute(sql1, out filasAfectadas);
                    totalFilasAfectadas += (int)filasAfectadas;

                    ADODB.Recordset rs3 = _conexion.Execute(sql2, out filasAfectadas);
                    totalFilasAfectadas += (int)filasAfectadas;

                    ADODB.Recordset rs4 = _conexion.Execute(sql3, out filasAfectadas);
                    totalFilasAfectadas += (int)filasAfectadas;

                    ADODB.Recordset rs5 = _conexion.Execute(sql4, out filasAfectadas);
                    totalFilasAfectadas += (int)filasAfectadas;

                    ADODB.Recordset rs6 = _conexion.Execute(sql5, out filasAfectadas);
                    totalFilasAfectadas += (int)filasAfectadas;

                    
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }

                if (totalFilasAfectadas > 0) //eliminamos el usuario
                {
                    return 3;
                }
                else //no encontre el usuario
                {
                    return 2;
                }
            }
            else
            {
                return 4; // La conexión no está abierta
            }
        }
        public int modificarUsario()
        {
            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;



            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "UPDATE usuario SET id_rol = " + _rol + ", celular = '" + _celular + "', apellido = '" + _apellido + "', ci = " + _ci + ", nombre = '" + _nombre + "', id_idioma = " + _idIdioma + ", longitud = " + _longitud + ", latitud = " + _latitud + " WHERE nombreUsuario = '" + _Usuario + "';";


                try
                {

                    _conexion.Execute(sql, out filasAfectadas);



                    return 3;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }
            }
            else
            {
                return 4;
            }


        }
        public DataTable RecordsetToDataTable(ADODB.Recordset recordset)
        {
            DataTable dataTable = new DataTable();

            for (int i = 0; i < recordset.Fields.Count; i++)
            {
                dataTable.Columns.Add(recordset.Fields[i].Name, typeof(string));
            }

            while (!recordset.EOF)
            {
                DataRow dataRow = dataTable.NewRow();
                for (int i = 0; i < recordset.Fields.Count; i++)
                {
                    dataRow[i] = recordset.Fields[i].Value.ToString();
                }
                dataTable.Rows.Add(dataRow);
                recordset.MoveNext();
            }

            return dataTable;
        }

        public DataTable ObtenerDatosUsuario()
        {

            DataTable dataTable = new DataTable();

            if (_conexion.State != 0)
            {
                //conexion abierta
                string sql = "SELECT * FROM usuario;";

                try
                {

                    ADODB.Recordset rs = new ADODB.Recordset();


                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic);


                    dataTable = RecordsetToDataTable(rs);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }


            return dataTable;
        }

        public int buscarCamionero()
        {

            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;




            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "select ci from camionero where ci='" + _ci + "'";

                try
                {
                    rs = _conexion.Execute(sql, out filasAfectadas);

                    if (!rs.EOF) //encontramos el paquete
                    {
                        return 3;
                    }
                    else //no encontre el paquete
                    {
                        return 2;
                    }
                }
                catch
                {
                    //int num = int.Parse(sql);
                    return 1;
                }
            }
            else
            {
                return 4;
            }
        }

        public (double, double) ObtenerLongitudLatitudCliente(int idBulto)
        {
            Paquete P = new Paquete();

            if (_conexion.State != 0)
            {
                string sql = @"SELECT cliente.longitud, cliente.latitud
                       FROM bulto
                       JOIN cliente ON bulto.ci_cliente = cliente.Ci
                       WHERE bulto.id = " + P.id;

                try
                {
                    ADODB.Recordset rs = new ADODB.Recordset();
                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic);

                    if (!rs.EOF)
                    {
                        _longitud = Convert.ToDouble(rs.Fields["longitud"].Value);
                        _latitud = Convert.ToDouble(rs.Fields["latitud"].Value);
                    }

                    rs.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            return (_longitud, _latitud);
        }
        public (double, double) ObtenerLongitudLatitudCliente()
        {
            Paquete p = new Paquete();
            ADODB.Recordset rs;
            
            p.id = ci;
           
            string sqlLongitud;
            string sqlLatitud;
            object filasAfectadas;
            if (_conexion.State != 0)
            {
                // Consulta para obtener la longitud
                sqlLatitud  = "SELECT c.latitud FROM cliente c JOIN bulto b ON c.Ci = b.ci_cliente WHERE b.id = " + p.id;

                // Consulta para obtener la latitud
                sqlLongitud = "SELECT c.longitud FROM cliente c JOIN bulto b ON c.Ci = b.ci_cliente WHERE b.id = " + p.id;

                try
                {


                    rs = _conexion.Execute(sqlLatitud, out filasAfectadas);
                    _latitud = Convert.ToSingle(rs.Fields["latitud"].Value);
                    rs = _conexion.Execute(sqlLongitud, out filasAfectadas);
                    _longitud = Convert.ToSingle(rs.Fields["longitud"].Value);
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.Message);
                }
            }

            return (_longitud, _latitud);
        }
    }
}