﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.Json;

namespace prueba
{
    public partial class usuarioApp : Form
    {
        public usuarioApp()
        {
            InitializeComponent();
            if (variables.idiom == true)
            {
                lbclien.Text = "Customer";
                lbclienlocalizar.Text = "Locate Packages";
                lbclienid.Text = "Enter Package ID";
                lbcliendatos.Text = "Package details:";
                lbclienlote.Text = "lot:";
                lbcliencamion.Text = "truck";
                lbcliencamionero.Text = "truck driver:";
                lbclienestado.Text = "shipping status:";
                lbcliendemora.Text = "Estimated delay (min)";
                lbclienfecha.Text = "departure date";
                año.Text = "year";
                label10.Text = "month";
                label11.Text = "day";
                label13.Text = "hs";
                btnSalir.Text = "exit";
                btnIngresar.Text = "GET INTO";
                btnSalir.Text = "exit";
               
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Menu frmMenu = new Menu();
            this.Hide();
            frmMenu.Show();
        }

        private void btnSalir_Click_1(object sender, EventArgs e)
        {
            Menu frmMenu = new Menu();
            this.Hide();
            frmMenu.Show();
            Program.cn.Close();
            frmMenu.almacenero.Enabled = false;
            frmMenu.camionero.Enabled = false;
            frmMenu.backoffice.Enabled = false;
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void usuarioApp_Load(object sender, EventArgs e)
        {

        }
        internal class clientePaquete
        {
            public int idbulto { set; get; }
            public int idlote { set; get; }
            public string matricula { set; get; }
            public string nombrecamionero { set; get; }
            public string apellidocamionero { set; get; }
            public string estadodeenvio { set; get; }
            public double demora { set; get; }
            public int anio { set; get; }
            public int mes { set; get; }
            public int dia { set; get; }
            public int hora { set; get; }

        }

            private void btnIngresar_Click(object sender, EventArgs e)
        {
            
            Paquete p = new Paquete();

             


            String cpserializado;
            String resultado;
            clientePaquete cp = new clientePaquete();
            clientePaquete cpp;
            //p.id = lc.id;
            string sidbulto = txtId.Text;
            int intidbulto;
            bool isIdValid = int.TryParse(sidbulto, out intidbulto);
            if (!isIdValid)
            {
                if (variables.idiom == true)
                {
                    Console.WriteLine("The data type of the id is not valid");
                }
                else
                {
                    Console.WriteLine("El tipo de dato del id no es valido");
                }
            }
            p.id = intidbulto;
            cp.idbulto = intidbulto;

            cpserializado = JsonSerializer.Serialize(cp);

            resultado = apiTransito.registrodatos(cpserializado);

            cpserializado = JsonSerializer.Serialize(cp);
            resultado = apiTransito.registrodatos(cpserializado);








            cpp = JsonSerializer.Deserialize<clientePaquete>(resultado);


            //txtanio.Text = cpp.anio.ToString();
            //txtmes.Text = cpp.mes.ToString();
            //txtdia.Text = cpp.dia.ToString();
            //txths.Text = cpp.hora.ToString();


            if(cpp.estadodeenvio== "recibido por el clie")
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The package has already been delivered");
                }
                else
                {
                    MessageBox.Show("el paquete ya fue entregado");
                }
            }
            else if (cpp.matricula == null)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The package was not sent");
                }
                else
                {
                    MessageBox.Show("el paquete no fue enviado");
                }
            }
            else
            {
                txtCamion.Text = cpp.matricula;
                string nombreapellido = cpp.nombrecamionero + " " + cpp.apellidocamionero;
                txtCamionero.Text = nombreapellido;


                int hola = Convert.ToInt32(Math.Floor(cpp.demora));
                txtDemora.Text = hola.ToString();
                txtLote.Text = cpp.idlote.ToString();
                txtenvio.Text = cpp.estadodeenvio;
                txtanio.Text = cpp.anio.ToString();
                txtmes.Text = cpp.mes.ToString();
                txtdia.Text = cpp.dia.ToString();
                txths.Text = cpp.hora.ToString();
            }
            


           // if (cpp.idlote == -1)
           // {
           //     txtLote.Text = " ";
           // }
           // else
           // {
           //     txtLote.Text = cpp.idlote.ToString();
           // }

           //if (cpp.matricula == null)
           // {
           //     MessageBox.Show("el paquete no fue enviado");
           // }
           // else
           // {
           //     txtenvio.Text = cpp.estadodeenvio;

           // }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }


}
    
    

