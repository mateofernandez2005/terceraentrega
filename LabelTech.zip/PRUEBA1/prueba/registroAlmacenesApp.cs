﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Numerics;
using System.Data.OleDb;

namespace prueba
{
    public partial class registroAlmacenesApp : Form
    {
        public registroAlmacenesApp()
        {
            InitializeComponent();
            btnRegistrar.Enabled = false;
            btnEliminar.Enabled = false;
            btnModificar.Enabled = false;
            Almacen A = new Almacen();
            gridalmacenes.DataSource = A.ObtenerDatosAlmacen();

            if (variables.idiom == true)
            {
                lbboalmlistas.Text = "lists";
                btnlistar.Text = "update";
                btnlista.Text = "lists of warehouses";
                btnSalir.Text = "exit";
                lbboalmregistro.Text = "Warehouse registration";
                lbboalmlongitud.Text = "Enter the length of the warehouse:";
                lbboalmid.Text = "Enter warehouse id:";
                lbboalmlatitud.Text = "Enter the latitude of the warehouse:";
                lbboalmrut.Text = "Enter the company ID:";
                lbboalmci.Text = "Ingresar el ci del encargado:";
                lbboalmkg.Text = "Enter capacity in kg:";
                lbboalmL.Text = "Enter capacity in L:";
                button1.Text = "search";
                btnlimpiar.Text = "clean";
                btnRegistrar.Text = "register";
                btnEliminar.Text = "delete";
                btnModificar.Text = "Modify";
            }












        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            backofficeApp frmbackofficeApp = new backofficeApp();
            this.Hide();
            frmbackofficeApp.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {


            Almacen A = new Almacen();
            A.registrardDatos();

            string idpaquete = txtIdAlmacen.Text;
            int intpaquete = int.Parse(idpaquete);
           A.id = intpaquete;


            int devolucion = A.buscarAlmacen();
            if (devolucion == 1) //eror al buscarlo 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error searching for the id" + devolucion);
                }
                else
                {
                    MessageBox.Show("Error al buscar el id" + devolucion);
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The warehouse was not found, if you want to add it press register");
                }
                else
                {
                    MessageBox.Show("no se encontro el almacen, si desea añadirlo apriete registrar");
                }
                btnRegistrar.Enabled = true;
                btnEliminar.Enabled = false;
                btnModificar.Enabled = false;
            }

            else if (devolucion == 3) //ENcontramos el paquete 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The warehouse was found, do you want to delete or modify it?");
                }
                else
                {
                    MessageBox.Show("se encontro el almacen, desea eliminarlo o modificarlo?");
                }
                A.registrardDatos();
                string Slatitud = A.latitud.ToString();
                txtLatitud.Text = Slatitud;
                string Slongitud = A.longitud.ToString();
                txtLongitud.Text = Slongitud;
                string Srutempresa= A.rutEmpresa.ToString();
                comborut.Text = Srutempresa;

                string Scialmacenero = A.ciAlmacenero.ToString();
                txtCi.Text = Scialmacenero;
                string ScapacidadKg = A.capacidadKg.ToString();
                txtKg.Text = ScapacidadKg;
                string ScapacidadM3 = A.capacidadM3.ToString();
                txtL.Text = ScapacidadM3;
                btnEliminar.Enabled = true;
                btnModificar.Enabled = true;
                btnRegistrar.Enabled = false;
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Resounding error");
                }
                else
                {
                    MessageBox.Show("error rotundo ");
                }
            }








        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {

        }

        private void btnModificar_Click(object sender, EventArgs e)
        {

        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {

        }

        private void btnRegistrar_Click_1(object sender, EventArgs e)
        {

            Almacen A = new Almacen();

            string idAlmacen = txtIdAlmacen.Text;
            String capacidadLts = txtL.Text;
            String capaciadKg = txtKg.Text;
            string longitud = txtLongitud.Text;
            string latitud = txtLongitud.Text;
            string ciAlmacenero = txtCi.Text;
            string rut = comborut.Text;


            int intcapacidadLts;
            bool successCapacidadLts = int.TryParse(capacidadLts, out intcapacidadLts);

            if (successCapacidadLts)
            {
                // El parseo fue exitoso, puedes usar intcapacidadLts aquí.
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, check the data type of capacity");
                }
                else
                {
                    MessageBox.Show("Error, compruebe el tipo de dato de capacidad");
                }
            }

            int intcapacidadKg;
            bool success = int.TryParse(capaciadKg, out intcapacidadKg);

            if (success)
            {
                // El parseo fue exitoso, puedes usar intcapacidadKg aquí.
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, check the data type of capacity");
                }
                else
                {
                    MessageBox.Show("Error, compruebe el tipo de dato de capacidad");
                }
            }

            int intid;
            bool successId = int.TryParse(idAlmacen, out intid);

            if (successId)
            {
                // El parseo fue exitoso, puedes usar intid aquí.
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, check the data type of warehouse");
                }
                else
                {
                    MessageBox.Show("Error, compruebe el tipo de dato de almacen");
                }
            }

            double intlongitud;
            bool successLongitud = double.TryParse(longitud, out intlongitud);

            if (successLongitud)
            {
                // El parseo fue exitoso, puedes usar intlongitud aquí.
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, check the data type of length");
                }
                else
                {
                    MessageBox.Show("Error, compruebe el tipo de dato de longitud");
                }
            }

            double intlatitud;
            bool successLatitud = double.TryParse(latitud, out intlatitud);

            if (successLatitud)
            {
                // El parseo fue exitoso, puedes usar intlatitud aquí.
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, check the data type of latitude");
                }
                else
                {
                    MessageBox.Show("Error, compruebe el tipo de dato de latitud");
                }
            }

            int intci;
            bool successCi = int.TryParse(ciAlmacenero, out intci);

            if (successCi)
            {
                // El parseo fue exitoso, puedes usar intci aquí.
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, check the data type of cialmacenero");
                }
                else
                {
                    MessageBox.Show("Error, compruebe el tipo de dato de cialmacenero");
                }
            }

            BigInteger intrut;
            bool successRut = BigInteger.TryParse(rut, out intrut);

            if (successRut)
            {
                // El parseo fue exitoso, puedes usar intrut aquí.
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, check the data type of rut");
                }
                else
                {
                    MessageBox.Show("Error, compruebe el tipo de dato de rut");
                }
            }


            A.id = intid;
            A.capacidadKg = intcapacidadKg;
            A.capacidadM3 = intcapacidadLts;
            A.longitud = intlongitud;
            A.latitud = intlatitud;
            A.ciAlmacenero = intci;
            A.rutEmpresa = intrut;

            

            int devolucion = A.registrarAlmacen();
            if (devolucion == 1) //eror al buscarlo 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, verify the rut and the ci of the person in charge (if registered)");
                }
                else
                {
                    MessageBox.Show("Error, verifique el rut y el ci del encargado (si se encuentra registrado) ");
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The truck was not found, if you want to add it press register");
                }
                else
                {
                    MessageBox.Show("no se encontro el camion, si desea añadirlo apriete registrar");
                }

            }

            else if (devolucion == 3) //ENcontramos el paquete 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Registered correctly");
                }
                else
                {
                    MessageBox.Show("se registro correctamente ");
                }



            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Connection closed");
                }
                else
                {
                    MessageBox.Show("conexion cerrada  ");
                }
            }

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            Almacen A = new Almacen();

            string idAlmacen = txtIdAlmacen.Text;
            String capacidadLts = txtL.Text;
            String capaciadKg = txtKg.Text;
            string longitud = txtLongitud.Text;
            string latitud = txtLongitud.Text;
            string ciAlmacenero = txtCi.Text;
            string rut = comborut.Text;


            int intcapacidadLts;
            bool successCapacidadLts = int.TryParse(capacidadLts, out intcapacidadLts);

            if (successCapacidadLts)
            {
                // El parseo fue exitoso, puedes usar intcapacidadLts aquí.
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, check the data type of capacity");
                }
                else
                {
                    MessageBox.Show("Error, compruebe el tipo de dato de capacidad");
                }
            }

            int intcapacidadKg;
            bool success = int.TryParse(capaciadKg, out intcapacidadKg);

            if (success)
            {
                // El parseo fue exitoso, puedes usar intcapacidadKg aquí.
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, check the data type of capacity");
                }
                else
                {
                    MessageBox.Show("Error, compruebe el tipo de dato de capacidad");
                }
            }

            int intid;
            bool successId = int.TryParse(idAlmacen, out intid);

            if (successId)
            {
                // El parseo fue exitoso, puedes usar intid aquí.
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, check the data type of warehouse");
                }
                else
                {
                    MessageBox.Show("Error, compruebe el tipo de dato de almacen");
                }
            }

            double intlongitud;
            bool successLongitud = double.TryParse(longitud, out intlongitud);

            if (successLongitud)
            {
                // El parseo fue exitoso, puedes usar intlongitud aquí.
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, check the data type of length");
                }
                else
                {
                    MessageBox.Show("Error, compruebe el tipo de dato de longitud");
                }
            }

            double intlatitud;
            bool successLatitud = double.TryParse(latitud, out intlatitud);

            if (successLatitud)
            {
                // El parseo fue exitoso, puedes usar intlatitud aquí.
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, check the data type of latitude");
                }
                else
                {
                    MessageBox.Show("Error, compruebe el tipo de dato de latitud");
                }
            }

            int intci;
            bool successCi = int.TryParse(ciAlmacenero, out intci);

            if (successCi)
            {
                // El parseo fue exitoso, puedes usar intci aquí.
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, check the data type of cialmacenero");
                }
                else
                {
                    MessageBox.Show("Error, compruebe el tipo de dato de cialmacenero");
                }
            }

            BigInteger intrut;
            bool successRut = BigInteger.TryParse(rut, out intrut);

            if (successRut)
            {
                // El parseo fue exitoso, puedes usar intrut aquí.
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, check the data type of rut");
                }
                else
                {
                    MessageBox.Show("Error, compruebe el tipo de dato de rut");
                }
            }

            A.id = intid;
            A.capacidadKg = intcapacidadKg;
            A.capacidadM3 = intcapacidadLts;
            A.longitud = intlongitud;
            A.latitud = intlatitud;
            A.ciAlmacenero = intci;
            A.rutEmpresa = intrut;



            int devolucion = A.modificarAlmacen();
            if (devolucion == 1) //eror al buscarlo 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error, verify the rut and the ci of the person in charge (if registered)");
                }
                else
                {
                    MessageBox.Show("Error, verifique el rut y el ci del encargado (si se encuentra registrado)");
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The truck was not found, if you want to add it press register");
                }
                else
                {
                    MessageBox.Show("no se encontro el camion, si desea añadirlo apriete registrar");
                }

            }

            else if (devolucion == 3) //ENcontramos el paquete 
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Registered correctly");
                }
                else
                {
                    MessageBox.Show("se registro correctamente ");
                }




            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Connection closed");
                }
                else
                {
                    MessageBox.Show("conexion cerrada  ");
                }
            }


        }

        private void btnEliminar_Click_1(object sender, EventArgs e)
        {
            Almacen A = new Almacen();

            string idalmacen = txtIdAlmacen.Text;
            int intalmacen = int.Parse(idalmacen);
            A.id = intalmacen;


            int devolucion = A.eliminarAlmacen();
            if (devolucion == 3)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Deleted correctly");
                }
                else
                {
                    MessageBox.Show("se elimino correctamente");
                }
            }
            else if (devolucion == 1)
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Error searching for the id, check the data");
                }
                else
                {
                    MessageBox.Show("Error al buscar el id, revise los datos");
                }
            }
            else if (devolucion == 2)//no encontre el paquete
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("The package was not found, nothing to delete");
                }
                else
                {
                    MessageBox.Show("no se encontro el paquete, nada para eliminar ");
                }
                btnRegistrar.Enabled = true;
            }
            else
            {
                if (variables.idiom == true)
                {
                    MessageBox.Show("Resounding error");
                }
                else
                {
                    MessageBox.Show("error rotundo ");
                }
            }



        }

        private void btnlimpiar_Click(object sender, EventArgs e)
        {
            txtCi.Text = null;
            txtIdAlmacen.Text = null;
            txtKg.Text = null;
            txtL.Text = null;
            txtLatitud.Text = null;
            txtLongitud.Text = null;
            comborut.Text = null;
        }

        private void registroAlmacenesApp_Load(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void listBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void grindalmacenes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnlistar_Click(object sender, EventArgs e)
        {
            Almacen A = new Almacen();
            gridalmacenes.DataSource = A.ObtenerDatosAlmacen();
        }

        private void lbboalmlistas_Click(object sender, EventArgs e)
        {

        }
    }
}
