﻿namespace prueba
{
    partial class almaceneroApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(almaceneroApp));
            this.button1 = new System.Windows.Forms.Button();
            this.lbAlmlistadepaquetes = new System.Windows.Forms.Label();
            this.gbsalida = new System.Windows.Forms.GroupBox();
            this.lbAlmmin = new System.Windows.Forms.Label();
            this.txtmatri = new System.Windows.Forms.TextBox();
            this.lbAlmhs = new System.Windows.Forms.Label();
            this.lbAlmmatricula = new System.Windows.Forms.Label();
            this.lbAlmdia = new System.Windows.Forms.Label();
            this.lbAlmsalidadelte = new System.Windows.Forms.Label();
            this.txtloti = new System.Windows.Forms.TextBox();
            this.lbAlmmes = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.lbAlmanio = new System.Windows.Forms.Label();
            this.lbAlmsalidaidlote = new System.Windows.Forms.Label();
            this.txtmin = new System.Windows.Forms.TextBox();
            this.lbAlmfecha2 = new System.Windows.Forms.Label();
            this.txths = new System.Windows.Forms.TextBox();
            this.lbAlmfecha = new System.Windows.Forms.Label();
            this.txtdia = new System.Windows.Forms.TextBox();
            this.txtanio = new System.Windows.Forms.TextBox();
            this.txtmes = new System.Windows.Forms.TextBox();
            this.girdlotes = new System.Windows.Forms.DataGridView();
            this.gridpaquetelote = new System.Windows.Forms.DataGridView();
            this.lbAlmidlote = new System.Windows.Forms.Label();
            this.txtidlote = new System.Windows.Forms.TextBox();
            this.button8 = new System.Windows.Forms.Button();
            this.txtIdBulto = new System.Windows.Forms.TextBox();
            this.lbAlmlegadaidlote = new System.Windows.Forms.Label();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.gbllegada = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.txtidalmacen = new System.Windows.Forms.TextBox();
            this.lbAlmidalmacen = new System.Windows.Forms.Label();
            this.gbalmacen = new System.Windows.Forms.GroupBox();
            this.lbAlmclistadelotes = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbAlm = new System.Windows.Forms.Label();
            this.gbsalida.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.girdlotes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridpaquetelote)).BeginInit();
            this.gbllegada.SuspendLayout();
            this.gbalmacen.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(997, 14);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 36);
            this.button1.TabIndex = 13;
            this.button1.Text = "SALIR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // lbAlmlistadepaquetes
            // 
            this.lbAlmlistadepaquetes.AutoSize = true;
            this.lbAlmlistadepaquetes.BackColor = System.Drawing.Color.Transparent;
            this.lbAlmlistadepaquetes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAlmlistadepaquetes.ForeColor = System.Drawing.Color.Coral;
            this.lbAlmlistadepaquetes.Location = new System.Drawing.Point(105, 20);
            this.lbAlmlistadepaquetes.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbAlmlistadepaquetes.Name = "lbAlmlistadepaquetes";
            this.lbAlmlistadepaquetes.Size = new System.Drawing.Size(261, 25);
            this.lbAlmlistadepaquetes.TabIndex = 17;
            this.lbAlmlistadepaquetes.Text = "Lista de paquetes por lote";
            // 
            // gbsalida
            // 
            this.gbsalida.BackColor = System.Drawing.Color.AliceBlue;
            this.gbsalida.Controls.Add(this.lbAlmmin);
            this.gbsalida.Controls.Add(this.txtmatri);
            this.gbsalida.Controls.Add(this.lbAlmhs);
            this.gbsalida.Controls.Add(this.lbAlmmatricula);
            this.gbsalida.Controls.Add(this.lbAlmdia);
            this.gbsalida.Controls.Add(this.lbAlmsalidadelte);
            this.gbsalida.Controls.Add(this.txtloti);
            this.gbsalida.Controls.Add(this.lbAlmmes);
            this.gbsalida.Controls.Add(this.button2);
            this.gbsalida.Controls.Add(this.lbAlmanio);
            this.gbsalida.Controls.Add(this.lbAlmsalidaidlote);
            this.gbsalida.Controls.Add(this.txtmin);
            this.gbsalida.Controls.Add(this.lbAlmfecha2);
            this.gbsalida.Controls.Add(this.txths);
            this.gbsalida.Controls.Add(this.lbAlmfecha);
            this.gbsalida.Controls.Add(this.txtdia);
            this.gbsalida.Controls.Add(this.txtanio);
            this.gbsalida.Controls.Add(this.txtmes);
            this.gbsalida.Location = new System.Drawing.Point(605, 85);
            this.gbsalida.Margin = new System.Windows.Forms.Padding(4);
            this.gbsalida.Name = "gbsalida";
            this.gbsalida.Padding = new System.Windows.Forms.Padding(4);
            this.gbsalida.Size = new System.Drawing.Size(461, 245);
            this.gbsalida.TabIndex = 15;
            this.gbsalida.TabStop = false;
            this.gbsalida.Text = "salida";
            // 
            // lbAlmmin
            // 
            this.lbAlmmin.AutoSize = true;
            this.lbAlmmin.ForeColor = System.Drawing.Color.Coral;
            this.lbAlmmin.Location = new System.Drawing.Point(395, 148);
            this.lbAlmmin.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbAlmmin.Name = "lbAlmmin";
            this.lbAlmmin.Size = new System.Drawing.Size(30, 17);
            this.lbAlmmin.TabIndex = 56;
            this.lbAlmmin.Text = "min";
            // 
            // txtmatri
            // 
            this.txtmatri.Location = new System.Drawing.Point(332, 97);
            this.txtmatri.Margin = new System.Windows.Forms.Padding(4);
            this.txtmatri.Name = "txtmatri";
            this.txtmatri.Size = new System.Drawing.Size(92, 22);
            this.txtmatri.TabIndex = 11;
            // 
            // lbAlmhs
            // 
            this.lbAlmhs.AutoSize = true;
            this.lbAlmhs.ForeColor = System.Drawing.Color.Coral;
            this.lbAlmhs.Location = new System.Drawing.Point(365, 148);
            this.lbAlmhs.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbAlmhs.Name = "lbAlmhs";
            this.lbAlmhs.Size = new System.Drawing.Size(23, 17);
            this.lbAlmhs.TabIndex = 55;
            this.lbAlmhs.Text = "hs";
            // 
            // lbAlmmatricula
            // 
            this.lbAlmmatricula.AutoSize = true;
            this.lbAlmmatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAlmmatricula.Location = new System.Drawing.Point(8, 97);
            this.lbAlmmatricula.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbAlmmatricula.Name = "lbAlmmatricula";
            this.lbAlmmatricula.Size = new System.Drawing.Size(297, 24);
            this.lbAlmmatricula.TabIndex = 10;
            this.lbAlmmatricula.Text = "Ingresar matricula del camion :";
            // 
            // lbAlmdia
            // 
            this.lbAlmdia.AutoSize = true;
            this.lbAlmdia.ForeColor = System.Drawing.Color.Coral;
            this.lbAlmdia.Location = new System.Drawing.Point(336, 148);
            this.lbAlmdia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbAlmdia.Name = "lbAlmdia";
            this.lbAlmdia.Size = new System.Drawing.Size(27, 17);
            this.lbAlmdia.TabIndex = 54;
            this.lbAlmdia.Text = "dia";
            // 
            // lbAlmsalidadelte
            // 
            this.lbAlmsalidadelte.AutoSize = true;
            this.lbAlmsalidadelte.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAlmsalidadelte.ForeColor = System.Drawing.Color.Coral;
            this.lbAlmsalidadelte.Location = new System.Drawing.Point(81, 20);
            this.lbAlmsalidadelte.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbAlmsalidadelte.Name = "lbAlmsalidadelte";
            this.lbAlmsalidadelte.Size = new System.Drawing.Size(237, 25);
            this.lbAlmsalidadelte.TabIndex = 9;
            this.lbAlmsalidadelte.Text = "Salida de lote a camion";
            this.lbAlmsalidadelte.Click += new System.EventHandler(this.label5_Click);
            // 
            // txtloti
            // 
            this.txtloti.Location = new System.Drawing.Point(243, 59);
            this.txtloti.Margin = new System.Windows.Forms.Padding(4);
            this.txtloti.Name = "txtloti";
            this.txtloti.Size = new System.Drawing.Size(181, 22);
            this.txtloti.TabIndex = 8;
            this.txtloti.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // lbAlmmes
            // 
            this.lbAlmmes.AutoSize = true;
            this.lbAlmmes.ForeColor = System.Drawing.Color.Coral;
            this.lbAlmmes.Location = new System.Drawing.Point(308, 148);
            this.lbAlmmes.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbAlmmes.Name = "lbAlmmes";
            this.lbAlmmes.Size = new System.Drawing.Size(34, 17);
            this.lbAlmmes.TabIndex = 53;
            this.lbAlmmes.Text = "mes";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.DarkBlue;
            this.button2.Location = new System.Drawing.Point(284, 199);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(133, 36);
            this.button2.TabIndex = 7;
            this.button2.Text = "Asignar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lbAlmanio
            // 
            this.lbAlmanio.AutoSize = true;
            this.lbAlmanio.ForeColor = System.Drawing.Color.Coral;
            this.lbAlmanio.Location = new System.Drawing.Point(279, 148);
            this.lbAlmanio.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbAlmanio.Name = "lbAlmanio";
            this.lbAlmanio.Size = new System.Drawing.Size(32, 17);
            this.lbAlmanio.TabIndex = 52;
            this.lbAlmanio.Text = "año";
            // 
            // lbAlmsalidaidlote
            // 
            this.lbAlmsalidaidlote.AutoSize = true;
            this.lbAlmsalidaidlote.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAlmsalidaidlote.Location = new System.Drawing.Point(8, 62);
            this.lbAlmsalidaidlote.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbAlmsalidaidlote.Name = "lbAlmsalidaidlote";
            this.lbAlmsalidaidlote.Size = new System.Drawing.Size(196, 24);
            this.lbAlmsalidaidlote.TabIndex = 0;
            this.lbAlmsalidaidlote.Text = "Ingresar Id del lote :";
            // 
            // txtmin
            // 
            this.txtmin.Location = new System.Drawing.Point(396, 167);
            this.txtmin.Margin = new System.Windows.Forms.Padding(4);
            this.txtmin.Name = "txtmin";
            this.txtmin.Size = new System.Drawing.Size(19, 22);
            this.txtmin.TabIndex = 51;
            // 
            // lbAlmfecha2
            // 
            this.lbAlmfecha2.AutoSize = true;
            this.lbAlmfecha2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAlmfecha2.ForeColor = System.Drawing.Color.Black;
            this.lbAlmfecha2.Location = new System.Drawing.Point(8, 167);
            this.lbAlmfecha2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbAlmfecha2.Name = "lbAlmfecha2";
            this.lbAlmfecha2.Size = new System.Drawing.Size(145, 20);
            this.lbAlmfecha2.TabIndex = 46;
            this.lbAlmfecha2.Text = "del lote al camion:";
            // 
            // txths
            // 
            this.txths.Location = new System.Drawing.Point(368, 167);
            this.txths.Margin = new System.Windows.Forms.Padding(4);
            this.txths.Name = "txths";
            this.txths.Size = new System.Drawing.Size(19, 22);
            this.txths.TabIndex = 50;
            // 
            // lbAlmfecha
            // 
            this.lbAlmfecha.AutoSize = true;
            this.lbAlmfecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAlmfecha.ForeColor = System.Drawing.Color.Black;
            this.lbAlmfecha.Location = new System.Drawing.Point(8, 148);
            this.lbAlmfecha.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbAlmfecha.Name = "lbAlmfecha";
            this.lbAlmfecha.Size = new System.Drawing.Size(223, 20);
            this.lbAlmfecha.TabIndex = 45;
            this.lbAlmfecha.Text = "ingrese la fecha de la subida";
            // 
            // txtdia
            // 
            this.txtdia.Location = new System.Drawing.Point(340, 167);
            this.txtdia.Margin = new System.Windows.Forms.Padding(4);
            this.txtdia.Name = "txtdia";
            this.txtdia.Size = new System.Drawing.Size(19, 22);
            this.txtdia.TabIndex = 49;
            // 
            // txtanio
            // 
            this.txtanio.Location = new System.Drawing.Point(284, 167);
            this.txtanio.Margin = new System.Windows.Forms.Padding(4);
            this.txtanio.Name = "txtanio";
            this.txtanio.Size = new System.Drawing.Size(19, 22);
            this.txtanio.TabIndex = 47;
            // 
            // txtmes
            // 
            this.txtmes.Location = new System.Drawing.Point(312, 167);
            this.txtmes.Margin = new System.Windows.Forms.Padding(4);
            this.txtmes.Name = "txtmes";
            this.txtmes.Size = new System.Drawing.Size(19, 22);
            this.txtmes.TabIndex = 48;
            // 
            // girdlotes
            // 
            this.girdlotes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.girdlotes.Location = new System.Drawing.Point(281, 80);
            this.girdlotes.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.girdlotes.Name = "girdlotes";
            this.girdlotes.RowTemplate.Height = 24;
            this.girdlotes.Size = new System.Drawing.Size(212, 128);
            this.girdlotes.TabIndex = 19;
            // 
            // gridpaquetelote
            // 
            this.gridpaquetelote.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridpaquetelote.Location = new System.Drawing.Point(244, 80);
            this.gridpaquetelote.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gridpaquetelote.Name = "gridpaquetelote";
            this.gridpaquetelote.RowTemplate.Height = 24;
            this.gridpaquetelote.Size = new System.Drawing.Size(228, 128);
            this.gridpaquetelote.TabIndex = 20;
            // 
            // lbAlmidlote
            // 
            this.lbAlmidlote.AutoSize = true;
            this.lbAlmidlote.BackColor = System.Drawing.Color.Transparent;
            this.lbAlmidlote.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAlmidlote.ForeColor = System.Drawing.Color.Black;
            this.lbAlmidlote.Location = new System.Drawing.Point(8, 80);
            this.lbAlmidlote.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbAlmidlote.Name = "lbAlmidlote";
            this.lbAlmidlote.Size = new System.Drawing.Size(190, 24);
            this.lbAlmidlote.TabIndex = 29;
            this.lbAlmidlote.Text = "Ingresar id del lote:";
            // 
            // txtidlote
            // 
            this.txtidlote.Location = new System.Drawing.Point(12, 121);
            this.txtidlote.Margin = new System.Windows.Forms.Padding(4);
            this.txtidlote.Name = "txtidlote";
            this.txtidlote.Size = new System.Drawing.Size(113, 22);
            this.txtidlote.TabIndex = 29;
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.Navy;
            this.button8.Location = new System.Drawing.Point(135, 116);
            this.button8.Margin = new System.Windows.Forms.Padding(4);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(87, 33);
            this.button8.TabIndex = 29;
            this.button8.Text = "Buscar";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // txtIdBulto
            // 
            this.txtIdBulto.Location = new System.Drawing.Point(219, 42);
            this.txtIdBulto.Margin = new System.Windows.Forms.Padding(4);
            this.txtIdBulto.Name = "txtIdBulto";
            this.txtIdBulto.Size = new System.Drawing.Size(123, 22);
            this.txtIdBulto.TabIndex = 1;
            this.txtIdBulto.TextChanged += new System.EventHandler(this.txtIdBulto_TextChanged);
            // 
            // lbAlmlegadaidlote
            // 
            this.lbAlmlegadaidlote.AutoSize = true;
            this.lbAlmlegadaidlote.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAlmlegadaidlote.Location = new System.Drawing.Point(8, 42);
            this.lbAlmlegadaidlote.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbAlmlegadaidlote.Name = "lbAlmlegadaidlote";
            this.lbAlmlegadaidlote.Size = new System.Drawing.Size(190, 24);
            this.lbAlmlegadaidlote.TabIndex = 2;
            this.lbAlmlegadaidlote.Text = "Ingresar Id del lote:";
            this.lbAlmlegadaidlote.Click += new System.EventHandler(this.label2_Click);
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrar.ForeColor = System.Drawing.Color.Green;
            this.btnRegistrar.Location = new System.Drawing.Point(360, 37);
            this.btnRegistrar.Margin = new System.Windows.Forms.Padding(4);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(93, 36);
            this.btnRegistrar.TabIndex = 14;
            this.btnRegistrar.Text = "Registrar";
            this.btnRegistrar.UseVisualStyleBackColor = true;
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);
            // 
            // gbllegada
            // 
            this.gbllegada.BackColor = System.Drawing.Color.AliceBlue;
            this.gbllegada.Controls.Add(this.btnRegistrar);
            this.gbllegada.Controls.Add(this.lbAlmlegadaidlote);
            this.gbllegada.Controls.Add(this.txtIdBulto);
            this.gbllegada.Location = new System.Drawing.Point(605, 363);
            this.gbllegada.Margin = new System.Windows.Forms.Padding(4);
            this.gbllegada.Name = "gbllegada";
            this.gbllegada.Padding = new System.Windows.Forms.Padding(4);
            this.gbllegada.Size = new System.Drawing.Size(461, 108);
            this.gbllegada.TabIndex = 7;
            this.gbllegada.TabStop = false;
            this.gbllegada.Text = "registrar llegada de lote";
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.DarkBlue;
            this.button3.Location = new System.Drawing.Point(172, 113);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(87, 36);
            this.button3.TabIndex = 7;
            this.button3.Text = "Buscar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // txtidalmacen
            // 
            this.txtidalmacen.Location = new System.Drawing.Point(12, 119);
            this.txtidalmacen.Margin = new System.Windows.Forms.Padding(4);
            this.txtidalmacen.Name = "txtidalmacen";
            this.txtidalmacen.Size = new System.Drawing.Size(140, 22);
            this.txtidalmacen.TabIndex = 8;
            this.txtidalmacen.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // lbAlmidalmacen
            // 
            this.lbAlmidalmacen.AutoSize = true;
            this.lbAlmidalmacen.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAlmidalmacen.Location = new System.Drawing.Point(8, 80);
            this.lbAlmidalmacen.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbAlmidalmacen.Name = "lbAlmidalmacen";
            this.lbAlmidalmacen.Size = new System.Drawing.Size(252, 24);
            this.lbAlmidalmacen.TabIndex = 9;
            this.lbAlmidalmacen.Text = "ingrese id de su almacen:";
            this.lbAlmidalmacen.Click += new System.EventHandler(this.label7_Click);
            // 
            // gbalmacen
            // 
            this.gbalmacen.BackColor = System.Drawing.Color.AliceBlue;
            this.gbalmacen.Controls.Add(this.lbAlmclistadelotes);
            this.gbalmacen.Controls.Add(this.lbAlmidalmacen);
            this.gbalmacen.Controls.Add(this.txtidalmacen);
            this.gbalmacen.Controls.Add(this.girdlotes);
            this.gbalmacen.Controls.Add(this.button3);
            this.gbalmacen.Location = new System.Drawing.Point(41, 85);
            this.gbalmacen.Margin = new System.Windows.Forms.Padding(4);
            this.gbalmacen.Name = "gbalmacen";
            this.gbalmacen.Padding = new System.Windows.Forms.Padding(4);
            this.gbalmacen.Size = new System.Drawing.Size(500, 245);
            this.gbalmacen.TabIndex = 16;
            this.gbalmacen.TabStop = false;
            this.gbalmacen.Text = "almacen";
            this.gbalmacen.Enter += new System.EventHandler(this.gbalmacen_Enter);
            // 
            // lbAlmclistadelotes
            // 
            this.lbAlmclistadelotes.AutoSize = true;
            this.lbAlmclistadelotes.BackColor = System.Drawing.Color.Transparent;
            this.lbAlmclistadelotes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAlmclistadelotes.ForeColor = System.Drawing.Color.Coral;
            this.lbAlmclistadelotes.Location = new System.Drawing.Point(93, 20);
            this.lbAlmclistadelotes.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbAlmclistadelotes.Name = "lbAlmclistadelotes";
            this.lbAlmclistadelotes.Size = new System.Drawing.Size(281, 25);
            this.lbAlmclistadelotes.TabIndex = 18;
            this.lbAlmclistadelotes.Text = "Lista de lotes en tu almacen";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.AliceBlue;
            this.groupBox4.Controls.Add(this.gridpaquetelote);
            this.groupBox4.Controls.Add(this.button8);
            this.groupBox4.Controls.Add(this.lbAlmidlote);
            this.groupBox4.Controls.Add(this.txtidlote);
            this.groupBox4.Controls.Add(this.lbAlmlistadepaquetes);
            this.groupBox4.Location = new System.Drawing.Point(41, 363);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(500, 245);
            this.groupBox4.TabIndex = 15;
            this.groupBox4.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.lbAlm);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1100, 63);
            this.panel1.TabIndex = 17;
            // 
            // lbAlm
            // 
            this.lbAlm.AutoSize = true;
            this.lbAlm.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAlm.ForeColor = System.Drawing.Color.White;
            this.lbAlm.Location = new System.Drawing.Point(435, 18);
            this.lbAlm.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbAlm.Name = "lbAlm";
            this.lbAlm.Size = new System.Drawing.Size(214, 31);
            this.lbAlm.TabIndex = 0;
            this.lbAlm.Text = "ALMACENERO";
            // 
            // almaceneroApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1100, 625);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.gbsalida);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.gbalmacen);
            this.Controls.Add(this.gbllegada);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximumSize = new System.Drawing.Size(1118, 672);
            this.MinimumSize = new System.Drawing.Size(1118, 672);
            this.Name = "almaceneroApp";
            this.Text = "almacen";
            this.gbsalida.ResumeLayout(false);
            this.gbsalida.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.girdlotes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridpaquetelote)).EndInit();
            this.gbllegada.ResumeLayout(false);
            this.gbllegada.PerformLayout();
            this.gbalmacen.ResumeLayout(false);
            this.gbalmacen.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox gbsalida;
        private System.Windows.Forms.TextBox txtloti;
        private System.Windows.Forms.DataGridView girdlotes;
        private System.Windows.Forms.DataGridView gridpaquetelote;
        private System.Windows.Forms.TextBox txtmatri;
        private System.Windows.Forms.TextBox txtidlote;
        private System.Windows.Forms.TextBox txtIdBulto;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtmin;
        private System.Windows.Forms.TextBox txths;
        private System.Windows.Forms.TextBox txtdia;
        private System.Windows.Forms.TextBox txtanio;
        private System.Windows.Forms.TextBox txtmes;
        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Button button1;
        public System.Windows.Forms.Label lbAlmlistadepaquetes;
        public System.Windows.Forms.Label lbAlmsalidadelte;
        public System.Windows.Forms.Button button2;
        public System.Windows.Forms.Label lbAlmsalidaidlote;
        public System.Windows.Forms.Label lbAlmmatricula;
        public System.Windows.Forms.Label lbAlmidlote;
        public System.Windows.Forms.Button button8;
        public System.Windows.Forms.Label lbAlmlegadaidlote;
        public System.Windows.Forms.Button btnRegistrar;
        public System.Windows.Forms.GroupBox gbllegada;
        public System.Windows.Forms.Button button3;
        public System.Windows.Forms.TextBox txtidalmacen;
        public System.Windows.Forms.Label lbAlmidalmacen;
        public System.Windows.Forms.GroupBox gbalmacen;
        public System.Windows.Forms.Label lbAlmmin;
        public System.Windows.Forms.Label lbAlmhs;
        public System.Windows.Forms.Label lbAlmdia;
        public System.Windows.Forms.Label lbAlmmes;
        public System.Windows.Forms.Label lbAlmanio;
        public System.Windows.Forms.Label lbAlmfecha2;
        public System.Windows.Forms.Label lbAlmfecha;
        public System.Windows.Forms.Label lbAlmclistadelotes;
        public System.Windows.Forms.Label lbAlm;
    }
}