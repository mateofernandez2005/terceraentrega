﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
namespace prueba
{
    class Camion
    {
        protected string _matricula;
        protected float _capacidadKg;
        protected float _capacidadM3;
        protected ADODB.Connection _conexion;

        public Camion()
        {
            _conexion = Program.cn;
            _capacidadKg = 0;
            _capacidadM3 = 0;
            _matricula = "";
        }

        public Camion(String matricula, float capacidadKg,
    ADODB.Connection cn, float capacidadM3)
        {
            _matricula = matricula;
            _conexion = cn;
            _capacidadKg = capacidadKg;
            _capacidadM3 = capacidadM3;
        }

        public ADODB.Connection conexion
        {
            get { return (_conexion); }
            set { _conexion = value; }
        }

        public String matricula
        {
            get { return (_matricula); }
            set { _matricula = value; }
        }

        public float capacidadKg
        {
            get { return (_capacidadKg); }
            set { _capacidadKg = value; }
        }

        public float capacidadM3
        {
            get { return (_capacidadM3); }
            set { _capacidadM3 = value; }
        }

        public int buscarCamion()
        {

            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;




            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "select matricula from camion where matricula='" + _matricula + "'";

                try
                {
                    rs = _conexion.Execute(sql, out filasAfectadas);

                    if (!rs.EOF) //encontramos el camion
                    {
                        return 3;
                    }
                    else //no encontre el paquete
                    {
                        return 2;
                    }
                }
                catch
                {
                    //int num = int.Parse(sql);
                    return 1;
                }
            }
            else
            {
                return 4;
            }


        }



        public int registrarCamion()
        {
            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;



            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "INSERT INTO camion (matricula, capacidadkg, capacidadM3) VALUES ('"+ _matricula +"'," + _capacidadKg +","+ _capacidadM3+")";
               
                try {

                    _conexion.Execute(sql, out filasAfectadas);



                    return 3;
            }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }
            }
            else
            {
                return 4;
            }


        }
        public int modificarCamion()
        {
            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;



            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "UPDATE camion SET matricula = '" + _matricula + "', capacidadKg = " + _capacidadKg + ", capacidadM3 = " + _capacidadM3 + " WHERE matricula = '" + _matricula + "';";


                try
                {

                    _conexion.Execute(sql, out filasAfectadas);



                    return 3;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }
            }
            else
            {
                return 4;
            }
        }
        public int registrardDatos()
        {
            string sql;
            string sql1;
            string sql2;
            ADODB.Recordset rs;
            object filasAfectadas;

            if (_conexion.State != 0)
            {
                //conexion abierta
                sql = "select matricula from camion where matricula='" + _matricula + "'";
                sql1 = "select capacidadKg from camion where matricula='" + _matricula + "'";
                sql2 = "select capacidadM3 from camion where matricula='" + _matricula + "'";

                try
                {
                    rs = _conexion.Execute(sql, out filasAfectadas);
                    _matricula = rs.Fields["matricula"].Value.ToString();
                    rs = _conexion.Execute(sql1, out filasAfectadas);
                    _capacidadKg = Convert.ToSingle(rs.Fields["capacidadKg"].Value);
                    rs = _conexion.Execute(sql2, out filasAfectadas);
                    _capacidadM3 = Convert.ToSingle(rs.Fields["capacidadM3"].Value);

                    return 3;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }
            }
            else
            {
                return 4;
            }
        }

        public int eliminarCamion()
        {
            String sql;
            String sql1;
            string sql2;

            object filasAfectadas;
            int totalFilasAfectadas = 0;

            if (_conexion.State != 0)
            {
                //conexion abierta
                sql2 = "DELETE FROM manejar WHERE matricula='" + _matricula + "'";
                sql = "DELETE FROM camion_lote WHERE matricula='" + _matricula + "'";
                sql1 = "DELETE FROM camion WHERE matricula='" + _matricula + "'";
                
                try
                {
                    ADODB.Recordset rs3 = _conexion.Execute(sql2, out filasAfectadas);
                    totalFilasAfectadas += (int)filasAfectadas;

                    ADODB.Recordset rs1 = _conexion.Execute(sql, out filasAfectadas);
                    totalFilasAfectadas += (int)filasAfectadas;

                    ADODB.Recordset rs2 = _conexion.Execute(sql1, out filasAfectadas);
                    totalFilasAfectadas += (int)filasAfectadas;

                    
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return 1;
                }

                if (totalFilasAfectadas > 0) //eliminamos el camion
                {
                    return 3;
                }
                else //no encontre el camion
                {
                    return 2;
                }
            }
            else
            {
                return 4; // La conexión no está abierta
            }
        }

        public DataTable RecordsetToDataTable(ADODB.Recordset recordset)
        {
            DataTable dataTable = new DataTable();

            for (int i = 0; i < recordset.Fields.Count; i++)
            {
                dataTable.Columns.Add(recordset.Fields[i].Name, typeof(string));
            }

            while (!recordset.EOF)
            {
                DataRow dataRow = dataTable.NewRow();
                for (int i = 0; i < recordset.Fields.Count; i++)
                {
                    dataRow[i] = recordset.Fields[i].Value.ToString();
                }
                dataTable.Rows.Add(dataRow);
                recordset.MoveNext();
            }

            return dataTable;
        }

        public DataTable ObtenerDatosAlmacen()
        {

            DataTable dataTable = new DataTable();

            if (_conexion.State != 0)
            {
                //conexion abierta
                string sql = "SELECT * FROM camion;";

                try
                {

                    ADODB.Recordset rs = new ADODB.Recordset();


                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic);


                    dataTable = RecordsetToDataTable(rs);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }


            return dataTable;
        }





    }

}
