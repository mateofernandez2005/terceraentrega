﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prueba
{
    public partial class backofficeApp : Form
    {
        public backofficeApp()
        {
            InitializeComponent();
            if (variables.idiom == true)
            {

                registroDeUsuario.Text = "user";
                registroDeCamiones.Text = "trucks";
                registroDePaquetes.Text = "packages";
                registroDeAlmacenes.Text = "warehouses";
                btnSalir.Text = "exit";
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Menu frmMenu = new Menu();
            this.Hide();
            frmMenu.Show();

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void groupBox6_Enter(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void registroDeCamionesToolStripMenuItem_Click(object sender, EventArgs e)
        {

            registroCamionApp2 frmRegistroCamionApp2 = new registroCamionApp2();
            this.Hide();
            frmRegistroCamionApp2.Show();
        }

        private void registroDeUsuarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RegistroUsuarioApp frmRegistroUsuarioApp = new RegistroUsuarioApp();
            this.Hide();
            frmRegistroUsuarioApp.Show();
        }

        private void registroDePaquetesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            registroPaquetesApp frmRegistroPaquetesApp = new registroPaquetesApp();
            this.Hide();
            frmRegistroPaquetesApp.Show();
        }

        private void registroDeAlmacenesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            registroAlmacenesApp frmRegistroAlmacenesApp = new registroAlmacenesApp();
            this.Hide();
            frmRegistroAlmacenesApp.Show();
        }

        private void asignacionesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //AsignacionesApp frmAsignacionesApp = new AsignacionesApp();
            this.Hide();
         //   frmAsignacionesApp.Show();
        }

        private void listasToolStripMenuItem_Click(object sender, EventArgs e)
        {
         //   listasApp frmListasApp = new listasApp();
            this.Hide();
        //    frmListasApp.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            RegistroUsuarioApp frmRegistroUsuarioApp = new RegistroUsuarioApp();
            this.Hide();
            frmRegistroUsuarioApp.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            registroPaquetesApp frmRegistroPaquetesApp = new registroPaquetesApp();
            this.Hide();
            frmRegistroPaquetesApp.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            registroAlmacenesApp frmRegistroAlmacenesApp = new registroAlmacenesApp();
            this.Hide();
            frmRegistroAlmacenesApp.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            registroCamionApp2 frmRegistroCamionApp2 = new registroCamionApp2();
            this.Hide();
            frmRegistroCamionApp2.Show();
        }

  
        private void backofficeApp_Load(object sender, EventArgs e)
        {

        }
    }
    }
    

